"""Reproduce the old zero-count bound and conditional four-lepton discovery reach.

Run from any directory with Python + SciPy. This only reads existing artifacts;
it does not generate events or change any nominal analysis result.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import scipy
from scipy.optimize import brentq
from scipy.special import gammainc, gammaincinv
from scipy.stats import poisson

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CONFIDENCE = .95
MISS = 1. - CONFIDENCE
ALPHA_5SIGMA = .5 * math.erfc(5. / math.sqrt(2.))


def read(path):
    return json.loads(Path(path).read_text())


def artifact(path):
    path = Path(path).resolve()
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def checked_summary(folder):
    path = folder / "summary.json"
    assert artifact(path)["sha256"] == read(folder / "completion.json")["files"]["summary.json"]
    return read(path)


def max_zero_log_probability(total_rate, processes):
    """Profile unknown nonnegative component rates under sum b_i = total_rate.

    Maximize sum N_i log(1-b_i/sigma_i). Its concave optimum satisfies
    b_i=max(0,sigma_i-N_i/lambda); least-exposed components enter first.
    """
    ordered = sorted(processes, key=lambda p: p["mc_exposure_fb_inverse"])
    active = []
    for index, item in enumerate(ordered):
        active.append(item)
        sigma = sum(p["conditional_rate_fb"] for p in active)
        count = sum(p["raw_source_events"] for p in active)
        if total_rate >= sigma:
            continue
        lam = count / (sigma - total_rate)
        if index + 1 < len(ordered) and lam > ordered[index + 1]["mc_exposure_fb_inverse"]:
            continue
        allocation = {p["sample"]: max(0., p["conditional_rate_fb"] - p["raw_source_events"] / lam)
                      for p in ordered}
        if len(active) == 1:
            # Avoid subtracting two ~180,000 fb numbers to obtain ~0.5 fb.
            allocation[active[0]["sample"]] = total_rate
        log_p = sum(p["raw_source_events"] * math.log1p(-allocation[p["sample"]] / p["conditional_rate_fb"])
                    for p in ordered)
        return log_p, allocation
    raise ValueError("total rate exceeds all generated conditional rates")


def median_discovery(signal, background, grid=None):
    """First luminosity with >=50% power for a one-sided local Poisson test.

    For each integer critical count n, the median-power boundary is
    L_n=gammaincinv(n,1/2)/(s+b). It is feasible exactly when
    P_b(N>=n)<=alpha. Enumerating n avoids a false monotonicity assumption
    about power: the integer critical count jumps as luminosity increases.
    """
    for n in range(1, 100000):
        luminosity = float(gammaincinv(n, .5)) / (signal + background)
        if grid is not None:
            luminosity = math.ceil(luminosity / grid) * grid
        tail = float(gammainc(n, background * luminosity))
        if tail <= ALPHA_5SIGMA:
            power = float(poisson.sf(n - 1, (signal + background) * luminosity))
            assert power >= .5 - 1.e-12
            assert math.isclose(tail, float(poisson.sf(n - 1, background * luminosity)), rel_tol=1.e-12)
            assert n == 1 or poisson.sf(n - 2, background * luminosity) > ALPHA_5SIGMA
            return {"luminosity_fb_inverse": luminosity, "critical_count": n,
                    "background_tail_probability": tail, "signal_plus_background_power": power}
    raise ValueError("discovery threshold not found")


def calculate(target, annual_luminosity):
    old_folder = ROOT / "output/reducible_20261117/production_report"
    extended_folder = ROOT / "output/fourl_extended_test_20261111/ssc_qq1m_extended_test"
    old = checked_summary(old_folder)
    extended = checked_summary(extended_folder)
    manifest_path = HERE / "old_ttbar_manifest.json"
    manifest = read(manifest_path)
    tt_entry = next(s for s in manifest["samples"] if s["name"] == "bkg_ttbar")
    assert not tt_entry["decay_bias"]["enabled"]
    first_tt = next(s for s in old["shards"] if s["manifest"].endswith("bkg_ttbar-00000/manifest_ssc.json"))
    assert artifact(manifest_path)["sha256"] == first_tt["shard"]
    proof = tt_entry["shower_completion"]
    factor = proof["root_summary"]["sum_weight"] / proof["saved_events"]
    assert math.isclose(proof["root_summary"]["sum_weight_squared"] / proof["saved_events"], factor * factor, rel_tol=1.e-12)
    assert math.isclose(factor, proof["source_weight_transform"]["factor"], rel_tol=1.e-12)
    assert proof["source_weight_transform"]["factor_bounds"][0] <= factor <= proof["source_weight_transform"]["factor_bounds"][1]
    processes = []
    for name in ("bkg_ttbar", "bkg_zbb_ee", "bkg_zbb_mumu"):
        shards = [row for row in old["shards"] if row["sample"] == name]
        rates = {row["native_cross_section_pb"] for row in shards}
        assert len(shards) == 100 and len(rates) == 1
        for row in shards:
            norm = row["normalization"]
            assert norm["denominator_sumw"] == norm["denominator_npositive"] == norm["denominator_event_count"]
            assert norm["denominator_nnegative"] == norm["denominator_nzero"] == 0
        count = int(sum(row["normalization"]["denominator_event_count"] for row in shards))
        saved = sum(row["observed_source_events"] for row in shards)
        assert count == 1000000
        assert old["frozen_classifier"]["by_process"][name]["selected_source_events"] == 0
        branching = factor if name == "bkg_ttbar" else 1.
        sigma = rates.pop()
        effective_rate = 1000. * sigma * branching
        processes.append({"sample": name, "raw_source_events": count, "saved_source_events": saved,
            "discarded_source_events": count - saved, "selected_positive_response_events": 0,
            "native_cross_section_pb": sigma, "constant_prompt_branching_factor": branching,
            "conditional_rate_fb": effective_rate, "mc_exposure_fb_inverse": count / effective_rate,
            "individual_binomial_upper_95_fb": effective_rate * -math.expm1(math.log(MISS) / count),
            "failed_event_unknown_response_cap_from_observed_fraction_fb": effective_rate * (count-saved) / count})
    min_exposure = min(p["mc_exposure_fb_inverse"] for p in processes)
    poisson_bound = -math.log(MISS) / min_exposure
    bound = brentq(lambda b: max_zero_log_probability(b, processes)[0] - math.log(MISS),
                   0., poisson_bound, xtol=1.e-13)
    log_p, allocation = max_zero_log_probability(bound, processes)
    tt = processes[0]
    assert math.isclose(bound, tt["individual_binomial_upper_95_fb"], abs_tol=2.e-10)
    exposure_target = -math.log(MISS) / target
    required = []
    for p in processes:
        count = math.ceil(p["conditional_rate_fb"] * exposure_target)
        required.append({"sample": p["sample"], "total_independent_unbiased_events": count,
            "additional_events_beyond_old_1m": count - p["raw_source_events"],
            "mc_exposure_fb_inverse": count / p["conditional_rate_fb"]})
    luminosity = read(extended_folder / "manifest_additional_ssc.json")["luminosity_fb"]
    assert luminosity == old["luminosity_fb"]
    assert extended["threshold"] == old["threshold"] == .488
    assert extended["model"]["sha256"] == old["frozen_artifacts"]["model.json"]["sha256"]
    totals = extended["extended_test"]["totals"]
    signal, background = (totals[name]["sum_weight"] / luminosity for name in ("signal", "background"))
    scenarios = {}
    for name, added in (("irreducible_only", 0.), ("plus_planned_target", target), ("plus_old_joint_95_bound", bound)):
        bg = background + added
        exact = median_discovery(signal, bg)
        exact.update(years=exact["luminosity_fb_inverse"] / annual_luminosity,
                     months=12. * exact["luminosity_fb_inverse"] / annual_luminosity)
        scenarios[name] = {"signal_rate_fb": signal, "fixed_background_rate_fb": bg,
            "added_reducible_rate_fb": added, "exact_median_local_poisson": exact,
            "grid_0p1_fb_inverse": median_discovery(signal, bg, .1),
            "asimov_luminosity_fb_inverse": 25. / (2. * ((signal + bg) * math.log1p(signal/bg) - signal))}
    return {"schema_version": 1, "scope": "Conditional sensitivity check, not a nominal background update or experimental discovery projection.",
        "inputs": {name: artifact(path) for name, path in {
            "old_control_report": old_folder / "summary.json", "old_ttbar_manifest": manifest_path,
            "extended_frozen_test": extended_folder / "summary.json",
            "extended_normalization_manifest": extended_folder / "manifest_additional_ssc.json",
            "script": Path(__file__)}.items()}, "scipy_version": scipy.__version__,
        "old_zero_count_inputs": processes,
        "old_joint_zero_count_bound": {"confidence_level": CONFIDENCE,
            "exact_binomial_conservative_upper_fb": bound, "poisson_conservative_upper_fb": poisson_bound,
            "worst_case_component_rate_allocation_fb": allocation, "probability_of_all_zero_at_bound": math.exp(log_p),
            "derivation": "R_i in [0,1] implies E[R_i] <= Pr(R_i>0). For zero positive responses, profile product_i(1-b_i/sigma_i)^N_i over b_i>=0 at fixed sum b_i. The least-exposed ttbar component controls this dataset. This is not the sum of three individual 95% limits.",
            "response_convention": "Failed shower attempts have zero response, exactly as in the recorded normalization. If failed events could pass physically, their unknown contribution is outside this zero-count bound.",
            "observed_failed_fraction_rate_cap_sum_fb_not_a_confidence_limit": sum(p["failed_event_unknown_response_cap_from_observed_fraction_fb"] for p in processes)},
        "zero_count_target": {"combined_reducible_upper_target_fb": target,
            "required_minimum_mc_exposure_per_process_fb_inverse": exposure_target,
            "allocation": required, "total_events_all_processes": sum(p["total_independent_unbiased_events"] for p in required),
            "additional_events_all_processes": sum(p["additional_events_beyond_old_1m"] for p in required),
            "equal_events_per_process_option": max(p["total_independent_unbiased_events"] for p in required),
            "guarantee": "With all zero counts and each N_i/sigma_i >= -log(0.05)/target, the joint 95% Poisson envelope is <=target; the exact binomial envelope is no larger.",
            "conditions": "Independent hard events; unchanged process, cuts and decay model; heavy-flavour decays sampled without importance bias. ttbar uses the existing conditional direct W->e/mu channel with its physical branching factor. The native/biased pilot reuses old hard events and changes the decay backend, so it is not added to the old exposure. The failed-response assumption must also be justified or failures resolved."},
        "discovery_conditions": {"one_sided_local_pvalue": ALPHA_5SIGMA, "median_power": .5,
            "fixed_signal_and_background_rates": True, "profile_background_or_theory_uncertainties": False,
            "look_elsewhere_correction": False, "reference_test_luminosity_fb_inverse": luminosity,
            "frozen_model_threshold": extended["threshold"], "annual_luminosity_fb_inverse": annual_luminosity,
            "startup_ramp": False, "mc_errors_fb_not_profiled": {name: totals[name]["mc_error"] / luminosity for name in ("signal", "background")},
            "integer_count_note": "The first-crossing luminosity is found by enumerating integer critical counts. Power can jump downward when the threshold increases, so rounding a continuous solution to a grid is checked separately."},
        "discovery_scenarios": scenarios}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target-fb", type=float, default=.025)
    parser.add_argument("--annual-luminosity", type=float, default=10.)
    parser.add_argument("--output", type=Path, default=HERE / "sensitivity_check.json")
    args = parser.parse_args()
    assert args.target_fb > 0 and args.annual_luminosity > 0
    result = calculate(args.target_fb, args.annual_luminosity)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(args.output)
