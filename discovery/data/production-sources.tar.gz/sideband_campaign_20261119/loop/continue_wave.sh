#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
exec 8>.continuation.lock
flock -n 8 || exit 1
touch second_wave.active
while [[ ! -f ../fit/target_fit.json ]]; do
    complete=true
    for index in 0 1 2 3; do
        [[ -s sideband_loop_focus_20261119_$index.json ]] || complete=false
    done
    if [[ "$complete" == true ]]; then
        bash launch.sh 1
        exit $?
    fi
    sleep 45
done
