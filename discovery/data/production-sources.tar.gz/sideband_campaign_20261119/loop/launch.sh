#!/usr/bin/env bash
set -eo pipefail
source /etc/profile.d/modules.sh
module load herwig/stable
set -u
export PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
work_dir=/home/apapaefs/HiggsSSC/inputs/pipeline/sideband_campaign_20261119/loop
archive=/home/apapaefs/HiggsSSC/inputs/pipeline/loop-gammagamma-20261118
generator_python=/home/apapaefs/HiggsSSC/inputs/pipeline/venv/bin/python
smoke_export="$archive/source_v1/hgammagamma/HOAnalysis/runs/gg_aa_loop_smoke_20261118/Backgrounds/events/bkg_loop_gg_aa/mg5_process"
cd "$work_dir"
# Each wave contains four independent 8k runs on the four allotted threads.
wave=${1:-0}
case "$wave" in
    0) lock=.launch.lock; completion=finished ;;
    1) lock=.wave_1.lock; completion=wave_1_finished ;;
    *) echo "Expected wave 0 or 1" >&2; exit 2 ;;
esac
exec 9>"$work_dir/$lock"
flock -n 9 || exit 1
run_one() {
    local index="$1" cpu="$2" tag seed source_dir
    tag="sideband_loop_focus_20261119_$index"
    seed=$((191160100+index))
    source_dir="$work_dir/runtime_$index"
    mkdir -p "$source_dir" "$work_dir/runs"
    rsync -a --exclude='runs/' --exclude='results/' --exclude='.git/' --exclude='__pycache__/' "$archive/source_v4/" "$source_dir/"
    if [[ ! -s "$work_dir/$tag.json" ]]; then
        cd "$source_dir"
        taskset -c "$cpu" "$generator_python" hgammagamma/run_loop_gammagamma.py \
            --stage all --resume --output-dir "$work_dir/runs/$tag" --run-tag "$tag" --nevents 8000 --nb-core 1 \
            --gen-mgg-min 100 --gen-mgg-max 150 --reuse-loop-export "$smoke_export" \
            --seed-base "$seed" --ebeam 20000 --no-herwig-module \
            --mg5-dir /home/apapaefs/HiggsSSC/inputs/pipeline/MG5_aMC_v3_5_15 \
            --mg5-python "$generator_python" --mg5-fortran /usr/bin/gfortran --mg5-cxx /usr/bin/g++ --analysis-cxx /usr/bin/g++
        "$generator_python" "$work_dir/extract.py" "$work_dir/runs/$tag/Backgrounds/events/bkg_loop_gg_aa" "$work_dir/$tag.json"
    fi
}
pids=()
cores=(38 39 78 79)
for n in 0 1 2 3; do
    index=$((4*wave+n))
    run_one "$index" "${cores[n]}" > "$work_dir/shard_$index.log" 2>&1 &
    pids+=("$!")
done
failed=0
for pid in "${pids[@]}"; do wait "$pid" || failed=1; done
date -u > "$work_dir/${completion}_${failed}.utc"
exit "$failed"
