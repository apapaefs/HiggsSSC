"""Extract a unit-normalized independent focused gg continuum mass spectrum."""
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import uproot
from scipy.sparse import coo_matrix

directory, output = map(Path, sys.argv[1:])
manifest = json.loads((directory / "campaign.json").read_text())
tag, hard = manifest["run_tag"], manifest["lhe"]
generated = hard["events"]
completion = manifest["shower_completion"]
assert manifest["completed"][-1] == "analyze"
assert (hard["born_mgg_validation"]["minimum_cut_gev"], hard["born_mgg_validation"]["maximum_cut_gev"]) == (100.,150.)
assert completion["attempted_events"] == generated and completion["saved_events"] == int(manifest["analysis"]["events_read"])
assert manifest["analysis"]["detector_response"] == "ssc" and manifest["analysis"]["response_mode"] == "genuine"
assert hard["negative_events"] == 0 and abs(hard["effective_events"]/generated - 1) < 1.e-6
root = directory / f"bkg_loop_gg_aa_hwsim_roots-{tag}_var.root"
with uproot.open(root) as source:
    tree = source["Data2"]
    values = tree["variables"].array(library="np")
    weights = tree["eventweight"].array(library="np").ravel()
    ids = tree["sourceevent"].array(library="np").ravel()
assert np.isclose(weights.sum(),completion["saved_events"],rtol=1.e-5)
keep = (values[:,-1]>=2) & (values[:,0]>=105) & (values[:,0]<160)
_, src = np.unique(ids[keep],return_inverse=True)
edges = np.arange(105.,161.)
bins = np.searchsorted(edges,values[keep,0],side="right")-1
w = weights[keep]*(1000.*hard["cross_section_pb"]/generated)
matrix = coo_matrix((w,(src,bins)),shape=(len(np.unique(src)),55)).tocsr()
hist = np.asarray(matrix.sum(axis=0)).ravel()
cov = (matrix.T @ matrix).toarray()
result = dict(sample="bkg_loop_gg_aa",stratum="focused_inside",generated_events=generated,
              independent_id=hard["sha256"],seed=manifest["seed"],run_tag=tag,
              mass_bin_edges_GeV=edges.tolist(),rates_fb=hist.tolist(),covariance_fb2=cov.tolist(),
              source_lhe_sha256=hard["sha256"],response_root_sha256=hashlib.sha256(root.read_bytes()).hexdigest(),
              native_cross_section_pb=hard["cross_section_pb"],selected_sources=matrix.shape[0],
              saved_events=completion["saved_events"],failed_showers=completion["discarded_events"],
              max_momentum_residual_MeV=completion["max_momentum_violation_mev"])
tmp=output.with_suffix(".tmp")
tmp.write_text(json.dumps(result)+"\n")
tmp.replace(output)
