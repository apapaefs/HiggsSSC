"""Prepare portable reference inputs from the published run, validating independent ROOT extraction."""
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.sparse import coo_matrix


HERE = Path(__file__).resolve().parent
OUTPUT = HERE.parents[1]
ROOT = OUTPUT.parent


def read(path):
    return json.loads(path.read_text())


def main():
    old_path = OUTPUT/"sideband_discovery/closure/continuum_fit.json"
    old = read(old_path)
    reach = read(OUTPUT/"sideband_discovery/statistics/sideband_reach.json")
    extra = ROOT/"hgammagamma/HOAnalysis/student_backgrounds/ssc40_v1"
    sample_meta = read(extra/"manifest.json")["samples"]
    edges = old["mass_bin_edges_GeV"]
    datasets = []
    published = read(OUTPUT/"student-defaults-20261118/2f510c0/discovery/diphoton_cuts.json")
    attempts = {row["sample"]:row["shower_quality"]["attempted_events"]
                for row in published["samples"] if row.get("shower_quality")}
    attempts["bkg_dijet_double_fake"] = sample_meta["bkg_dijet_double_fake"]["generated_sources"]
    for name, spectrum in old["sample_rates_fb_by_bin"].items():
        if name=="bkg_loop_gg_aa":
            continue
        member = {"sample":name,"stratum":"full","generated_events":attempts[name],
                  "rate_fb":spectrum,"covariance_fb2":old["component_covariance_fb_squared"][name],
                  "edges_gev":edges,"independent_id":"published:"+name}
        if name in ("bkg_prompt_aa","bkg_gamma_j"):
            fname = "prompt_1m_reference.json" if name=="bkg_prompt_aa" else "gammaj_1m_reference.json"
            replica = read(HERE/fname)
            for k in ("rate_fb","covariance_fb2"):
                if not np.allclose(replica[k],member[k],rtol=1.e-10,atol=1.e-10):
                    raise ValueError(f"Reference ROOT extraction differs for {name} {k}")
            member.update({k:replica[k] for k in ("independent_id","seed","generated_events")})
            member["source_lhe_sha256"] = replica["independent_id"]
        if name=="bkg_dijet_double_fake":
            member["shards"] = [{"seed":i["seed"],"events":i["generated"]} for i in sample_meta[name]["inputs"]]
        datasets.append(member)
    name = "bkg_loop_gg_aa"
    meta = sample_meta[name]
    path = extra/meta["file"]
    if hashlib.sha256(path.read_bytes()).hexdigest()!=meta["sha256"]:
        raise ValueError("Baseline loop table differs from the published input")
    with np.load(path) as arr:
        x, src, weights = arr["variables"],arr["sourceevent"],arr["weight_pb"]*1000.
    eligible = (x[:,-1]>=2)&(x[:,0]>=edges[0])&(x[:,0]<edges[-1])
    offset = 0
    for domain in meta["inputs"]:
        stop = offset+domain["generated"]
        mask = eligible & (src>=offset) & (src<stop)
        bins = np.searchsorted(edges,x[mask,0],side="right") - 1
        matrix = coo_matrix((weights[mask],(src[mask]-offset,bins)),
                            shape=(stop-offset,len(edges)-1)).tocsr()
        # From the original source_v2 campaign.json matched by the LHE SHA-256.
        baseline_loop_seeds = {
            "c9e2785376cddff765f0d39ed8254fbbcfc859a9a3d4e0ac408f912146ed9b2d": 181126032,
            "ba9346f3821772c0888e508eb01ac63d6633640fc53ee37166d76b5331eb32d3": 181126033,
        }
        hard_hash = domain["source_lhe_sha256"]
        datasets.append({"sample":name,"stratum":domain["region"],"generated_events":stop-offset,
                         "independent_id":hard_hash,"source_lhe_sha256":hard_hash,
                         "seed":baseline_loop_seeds[hard_hash],"edges_gev":edges,
                         "rate_fb":np.asarray(matrix.sum(axis=0)).ravel().tolist(),
                         "covariance_fb2":(matrix.T@matrix).toarray().tolist()})
        offset=stop
    for k, field in (("rate_fb","sample_rates_fb_by_bin"),("covariance_fb2","component_covariance_fb_squared")):
        if not np.allclose(sum(np.array(d[k]) for d in datasets if d["sample"]==name), old[field][name]):
            raise ValueError(f"Loop split fails to close {field}")
    result={"datasets":datasets, "fourlepton":reach["fourlepton_rates_fb"],
            "old_fit_sha256":hashlib.sha256(old_path.read_bytes()).hexdigest(),
            "published_median_reach":reach["multibin_models"]["exponential2"],
            "published_spurious_mu_error":old["models"]["exponential2"]["spurious_signal_mc_standard_error"]}
    (HERE/"baseline.json").write_text(json.dumps(result,separators=(",",":"))+"\n")


if __name__=="__main__":
    main()
