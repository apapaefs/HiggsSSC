"""Quantify a complete-shard replacement against the campaign mass fit."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

base=Path(__file__).resolve().parent
sys.path.insert(0,str(base.parent/"fit"/"reference"))
from continuum_fit import ALL, BLIND, WINDOW, Shape

parser=argparse.ArgumentParser()
parser.add_argument("index",type=int)
parser.add_argument("--fit",type=Path,default=base.parent/"fit"/"latest_fit.json")
parser.add_argument("--exposure",type=int,default=46920000)
args=parser.parse_args()
folder=base/"recovery"/f"{args.index:04d}"
control=json.loads((folder/"replacement_comparison.json").read_text())
raw=args.fit.read_bytes()
fit=json.loads(raw)
b=np.asarray(fit["background_per_bin_fb"])
s=np.asarray(fit["signal_per_bin_fb"])
shape=Shape("exponential",2)
par,_,_,deriv=shape.fit(b,ALL,s)
n=json.loads((folder/"independent_control"/"spectrum.json").read_text())["generated_events"]
delta=np.asarray(control["rate_shift_fb"])*n/args.exposure
cov=np.asarray(control["covariance_fb2"])*(n/args.exposure)**2
par_new,_,_,_=shape.fit(b+delta,ALL,s)
def lumi(background):
    _,smooth,_,_=shape.fit(background,~BLIND)
    truth=smooth+s
    _,null,_,_=shape.fit(truth,ALL)
    return 25/(2*np.sum(null-truth+truth*np.log(truth/null)))
def first_source(part):
    p=folder/part
    summary=json.loads((p/"spectrum.json").read_text())
    w=np.zeros_like(b)
    with (p/"pairs.csv").open() as handle:
        for row in csv.DictReader(handle):
            m=float(row["m_gg"])
            if int(row["source"])==0 and 105<=m<160:
                w[int(m-105)]+=float(row["fq"])**2*summary["sigma_nb"]*1.e6/args.exposure
    return {"seed":summary["generator_seed"],"full_mass_range_rate_fb":w.sum(),
            "four_GeV_window_rate_fb":w[WINDOW].sum(),"linear_mu":deriv[-1]@w}

out={"index":args.index,"reference_fit_sha256":hashlib.sha256(raw).hexdigest(),
     "exposure_events_including_reference":args.exposure,
     "method":"At this total dijet exposure replace the official reconstructed shard by its prespecified independent control. Both spectra use their own native cross sections. All other analysis components are fixed to the named checkpoint. The fit of the two spectra uses the same nominal quadratic log continuum, signal template, mass bins, and blinded sidebands.",
     "control_minus_recovered_fit_mass_range_fb":delta.sum(),
     "fit_mass_range_change_mc_error_fb":np.sqrt(cov.sum()),
     "control_minus_recovered_123_127_gev_fb":delta[WINDOW].sum(),
     "window_change_mc_error_fb":np.sqrt(cov[WINDOW][:,WINDOW].sum()),
     "control_minus_recovered_mu":par_new[-1]-par[-1],
     "mu_change_mc_error_linearized":np.sqrt(deriv[-1]@cov@deriv[-1]),
     "smooth_L5_change_fb_inverse":lumi(b+delta)-lumi(b),
     "first_independent_continuation_source":first_source("continuation"),
     "first_independent_control_source":first_source("independent_control")}
path=folder/f"fit_sensitivity_{args.exposure}.json"
path.write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out,indent=2))
