"""Small read-only snapshot of the running minimum-bias campaign."""
import json
import os
from pathlib import Path
import time
ROOT=Path(__file__).resolve().parent
state={"timestamp":time.time()}
for name in ["dispatch.log","dispatch_idle.log","dispatch_third.log"]:
    f=ROOT/name
    if not f.is_file(): continue
    lines=f.read_text().splitlines()
    failed=[int(x.split()[2]) for x in lines if x.startswith("FAILED shard ")]
    unresolved=[n for n in failed if not (ROOT/"shards"/f"{n:04d}"/"spectrum.json").exists()]
    state[name]={"successes":sum(x.startswith("Completed ") and " of " not in x for x in lines),
                 "failed":failed,"unresolved":unresolved}
state["native_repair_errors"]=[p.name for p in (ROOT/"recovery_tasks").glob("*.error")]
state["repair_status"]={p.name:p.suffix for p in (ROOT/"recovery_tasks").glob("*") if p.is_file()}
state["fit_target"]=(ROOT.parent/"fit"/"target_fit.json").exists()
state["third_done"]=(ROOT/"third_wave.done.json").exists()
state["primary_validated"]=all((ROOT/"shards"/f"{i:04d}"/"spectrum.json").is_file() for i in range(504))
state["free_gb"]=round(os.statvfs(ROOT).f_bavail*os.statvfs(ROOT).f_frsize/1e9,1)
agg=ROOT/"pooled_waves.json"
if agg.is_file():
    a=json.loads(agg.read_text())
    state["closed_waves"]=a["complete_predeclared_waves"]
    state["sampled_events"]=a["generated_events"]
print(json.dumps(state))
