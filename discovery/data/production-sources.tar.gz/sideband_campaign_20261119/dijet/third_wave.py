"""Launch optional, fixed 12-seed blocks after the primary allocation is free."""
import json
import os
from pathlib import Path
import subprocess
import time
import sys

BASE=Path(__file__).resolve().parent
TARGET=BASE.parent/"fit"/"target_fit.json"
MARKER=BASE/"third_wave.active"
DONE=BASE/"third_wave.done.json"
WAVE_LOG=BASE/"dispatch_third.log"
MASK="12-17,52-57"
def exists(i):
    return (BASE/"shards"/f"{i:04d}"/"spectrum.json").is_file()
def finish(reason):
    tmp=DONE.with_suffix(".tmp")
    tmp.write_text(json.dumps({"reason":reason,"completed_indices":[i for i in range(624,912) if exists(i)],
                               "time_unix":time.time()})+"\n")
    tmp.replace(DONE)
if not MARKER.is_file():
    raise SystemExit("Stage 3 requires the agreed activation marker.")
while not all(exists(i) for i in range(504)):
    if TARGET.is_file():
        finish("precision_target_before_primary_end")
        raise SystemExit(0)
    time.sleep(30)
subprocess.run([sys.executable,str(BASE/"pool.py"),"--first","0","--stop","504","--output","primary_final.json"],check=True)
for first in range(624,912,12):
    if TARGET.is_file():
        finish("precision_target")
        raise SystemExit(0)
    if all(exists(i) for i in range(first,first+12)):continue
    with WAVE_LOG.open("a") as out:
        subprocess.run(["taskset","-c",MASK,"bash",str(BASE/"launch.sh"),str(first),str(first+12),"50000","12"],
                       stdout=out,stderr=subprocess.STDOUT,check=False)
    while not all(exists(i) for i in range(first,first+12)):
        # Retry queued diagnosed native recovery tasks in the available slots.
        from recover import work_outstanding
        pending=list((BASE/"recovery_tasks").glob("*.json"))
        if pending:
            work_outstanding()
        else:
            time.sleep(15)
finish("all_third_seeds_closed")
