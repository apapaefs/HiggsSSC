"""Use one freed slot within a fixed twelve-seed block for diagnosed native replay."""
import argparse
from pathlib import Path
import time

from recover import work_outstanding

p=argparse.ArgumentParser()
p.add_argument("index",type=int)
p.add_argument("freed_slots",type=int)
a=p.parse_args()
root=Path(__file__).resolve().parent
start=624+12*((a.index-624)//12)
assert 624<=a.index<912 and 1<=a.freed_slots<=12
while True:
    done=sum(any((root/"shards"/f"{i:04d}"/name).is_file()
                 for name in ("spectrum.json","native_failure.json"))
             for i in range(start,start+12))
    if done>=a.freed_slots: break
    time.sleep(6)
work_outstanding(a.index,a.index+1)
