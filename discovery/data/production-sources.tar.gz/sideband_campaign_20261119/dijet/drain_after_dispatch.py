"""Use a freed worker in its own allocation if a last-wave native failure needs replay."""
import argparse
from pathlib import Path
import re
import time

from recover import work_outstanding

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("dispatch_log")
parser.add_argument("first", type=int)
parser.add_argument("stop", type=int)
args = parser.parse_args()
log = root / args.dispatch_log
terminal = re.compile(r"^Completed \d+ of " + str(args.stop - args.first) + r"$", re.M)
while not log.is_file() or not terminal.search(log.read_text()):
    time.sleep(30)

while True:
    todo = [i for i in range(args.first, args.stop)
            if not (root / "shards" / f"{i:04d}" / "spectrum.json").is_file()]
    if not todo:
        break
    tasks = root / "recovery_tasks"
    if any(args.first <= int(p.name.split("_", 1)[0]) < args.stop for p in tasks.glob("*.json")):
        work_outstanding(args.first, args.stop)
    else:
        time.sleep(15)
