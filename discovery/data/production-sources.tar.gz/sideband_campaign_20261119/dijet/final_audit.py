"""Write the final physical-exposure and native recovery audit against one fit."""
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time

here=Path(__file__).resolve().parent
folder=here/"final_audit_inputs"
folder.mkdir(exist_ok=True)
os.environ.update(OPENBLAS_NUM_THREADS="1",OMP_NUM_THREADS="1",MKL_NUM_THREADS="1")
def read(path): return json.loads(path.read_text())
def run(script,*args):
    subprocess.run([sys.executable,str(here/script),*map(str,args)],check=True,stdout=subprocess.DEVNULL)

while not (here/"third_wave.done.json").is_file(): time.sleep(30)
done=read(here/"third_wave.done.json")
pooled=folder/"dijet_pool.json"
run("pool.py","--complete-waves","--output",pooled)
packet=read(pooled)
nnew=packet["generated_events"]
exposure=1320000+nnew
fitpath=folder/"fit_at_dijet_closure.json"
while True:
    incoming=(here.parent/"fit"/"latest_fit.json").read_bytes()
    data=json.loads(incoming)
    proc=data["generated_exposures"]["bkg_dijet_double_fake"]["full"]
    if proc["generated_including_reference"]==exposure: break
    time.sleep(20)
fitpath.write_bytes(incoming)
records=[]
for replica in packet["shards"]:
    if not replica.get("continuation_generator_seeds"): continue
    source=here/replica["path"]
    d=read(source)
    idx=int(source.parent.name)
    rec=here/"recovery"/source.parent.name
    while not (rec/"replacement_comparison.json").is_file():time.sleep(20)
    run("compare_repair.py",idx,"--fit",fitpath,"--exposure",exposure)
    compare=read(rec/f"fit_sensitivity_{exposure}.json")
    records.append((idx,d,rec,compare))

late=[r for r in records if r[1].get("independently_replaced_native_decays")]
late_checks={}
for idx,_,rec,_ in late:
    run("bound_replaced_source.py",idx,"--fit",fitpath,"--exposure",exposure)
    late_checks[idx]=read(rec/f"saved_event_bound_{exposure}.json")
    if idx!=390 and late_checks[idx]["fit_mass_range_pair_count_bound"]:
        raise RuntimeError(f"An additional native late-decay sensitivity check is needed for {idx}")
run("evaluate_decay_replay.py",390,73000391,73000392,73000393,73000394,"--exposure",exposure)
bound=late_checks[390]
conditional=read(here/"recovery"/"0390"/"conditional_native_decay_sensitivity.json")
def signed(x): return f"{x:+.5f}".replace("-","−")
rows=[]
for idx,d,rec,comp in records:
    prefix=d["components"]["prefix"]["size"]
    cont=d["components"]["continuation"]
    compare=read(rec/"independent_control"/"spectrum.json")
    if d.get("zero_response_native_aborts"):
        treatment="One accepted collision provably had zero dijet response"
    elif d.get("interrupted_sampler_proposals"):
        treatment="One diffractive sampler trial interrupted before event acceptance"
    elif d.get("independently_replaced_native_decays"):
        treatment="One accepted collision interrupted during decay and was independently replaced"
        if late_checks[idx]["fit_mass_range_pair_count_bound"]==0:
            treatment+=". Its saved topology proves zero original double-fake weight"
    else:
        raise ValueError(f"Unclassified interruption in {idx}")
    rows.append(f"| {idx} | {d['generator_seed']} | {d['abort_1based_event_index']:,} | {prefix:,} + {cont['size']:,} | {cont['seed']} / {compare['generator_seed']} | {treatment} | {signed(comp['control_minus_recovered_mu'])} ± {comp['mu_change_mc_error_linearized']:.5f} |")

fit_sha=hashlib.sha256(incoming).hexdigest()
assert all(c["reference_fit_sha256"]==fit_sha for _,_,_,c in records)
assert bound["fit_sha256"]==conditional["fit_sha256"]==fit_sha
seeds=packet["shard_count"]
lines=[
    "# Dijet double-fake production audit",
    f"The fit uses **{exposure:,} physical source events** across the earlier 1,320,000 events and {seeds:,} new seeds of 50,000 events each. The new exposure is {nnew:,}. Independent controls and conditional re-decays add zero exposure. Each seed uses its native inclusive cross section and all fake-pair contributions from a common source are grouped in its 55-bin covariance.",
    "Every interrupted seed contributes exactly 50,000 requests to the fit. The last column gives the change in fitted 125 GeV Higgs strength when a separate 50,000-event control replaces that whole seed within the completed exposure. Its error comes from the two independent source samples.",
    "| Shard | Original seed | Interrupted request | Replayed prefix + continuation | Continuation / control seed | Native accounting | Control shift in Higgs yields |\n|---:|---:|---:|---:|---|---|---:|\n"+"\n".join(rows),
    f"For source 390, request 36,560, the six unresolved hadrons were re-decayed {conditional['native_decay_trials']:,} times with the other 595 particles fixed. All trials passed the momentum checks. The leading reconstructed transverse momentum was at most {conditional['max_leading_reconstructed_pt_bound_gev']:.2f} GeV across these trials, below the 20 GeV photon threshold.",
    f"At the actual {exposure/1e6:.2f} million-event exposure, the one-sided 95% upper bound on the **expected** positive shift from this collision is {conditional['conditional_expected_positive_mu_shift_95pct_upper_at_planned_exposure']:.2g} Higgs yields for maximally mixed parents. Under the same normalized positive native decay law, allowing arbitrary joint parent spins gives an expected shift between −{conditional['arbitrary_joint_spin_negative_mu_shift_abs_95pct_upper_at_planned_exposure']:.2g} and +{conditional['arbitrary_joint_spin_positive_mu_shift_95pct_upper_at_planned_exposure']:.2g} at 95% confidence. The spin dimension factor is 135. For an **individual possible decay outcome**, projecting onto the fit derivative gives deterministic shift bounds of {signed(bound['linearized_lower_mu_shift'])} and {signed(bound['linearized_upper_mu_shift'])} Higgs yields. That bound permits up to {bound['fit_mass_range_pair_count_bound']} fit-range pairs and uses GEM's largest in-range per-jet fake probability, {bound['maximum_fake_probability_per_jet_in_fit_range']:.6f}.",
    f"The pool has identity `{packet['independent_id']}`. The common fit checkpoint has SHA-256 `{fit_sha}`. The per-source products, controls and original native process diagnostics are under `dijet/recovery` on Timur.",
]
for idx,_,_,comp in late:
    if idx==390:continue
    bnd=late_checks[idx]
    first=comp["first_independent_continuation_source"]["full_mass_range_rate_fb"]
    count=bnd['eligible_jet_count_bound']
    jets='jet' if count==1 else 'jets'
    lines.insert(-1,f"Source {idx} has at most {count} eligible {jets} for any momentum-conserving decays of its {bnd['unstable_parents']} unfinished parents. The original source has exactly zero fit-range pair weight. Its prespecified independent replacement also contributes {first:.6g} fb across the fit range.")
output=here/"final_dijet_audit.md"
draft=output.with_suffix(".tmp")
draft.write_text("\n\n".join(lines)+"\n")
draft.replace(output)
print(output,exposure,done["reason"],flush=True)
