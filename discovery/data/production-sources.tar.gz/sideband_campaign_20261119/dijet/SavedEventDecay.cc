#include "Herwig/Decay/HwDecayHandler.h"
#include "ThePEG/EventRecord/Particle.h"
#include "ThePEG/EventRecord/Collision.h"
#include "ThePEG/EventRecord/Step.h"
#include "ThePEG/Handlers/AnalysisHandler.h"
#include "ThePEG/Interface/ClassDocumentation.h"
#include "ThePEG/Repository/EventGenerator.h"
#include "ThePEG/Utilities/DescribeClass.h"
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <stdexcept>
#include <vector>

namespace Herwig {
using namespace ThePEG;

class SavedEventDecay : public AnalysisHandler {
public:
  static void Init() {
    static ClassDocumentation<SavedEventDecay> doc("Re-decay saved colour-singlet parents with the configured native handler.");
  }
  void analyze(tEventPtr, long, int, int) override {
    if (finished) return;
    finished=true;
    auto handler=generator()->getObject<HwDecayHandler>("/Herwig/Decays/DecayHandler");
    if (!handler) throw std::runtime_error("Missing native decay handler");
    std::ifstream input("parents.dat");
    std::ofstream out("daughters.dat");
    out << std::setprecision(17);
    int pdg;
    double px,py,pz,e,m;
    struct Parent { int id; Lorentz5Momentum p; };
    std::vector<Parent> parents;
    while(input>>pdg>>px>>py>>pz>>e>>m)
      parents.push_back({pdg,Lorentz5Momentum(px*GeV,py*GeV,pz*GeV,e*GeV,m*GeV)});
    if(parents.size()!=6) throw std::runtime_error("Expected six saved colour-singlet parents");
    const int draws=std::stoi(std::getenv("SSC_DECAY_DRAWS")?std::getenv("SSC_DECAY_DRAWS"):"64");
    for(int i=0;i<draws;++i) {
      for(unsigned j=0;j<parents.size();++j) {
        const auto &saved=parents[j];
        PPair incoming(getParticleData(22)->produceParticle(),getParticleData(22)->produceParticle());
        CollPtr collision=new_ptr(Collision(incoming));
        tStepPtr step=collision->newStep();
        PPtr parent=getParticleData(saved.id)->produceParticle(saved.p);
        step->addParticle(parent);
        handler->performDecay(parent,*step);
        const auto daughters=step->getFinalState();
        if(daughters.empty()) throw std::runtime_error("Native decay returned no daughters");
        for(const auto &daughter:daughters) {
          const auto &p=daughter->momentum();
          out << i << ' ' << j << ' ' << daughter->id() << ' ' << p.x()/GeV << ' ' << p.y()/GeV
              << ' ' << p.z()/GeV << ' ' << p.e()/GeV << ' ' << p.m()/GeV << '\n';
        }
      }
    }
    out.close();
    if(!out) throw std::runtime_error("Could not write the native decay sample");
  }
private:
  IBPtr clone() const override {return new_ptr(*this);}
  IBPtr fullclone() const override {return new_ptr(*this);}
  bool finished=false;
};
DescribeClass<SavedEventDecay,AnalysisHandler> describeSavedEventDecay("Herwig::SavedEventDecay","SavedEventDecay.so");
}
