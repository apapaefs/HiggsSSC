"""Initialize the original Herwig decay configuration, then sample saved parents."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess

here=Path(__file__).resolve().parent
args=argparse.ArgumentParser()
args.add_argument("index",type=int)
args.add_argument("seed",type=int)
args.add_argument("draws",type=int)
a=args.parse_args()
folder=here/"recovery"/f"{a.index:04d}"
out=folder/"native_redecays"/str(a.seed)
out.mkdir(exist_ok=True,parents=True)
plugin=out/"SavedEventDecay.so"
if not plugin.exists(): plugin.symlink_to(here/"SavedEventDecay.so")
state=json.loads(next(l.split("=",1)[1] for l in (folder/"event_data_stable.log").read_text().splitlines() if l.startswith("DECAY_PARTICLES=")))
parents=[p for p in state if not p["stable"]]
assert len(parents)==6
(out/"parents.dat").write_text("".join(" ".join(map(str,[p["particle_id"],*p["momentum_gev"]]))+"\n" for p in parents))
source=(here/"shards"/f"{a.index:04d}"/"minbias.in").read_text()
source=re.sub(r"(RandomNumberGenerator:Seed) [0-9]+",rf"\g<1> {a.seed}",source)
source=re.sub(r"(EventGenerator:NumberOfEvents) [0-9]+",r"\g<1> 1",source)
setup=f"""library {here}/SavedEventDecay.so
create Herwig::SavedEventDecay /Herwig/Analysis/SavedEventDecay
insert EventGenerator:AnalysisHandlers 0 /Herwig/Analysis/SavedEventDecay
"""
source=source.replace("saverun minbias",setup+"saverun minbias")
assert "create Herwig::SavedEventDecay" in source
(out/"minbias.in").write_text(source)
(out/"events").mkdir(exist_ok=True)
for command,name in ((["Herwig","read","minbias.in"],"read.log"),(["Herwig","run","minbias.run","-N1"],"run.log")):
    with (out/name).open("w") as log:
        subprocess.run(command,cwd=out,stdout=log,stderr=subprocess.STDOUT,check=True,
                       env={**os.environ,"SSC_DECAY_DRAWS":str(a.draws)})
if not (out/"daughters.dat").stat().st_size: raise RuntimeError("Empty native re-decay sample")
