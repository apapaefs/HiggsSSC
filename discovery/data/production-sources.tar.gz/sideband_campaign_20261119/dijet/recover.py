"""Replay a failed seed through its last valid event and account for its one abort.

A postmortem EventGenerator::ieve value comes from the native core. Each job
uses an existing production worker slot before that worker starts its next seed.
"""
import concurrent.futures
import fcntl
import json
import math
import shutil
from pathlib import Path
import re
import time

import numpy as np
from extract import package
from worker import HERE, CARD, BINARY, ANALYZER_SHA, digest, run_logged


def generate(idx, bad, part, n):
    base=HERE/"recovery"/f"{idx:04d}"
    original=HERE/"shards"/f"{idx:04d}"
    original_seed=19000000+101*idx
    # Disjoint recovery/diagnostic namespaces; range is independent of physics outcome.
    seeds={"prefix":original_seed, "continuation":32000000+idx*211, "independent_control":42000000+idx*211}
    sampler=base/"sampler_interruption.json"
    late_decay=base/"late_decay_replacement.json"
    zero_weight_events=int(not (sampler.is_file() or late_decay.is_file()))
    sizes={"prefix":bad-1,"continuation":n-bad+1-zero_weight_events,"independent_control":n}
    seed, size=seeds[part],sizes[part]
    run=base/part
    run.mkdir(exist_ok=True, parents=True)
    (run/"events").mkdir(exist_ok=True)
    output=run/"spectrum.json"
    if not output.exists():
        if part=="prefix":
            shutil.copy2(original/"minbias.run",run/"minbias.run")
            shutil.copy2(original/"minbias.in",run/"minbias.in")
        else:
            (run/"minbias.in").write_text(CARD.read_text().replace("RandomNumberGenerator:Seed 931025", f"RandomNumberGenerator:Seed {seed}").replace("EventGenerator:NumberOfEvents 10000",f"EventGenerator:NumberOfEvents {size}"))
            run_logged(["Herwig","read","minbias.in"],run,"read.log")
        run_logged(["Herwig","run","minbias.run",f"-N{size}"],run,"run.log")
        run_logged([str(BINARY),"--dijet-bound",str(run/"events/minbias.root"),"moments.csv",str(seed+100),"pairs.csv"],run,"response.log")
        d=package(run,seed,size)
        d.update(analyzer_sha256=digest(BINARY), card_sha256=digest(run/"minbias.in"),
                 source_root_sha256=digest(run/"events/minbias.root"), source_generator_output_sha256=digest(run/"minbias.out"),
                 detector_pairs_sha256=digest(run/"pairs.csv"))
        if part=="prefix":
            # Native warnings include decay details and event indices. Match all
            # complete diagnostic lines before the earlier process aborted.
            log0=(original/"minbias.log").read_text(errors="replace").splitlines()
            log1=(run/"minbias.log").read_text(errors="replace").splitlines()
            def event_warnings(lines):
                return [s for s in lines if re.search(r' in event [0-9]+',s)]
            a,b=event_warnings(log0),event_warnings(log1)
            if min(len(a),len(b))<3 or a[:min(len(a),len(b))-1]!=b[:min(len(a),len(b))-1]:
                raise ValueError("Replay warnings/indices disagree with original")
            d["verified_common_native_diagnostic_lines"]=min(len(a),len(b))-1
        tmp=output.with_suffix(".tmp")
        tmp.write_text(json.dumps(d,separators=(",",":")));tmp.replace(output)
    with (base/"combine.lock").open("w") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        if not all((base/k/"spectrum.json").is_file() for k in ("prefix","continuation")): return
        primary=json.loads((base/"prefix/spectrum.json").read_text())
        continuation=json.loads((base/"continuation/spectrum.json").read_text())
        parts=[primary,continuation]
        proof_path=base/"kinematics_auto.json"
        if not zero_weight_events: proof_path=sampler if sampler.is_file() else late_decay
        if not proof_path.is_file(): proof_path=base/"kinematics.json"
        proof=json.loads(proof_path.read_text())
        if zero_weight_events and (proof["shard"]!=idx or proof["failed_event_1based"]!=bad or
                proof["double_fake_rate_contribution_fb"]!=0 or proof["sum_transverse_masses_gev"]>=20):
            raise ValueError("Missing per-event proof that the interrupted source has zero detector weight")
        if not zero_weight_events and (proof["shard"]!=idx or proof["pending_request_1based"]!=bad or 
                proof["position_receipt_sha256"]!=digest(base/"position.log")):
            raise ValueError("Native sampler classification disagrees with its event position")
        out=original/"spectrum.json"
        assert sum(s['generated_events'] for s in parts)==n-zero_weight_events
        def comb(key,exp):
            return sum((s['generated_events']/n)**exp * np.array(s[key]) for s in parts).tolist()
        actual=set(sum(([s["generator_seed"],s["response_seed"]] for s in parts),[]))
        assert len(actual)==4
        total=dict(sample="bkg_dijet_double_fake",independent_id=f"inclusive_minbias_seed_{original_seed}_with_documented_continuation",
                   generated_events=n, completed_native_events=n-zero_weight_events, zero_response_native_aborts=zero_weight_events,
                   interrupted_sampler_proposals=int(sampler.is_file()),
                   independently_replaced_native_decays=int(late_decay.is_file()),
                   generator_seed=original_seed,response_seed=original_seed+100,
                   auxiliary_generator_seeds=[continuation["generator_seed"]],auxiliary_response_seeds=[continuation["response_seed"]],
                   sigma_nb=sum(s["sigma_nb"]*s["generated_events"]/(n-zero_weight_events) for s in parts),
                   edges_gev=list(range(105,161)),fit_range_sources=sum(s['fit_range_sources'] for s in parts),
                   fit_range_pairs=sum(s['fit_range_pairs'] for s in parts),
                   rate_fb=comb('rate_fb',1),covariance_fb2=comb('covariance_fb2',2),
                   lower_endpoint_rate_fb=comb('lower_endpoint_rate_fb',1),lower_endpoint_covariance_fb2=comb('lower_endpoint_covariance_fb2',2),
                   analyzer_sha256=ANALYZER_SHA, abort_1based_event_index=bad,
                   position_receipt_sha256=digest(base/"position.log"),
                   native_interruption_proof_sha256=digest(proof_path),
                   components={k:{"path":str((base/k/"spectrum.json").relative_to(HERE)),"sha256":digest(base/k/"spectrum.json"),
                                  "seed":seeds[k],"size":sizes[k]} for k in ("prefix","continuation")})
        tmp=out.with_suffix(".tmp")
        tmp.write_text(json.dumps(total,separators=(",",":"))+"\n"); tmp.replace(out)
        # The independent full-size control is diagnostic only.
        control=base/"independent_control/spectrum.json"
        if control.is_file():
            ctrl=json.loads(control.read_text())
            delta=np.array(ctrl["rate_fb"])-total["rate_fb"]
            cov=np.array(ctrl["covariance_fb2"])+total["covariance_fb2"]
            comparison=dict(rate_shift_fb=delta.tolist(),covariance_fb2=cov.tolist(),control_seed=seeds["independent_control"],
                            integrated_fit_range_difference_fb=delta.sum(),integrated_fit_range_difference_mc_error_fb=math.sqrt(cov.sum()))
            (base/"replacement_comparison.json").write_text(json.dumps(comparison)+"\n")


def work_outstanding(first=0,stop=912):
    folder=HERE/"recovery_tasks"
    if not folder.exists(): return
    for task in sorted(folder.glob("*.json")):
        name=task.stem
        if not first<=int(name.split("_",1)[0])<stop:
            continue
        try:
            task.rename(folder/(name+".running"))
        except FileNotFoundError:
            continue
        try:
            d=json.loads((folder/(name+".running")).read_text())
            generate(**d)
        except Exception:
            import traceback
            (folder/(name+".error")).write_text(traceback.format_exc())
            return
        (folder/(name+".running")).rename(folder/(name+".done"))
        return
