"""Run each seed once, and record errors without hiding finished shards."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument("first", type=int)
p.add_argument("stop", type=int)
p.add_argument("events", type=int)
p.add_argument("workers", type=int)
args=p.parse_args()
def process(idx):
    log = root / "logs" / f"shard_{idx:04d}.log"
    (root / "logs").mkdir(exist_ok=True)
    with log.open("a") as stream:
        stream.write(f"Starting {time.asctime()}\n")
        stream.flush()
        code=subprocess.run([sys.executable,str(root/"worker.py"),str(idx),str(args.events)],stdout=stream,stderr=subprocess.STDOUT).returncode
    if code:
        print(f"FAILED shard {idx} at {time.asctime()}. See {log}.",flush=True)
    else:
        print(f"Completed {idx} at {time.asctime()}",flush=True)
    return code
print(args,time.asctime(),flush=True)
with ThreadPoolExecutor(args.workers) as pool:
    codes=list(pool.map(process, range(args.first,args.stop)))
print(f"Completed {codes.count(0)} of {len(codes)}",flush=True)
sys.exit(any(codes))
