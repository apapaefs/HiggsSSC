# Dijet double-fake production audit

The fit uses **46,920,000 physical source events** across the earlier 1,320,000 events and 912 new seeds of 50,000 events each. The new exposure is 45,600,000. Independent controls and conditional re-decays add zero exposure. Each seed uses its native inclusive cross section and all fake-pair contributions from a common source are grouped in its 55-bin covariance.

Every interrupted seed contributes exactly 50,000 requests to the fit. The last column gives the change in fitted 125 GeV Higgs strength when a separate 50,000-event control replaces that whole seed within the completed exposure. Its error comes from the two independent source samples.

| Shard | Original seed | Interrupted request | Replayed prefix + continuation | Continuation / control seed | Native accounting | Control shift in Higgs yields |
|---:|---:|---:|---:|---|---|---:|
| 43 | 19004343 | 31,784 | 31,783 + 18,216 | 32009073 / 42009073 | One accepted collision provably had zero dijet response | +0.00176 ± 0.00490 |
| 314 | 19031714 | 32,665 | 32,664 + 17,336 | 32066254 / 42066254 | One diffractive sampler trial interrupted before event acceptance | −0.00339 ± 0.00334 |
| 390 | 19039390 | 36,560 | 36,559 + 13,441 | 32082290 / 42082290 | One accepted collision interrupted during decay and was independently replaced | +0.00515 ± 0.00386 |
| 854 | 19086254 | 40,086 | 40,085 + 9,915 | 32180194 / 42180194 | One accepted collision interrupted during decay and was independently replaced. Its saved topology proves zero original double-fake weight | −0.00617 ± 0.00413 |
| 860 | 19086860 | 32,548 | 32,547 + 17,453 | 32181460 / 42181460 | One diffractive sampler trial interrupted before event acceptance | −0.00407 ± 0.00489 |

For source 390, request 36,560, the six unresolved hadrons were re-decayed 10,000 times with the other 595 particles fixed. All trials passed the momentum checks. The leading reconstructed transverse momentum was at most 17.23 GeV across these trials, below the 20 GeV photon threshold.

At the actual 46.92 million-event exposure, the one-sided 95% upper bound on the **expected** positive shift from this collision is 4.4e-05 Higgs yields for maximally mixed parents. Under the same normalized positive native decay law, allowing arbitrary joint parent spins gives an expected shift between −0.00072 and +0.0059 at 95% confidence. The spin dimension factor is 135. For an **individual possible decay outcome**, projecting onto the fit derivative gives deterministic shift bounds of −0.01775 and +0.14605 Higgs yields. That bound permits up to 75 fit-range pairs and uses GEM's largest in-range per-jet fake probability, 0.000385.

Source 854 has at most 1 eligible jet for any momentum-conserving decays of its 22 unfinished parents. The original source has exactly zero fit-range pair weight. Its prespecified independent replacement also contributes 0 fb across the fit range.

The pool has identity `new_minbias_pool_3b576ed168cb344d00a2`. The common fit checkpoint has SHA-256 `1284e76311bf9fd804f23994f16d6a362e161935514d1957a338bf16feb68ec9`. The per-source products, controls and original native process diagnostics are under `dijet/recovery` on Timur.
