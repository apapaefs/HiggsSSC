"""Project a rigorous bound for one undetermined late-decay event onto the mass fit."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys

import ROOT
import fastjet as fj
import numpy as np

base=Path(__file__).resolve().parent
sys.path.insert(0,str(base.parent/"fit"/"reference"))
from continuum_fit import ALL, EDGES, Shape

parser=argparse.ArgumentParser()
parser.add_argument("index",type=int)
parser.add_argument("--exposure",type=int,default=46920000)
parser.add_argument("--fit",type=Path,default=base.parent/"fit"/"latest_fit.json")
parser.add_argument("--geometry-only",action="store_true")
args=parser.parse_args()
folder=base/"recovery"/f"{args.index:04d}"
snapshot=folder/"event_data_stable.log"
if not snapshot.is_file(): snapshot=folder/"event_data_verified.log"
raw=snapshot.read_bytes()
state=json.loads(next(x.split("=",1)[1] for x in raw.decode().splitlines() if x.startswith("DECAY_PARTICLES=")))
rec=json.loads((folder/"late_decay_replacement.json").read_text())
if args.geometry_only:
    receipt={"response_seed":19000000+101*args.index+100}
else:
    receipt=json.loads((base/"shards"/f"{args.index:04d}"/"spectrum.json").read_text())
fitraw=args.fit.read_bytes()
fit=json.loads(fitraw)
b=np.array(fit["background_per_bin_fb"])
s=np.array(fit["signal_per_bin_fb"])
g=Shape("exponential",2).fit(b,ALL,s)[-1][-1]

def mix(x):
    mask=(1<<64)-1
    x=(x+0x9e3779b97f4a7c15)&mask
    x=((x^(x>>30))*0xbf58476d1ce4e5b9)&mask
    x=((x^(x>>27))*0x94d049bb133111eb)&mask
    return x^(x>>31)

def gaussian(kind,index):
    after=receipt["response_seed"]
    event=rec["pending_request_1based"]-1
    value=mix(after)^mix(event+0x100000001b3)^mix((kind<<32)^index)
    seed=(mix(value)&0xffffffff) or 1
    return ROOT.TRandom3(seed).Gaus(0.,1.)

# For an E-scheme merge at |dy|<=R, mT'² <= (a+b)² + 2ab(coshR-1).
# With x=a/(a+b), ln[mT'/(a+b)] <= (coshR-1)x(1-x).
# Jensen gives ln[||(a,b)||p/(a+b)] >= (1/p-1) H(x). With u=2x-1,
# H(x)=ln(2)-sum u^(2k)/(2k(2k-1)). The coefficients sum to ln(2)
# and u^(2k)<=u², giving H(x)>=4ln(2)x(1-x), hence mT'^p<=a^p+b^p.
q=1/(1+(math.cosh(.4)-1)/(4*math.log(2)))
native_scalar=power_sum=0.
stable_inputs=unknown_parents=0
for entry in state:
    px,py,pz,energy,mass=entry["momentum_gev"]
    pt=math.hypot(px,py)
    mt=math.hypot(pt,mass)
    if entry["stable"]:
        if (pt<=.4 or abs(math.asinh(pz/pt))>=6 or abs(entry["particle_id"]) in (12,14,16)):
            continue
        stable_inputs+=1
        native_scalar+=pt
        power_sum+=mt**q
    else:
        unknown_parents+=1
        # No possible daughter with pT>0.4 and |eta|<6 if the parent's
        # smaller beam light-cone component is below 0.4 exp(-6).
        if energy-abs(pz)<.4*math.exp(-6): continue
        count=math.floor(mt/.4)
        if count:
            native_scalar+=mt
            power_sum+=count**(1-q)*mt**q
# The optional flavour ghosts have pT 1e-15 GeV. The loose additive
# margin is many orders larger and guards numerical rounding at any floor.
native_count=math.floor((native_scalar+1.e-4)/10.)
z=max(0.,*(gaussian(kind,i) for kind in (30,31) for i in range(native_count)))
pileup=.120+.366*(2.5-1.4)
noise=math.hypot(.175,pileup)
rel=math.sqrt(.085**2/10.+.004**2+(noise/10.)**2)
# E/cosh(eta) <= sqrt(E²-pz²)=mT. The known seeded smearing is at most
# 1+z*rel at reconstructed |eta|<2.5. Every eligible photon has pT >=20.
t=20./(1+z*rel)
eligible=min(native_count,math.floor((power_sum+1.e-4)/t**q))
# Each detector draw belongs to exactly one stored jet. For each possible
# b/non-b split, minimize the cost in the additive mT^q budget over which jets
# qualify. This also respects the native cap on the sum of both multiplicities.
distinct=0
for nb in range(native_count+1):
    draws=[gaussian(30,i) for i in range(native_count-nb)] + [gaussian(31,i) for i in range(nb)]
    costs=sorted((20./(1+max(0.,v)*rel))**q for v in draws)
    distinct=max(distinct,int(np.sum(np.cumsum(costs)<=power_sum+1.e-4)))
eligible=min(eligible,distinct)
# For massless reconstructed candidates of the same eta sign, |deta|<2.4.
# If both have pT < 105/(2*cosh(1.2)), their pair cannot reach 105 GeV.
high_pt=105./(2*math.cosh((2.5-.1)/2))
pair_bounds={}
for count in range(2,eligible+1):
    high=0
    for num in range(1,count+1):
        cost=(count-num)*t**q+num*(high_pt/(1+z*rel))**q
        if cost<=power_sum+1.e-4: high=num
    low=count-high
    # The fewest forbidden pairs occurs when low-pT jets split evenly in sign.
    forbidden=math.comb(low//2,2)+math.comb((low+1)//2,2)
    pair_bounds[count]=math.comb(count,2)-forbidden
pairs=max(pair_bounds.values(),default=0)
def inspect_partial_state(freeze):
    constituents=[]
    for row in state:
        if not row["stable"] and not freeze: continue
        px,py,pz,e,_=row["momentum_gev"]
        p=fj.PseudoJet(px,py,pz,e)
        if p.pt()<=.4 or abs(p.eta())>=6 or abs(row["particle_id"]) in (12,14,16): continue
        if abs(row["particle_id"]) in (11,13,22) and p.pt()>10: continue
        constituents.append(p)
    clusters=fj.ClusterSequence(constituents,fj.JetDefinition(fj.antikt_algorithm,.4))
    jets=clusters.inclusive_jets(10.)
    pts=[j.e()/math.cosh(j.eta())*(1+z*rel) for j in jets if .1<abs(j.eta())<2.5 and not 1.01<abs(j.eta())<1.16]
    return {"n_native_jets":len(jets),"n_potentially_eligible":sum(x>=20 for x in pts),
            "largest_central_reconstructed_pt_bound_gev":max(pts,default=0.)}
fq=np.interp(EDGES[:-1],[80,100,120,140,160],[4.1e-4,3.9e-4,3.7e-4,3.6e-4,3.4e-4])
if args.geometry_only:
    print(json.dumps(dict(native_scalar=native_scalar,eligible=eligible,pairs=pairs,power_sum=power_sum,
                          threshold_mT=t,draws=z,stable_inputs=stable_inputs,undecayed=unknown_parents)))
    raise SystemExit(0)
sources=[json.loads((folder/k/"spectrum.json").read_text())["sigma_nb"] for k in ("prefix","continuation")]
factor=max(sources)*1.e6/args.exposure
unit=pairs*factor
out=dict(index=args.index,exposure=args.exposure,source_sigma_nb_upper_of_observed_native_components=max(sources),
         native_particles=len(state),stable_particles_passing_constituent_cuts=stable_inputs,
         unstable_parents=unknown_parents,native_input_scalar_pt_bound_gev=native_scalar,
         native_jet_count_bound=native_count,maximum_seeded_standard_normal=z,
         maximum_fractional_energy_rms=rel,eligible_jet_minimum_mT_gev=t,
         anti_kt_aggregation_power=q,upper_bound_on_sum_of_input_mT_power=power_sum,
         eligible_jet_count_bound=eligible,fit_mass_range_pair_count_bound=pairs,
         same_sign_eta_low_pt_cut_for_105_GeV_mass_gev=high_pt,fit_pair_bounds_by_eligible_count=pair_bounds,
         maximum_fake_probability_per_jet_in_fit_range=fq.max(),
         rigorous_full_mass_range_rate_bound_fb=unit*np.max(fq**2),
         linearized_lower_mu_shift=unit*min(0.,min(fq**2*g)),
         linearized_upper_mu_shift=unit*max(0.,max(fq**2*g)),
         minimum_fit_derivative_per_fb=g.min(),maximum_fit_derivative_per_fb=g.max(),
         illustrative_partial_state_no_undecayed_parents=inspect_partial_state(False),
         illustrative_partial_state_frozen_parents=inspect_partial_state(True),
         fit_sha256=hashlib.sha256(fitraw).hexdigest(),particle_trace_sha256=hashlib.sha256(raw).hexdigest(),
         interpretation="A bound on an unknown original event at the nominal quadratic log continuum fit derivative, with all potentially eligible pairs placed in the most adverse bins. The physical normalization uses the larger of the measured component cross sections. The two real independently generated possible replacement sources are counted separately in the full-shard comparison.")
result=folder/f"saved_event_bound_{args.exposure}.json"
result.write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out,indent=2))
