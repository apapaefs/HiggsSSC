"""Recluster the saved 595 particles with native daughters of six fixed parents."""
import argparse
import hashlib
import json
import math
from pathlib import Path

import fastjet as fj
import numpy as np
from scipy.stats import beta

here=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument("index",type=int)
p.add_argument("seeds",nargs="+",type=int)
p.add_argument("--draws-per-seed",type=int,default=2500)
p.add_argument("--exposure",type=int,default=46920000)
a=p.parse_args()
folder=here/"recovery"/f"{a.index:04d}"
particles=json.loads(next(l.split("=",1)[1] for l in (folder/"event_data_stable.log").read_text().splitlines() if l.startswith("DECAY_PARTICLES=")))
bound=json.loads((folder/f"saved_event_bound_{a.exposure}.json").read_text())
factor=1+bound["maximum_seeded_standard_normal"]*bound["maximum_fractional_energy_rms"]
definition=fj.JetDefinition(fj.antikt_algorithm,.4)
def native_input(pid,px,py,pz,e):
    item=fj.PseudoJet(px,py,pz,e)
    if item.pt()<=.4 or abs(item.eta())>=6 or abs(pid) in (12,14,16): return None
    # No saved charged lepton has enough pT for the lepton isolation branch.
    if abs(pid) in (11,13) and item.pt()>10: raise ValueError("Check charged-lepton isolation")
    if abs(pid)==22 and item.pt()>10:return None
    return item
stable=[native_input(p["particle_id"],*p["momentum_gev"][:4]) for p in particles if p["stable"]]
stable=[p for p in stable if p is not None]
parent_momenta=np.array([p["momentum_gev"][:4] for p in particles if not p["stable"]])
eligible_one=eligible_pair=missing_draws=0
max_closure=max_leading=max_second=0.
streams=[]
for seed in a.seeds:
    directory=folder/"native_redecays"/str(seed)
    path=directory/"daughters.dat"
    draws=a.draws_per_seed
    parse_error=None
    if path.exists() and path.stat().st_size:
        try:
            data=np.loadtxt(path,ndmin=2)
        except ValueError as exc:
            parse_error=str(exc)
            data=np.empty((0,8))
    else:
        data=np.empty((0,8))
    if data.shape[1]!=8 or np.any(~np.isfinite(data)):raise ValueError("Nonfinite or malformed native records")
    if np.any(data[:,0]<0) or np.any(data[:,0]>=draws) or np.any(np.diff(data[:,0])<0):
        raise ValueError("Unexpected draw identifiers")
    summed=np.zeros((draws,len(parent_momenta),4))
    np.add.at(summed,(data[:,0].astype(int),data[:,1].astype(int)),data[:,3:7])
    residual=np.max(np.abs(summed-parent_momenta),axis=(1,2))
    valid=residual<=.02
    # A crash, truncated trial or bad momentum record is conservatively counted
    # as a possible fit-range pair, including all prespecified draws left unrun.
    missing=int(np.count_nonzero(~valid))
    diff=float(max(residual[valid],default=0.))
    max_closure=max(max_closure,diff)
    intervals=np.searchsorted(data[:,0],np.arange(draws+1))
    stream_pairs=0
    for i,(begin,end) in enumerate(zip(intervals[:-1],intervals[1:])):
        if not valid[i]: continue
        inputs=stable.copy()
        for row in data[begin:end]:
            item=native_input(int(row[2]),*row[3:7])
            if item is not None: inputs.append(item)
        cluster=fj.ClusterSequence(inputs,definition)
        central=[j.e()/math.cosh(j.eta())*factor for j in cluster.inclusive_jets(10.)
                 if .1<abs(j.eta())<2.5 and not 1.01<abs(j.eta())<1.16]
        central=sorted(central,reverse=True)+[0.,0.]
        max_leading=max(max_leading,central[0])
        max_second=max(max_second,central[1])
        eligible_one+=central[0]>=20
        stream_pairs+=central[1]>=20
    eligible_pair+=stream_pairs
    missing_draws+=missing
    streams.append({"generator_seed":seed,"draws":draws,"native_daughters":len(data),
                    "max_parent_four_momentum_residual_gev":diff,"draws_with_two_possible_candidates":stream_pairs,
                    "missing_or_invalid_draws_counted_as_successes":missing,"parse_error":parse_error,
                    "native_output_sha256":hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None})
total=len(streams)*a.draws_per_seed
effective_successes=eligible_pair+missing_draws
upper=float(beta.ppf(.95,effective_successes+1,total-effective_successes)) if effective_successes<total else 1.
dimensions={9000111:1,-10215:5,213:3,223:3,111:1,113:3}
if sorted(p["particle_id"] for p in particles if not p["stable"])!=sorted(dimensions):raise ValueError("Unexpected native set of parents")
spin_dimension=math.prod(dimensions.values())
arbitrary_spin_upper=min(1.,spin_dimension*upper)
out={"physical_collision_count":1,"source_index_1based":36560,"stable_particles_fixed":595,
     "dijet_exposure_including_reference":a.exposure,"fit_sha256":bound["fit_sha256"],
     "native_parent_decays_drawn_per_trial":6,"native_decay_trials":total,
     "conditioning":"Use saved post-hadronization PDG identities, virtual masses and four-momenta, with the earlier 595 stable particles fixed. Each fresh parent has no prior production spin-density information. Herwig 7.3.0 HwDecayHandler::performDecay uses the original decay modes, decay matrix elements, daughter spin information and radiation configuration.",
     "detector":"Recluster each trial with the production native constituent filters and anti-kt R=0.4. Bound the SSC pT of every surviving central jet using the largest possible detector draw across all allowed light/b-jet indices of this exact collision. This overestimates the number of candidates.",
     "max_parent_four_momentum_residual_gev":max_closure,
     "draws_with_one_or_more_possible_candidates":eligible_one,
     "draws_with_two_or_more_possible_candidates":eligible_pair,
     "missing_or_invalid_draws_counted_as_successes":missing_draws,
     "max_leading_reconstructed_pt_bound_gev":max_leading,"max_second_reconstructed_pt_bound_gev":max_second,
     "conditional_pair_occupancy_95pct_upper":upper,
     "conditional_expected_positive_mu_shift_95pct_upper_at_planned_exposure":upper*bound["linearized_upper_mu_shift"],
     "conditional_expected_negative_mu_shift_abs_95pct_upper_at_planned_exposure":upper*abs(bound["linearized_lower_mu_shift"]),
     "native_spin_dimensions_2J_plus_1":dimensions,
     "positive_decay_law_dimension_bound":spin_dimension,
     "arbitrary_joint_spin_pair_occupancy_95pct_upper":arbitrary_spin_upper,
     "arbitrary_joint_spin_positive_mu_shift_95pct_upper_at_planned_exposure":arbitrary_spin_upper*bound["linearized_upper_mu_shift"],
     "arbitrary_joint_spin_negative_mu_shift_abs_95pct_upper_at_planned_exposure":arbitrary_spin_upper*abs(bound["linearized_lower_mu_shift"]),
     "arbitrary_spin_assumption":"Fresh massive vector and tensor parents have I/(2J+1) in ThePEG, with original width and branching fractions. For the same positive normalized decay law, any joint spin density matrix satisfies rho <= 135 times the maximally mixed product. Thus every positive acceptance probability is bounded by 135 times its estimate for the mixed state.",
     "streams":streams,"fit_exposure_policy":"The independent continuation enters the physical spectrum. All re-decays probe a single source and enter neither Poisson exposure nor independent-source fit covariance."}
dest=folder/("conditional_native_decay_sensitivity.json" if total>=10000 else "conditional_decay_smoke.json")
dest.write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out,indent=2))
