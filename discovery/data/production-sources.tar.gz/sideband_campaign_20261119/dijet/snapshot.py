"""Publish a compact aggregate snapshot whenever another complete seed arrives."""
import json
from pathlib import Path
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
waves_only="--complete-waves" in sys.argv[1:]
previous=None
while True:
    shards=tuple(sorted(str(x.parent.name) for x in (root/"shards").glob("*/spectrum.json")))
    if shards and shards!=previous:
        subprocess.run([sys.executable, str(root/"pool.py")] + (["--complete-waves"] if waves_only else []),check=True)
        previous=shards
    logs=[root/"dispatch.log", root/"dispatch_idle.log"]
    third_done=(not (root/"third_wave.active").is_file()) or (root/"third_wave.done.json").is_file()
    if third_done and all(log.is_file() and any(s.startswith("Completed ") and " of " in s for s in log.read_text().splitlines()) for log in logs):
        break
    time.sleep(45)
