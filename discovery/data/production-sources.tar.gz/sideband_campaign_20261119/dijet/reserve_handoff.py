"""Widen only the existing idle scheduler's affinity once primary seeds close."""
import json
import os
from pathlib import Path
import time

root=Path(__file__).resolve().parent
while not all((root/'shards'/f'{i:04d}'/'spectrum.json').exists() for i in range(504)):
    time.sleep(10)
pid=1598808
mask=set(range(18,38))|set(range(58,78))|set(range(12))|set(range(40,52))
expected=['504','624','50000','12']
changed=set()
for _ in range(3):
    process=Path(f'/proc/{pid}')
    if not process.exists(): break
    command=process.joinpath('cmdline').read_bytes().rstrip(b'\0').decode().split('\0')
    if command[-4:]!=expected or Path(command[-5]).name!='dispatch.py':
        raise RuntimeError('Reserve dispatcher identity changed')
    pending=[pid]
    while pending:
        parent=pending.pop()
        try: threads=list(Path(f'/proc/{parent}/task').iterdir())
        except FileNotFoundError: continue
        for thread in threads:
            tid=int(thread.name)
            try:
                if os.sched_getscheduler(tid)!=os.SCHED_IDLE: raise ValueError(f'Unexpected class on {tid}')
                os.sched_setaffinity(tid,mask)
                if os.sched_getaffinity(tid)!=mask: raise ValueError(f'Invalid affinity on {tid}')
                pending.extend(map(int,(thread/'children').read_text().split()))
                changed.add(tid)
            except (ProcessLookupError,FileNotFoundError): pass
    time.sleep(1)
(root/'reserve_handoff.json').write_text(json.dumps({"time_unix":time.time(),"dispatcher_pid":pid,
     "scheduler":"SCHED_IDLE", "affinity":sorted(mask),"updated_thread_ids":sorted(changed)},indent=2)+'\n')
