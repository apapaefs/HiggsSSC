"""Feed independent hard-event parents to small disjoint CPU teams on Timur."""
from collections import Counter
import fcntl
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
CAMPAIGN=HERE.parent
READY=CAMPAIGN/'ready/nlo'
STOP=CAMPAIGN/'fit/TARGET_REACHED.json'
MODES=('prompt','gammaj')
POLL_SECONDS=15


def read(path):
    return json.loads(path.read_text())


def write(path,value):
    tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n')
    tmp.replace(path)


def cpus(text):
    result=set()
    for item in text.strip().split(','):
        nums=list(map(int,item.split('-')))
        result.update(range(nums[0],nums[-1]+1))
    return result


def lives(pid,tag):
    try:
        cmd=Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\x00')
        return b'run' in cmd and tag.encode() in cmd and any(s.endswith(b'produce.py') for s in cmd)
    except (FileNotFoundError,PermissionError,ProcessLookupError):
        return False


def tasks():
    return {p.stem:read(p) for p in sorted((HERE/'requests').glob('sb20_*.json'))}


def main():
    owner=(HERE/'farm.lock').open('a')
    fcntl.flock(owner,fcntl.LOCK_EX|fcntl.LOCK_NB)
    for directory in (HERE/'requests',HERE/'logs',HERE/'leases',HERE/'work',HERE/'parents',READY):
        directory.mkdir(parents=True,exist_ok=True)
    allowed_os=set(os.sched_getaffinity(0))
    if not (HERE/'cpu_at_start.json').exists():
        write(HERE/'cpu_at_start.json',sorted(allowed_os))
    verified=subprocess.run([sys.executable,str(HERE/'produce.py'),'verify'],check=True)
    handles={}
    active={}
    last_state=None
    for lease in (HERE/'leases').glob('*.json'):
        row=read(lease)
        if lives(row['pid'],lease.stem):
            active[lease.stem]=row
    while True:
        now=time.time()
        completed={m:0 for m in MODES}
        allocated={m:0 for m in MODES}
        todo=tasks()
        for tag,request in todo.items():
            mode,n=request['mode'],request['events']
            allocated[mode]+=n
            if (READY/(tag+'.json')).is_file():
                completed[mode]+=n
        for tag,row in list(active.items()):
            if tag in handles:
                done=handles[tag].poll() is not None
            else:
                done=not lives(row['pid'],tag)
            if not done:
                continue
            if not (READY/(tag+'.json')).is_file():
                failures=read(HERE/'failures.json') if (HERE/'failures.json').is_file() else {}
                failure=failures.setdefault(tag,{'count':0})
                failure.update(count=failure['count']+1,last_failure=now)
                write(HERE/'failures.json',failures)
                print(time.ctime(),'worker exited before closure',tag,'see logs/'+tag+'.log',flush=True)
            active.pop(tag)
            handles.pop(tag,None)
        # The PID lease is independent of the scheduler to allow a safe supervisor restart.
        # A failure with an archived but incomplete request is resumed in the same directory.
        requested=cpus((HERE/'cpus.txt').read_text())
        if not requested <= allowed_os:
            raise ValueError(f'Assigned mask outside available CPUs: {requested-allowed_os}')
        busy={cpu for data in active.values() for cpu in data['cpus']}
        free=sorted(requested-busy,key=lambda c:(c%40,c//40))
        goals=read(HERE/'targets.json')
        if set(goals)!=set(MODES) or any(type(v) is not int or v < 0 for v in goals.values()):
            raise ValueError('Invalid additional-event targets')
        failed=read(HERE/'failures.json') if (HERE/'failures.json').exists() else {}
        def may_retry(tag):
            entry=failed.get(tag,{})
            return entry.get('count',0)<3 and now-entry.get('last_failure',0)>60
        incomplete=[tag for tag in todo if not (READY/(tag+'.json')).exists() and tag not in active]
        blocked=[tag for tag in incomplete if not may_retry(tag)]
        resume=[tag for tag in incomplete if may_retry(tag)]
        stop=STOP.exists()
        disk_free=shutil.disk_usage(HERE).free / (1<<30)
        # A new 250k parent needs <4 GiB at peak including the authenticated response.
        # Scratch is released on verified closure; a 25 GiB minimum protects unrelated files.
        while free and (resume or not stop):
            if len(free)<3 and active:
                break
            if resume:
                tag=resume.pop(0)
            else:
                eligible=[m for m in MODES if allocated[m]<goals[m]]
                if not eligible or disk_free < 32 + 4*(1+len(active)):
                    break
                mode=min(eligible,key=lambda m:allocated[m]/goals[m])
                indices=[r['index'] for r in todo.values() if r['mode']==mode]
                index=max(indices,default=0)+1
                if index>=1500:
                    raise ValueError('Reserved independent hard/shower seed space exhausted')
                tag=f'sb20_{mode}_{index:06d}'
                n=min(20000 if index==1 else 250000,goals[mode]-allocated[mode])
                request=dict(mode=mode,index=index,events=n)
                write(HERE/'requests'/(tag+'.json'),request)
                todo[tag]=request
                allocated[mode]+=n
            # Six hardware threads per team amortize the serial MG5 collection phase.
            lanes=free[:6] if len(free)>8 else list(free)
            free=free[len(lanes):]
            with (HERE/'logs'/(tag+'.log')).open('ab') as logfile:
                cmd=['taskset','-c',','.join(map(str,lanes)),sys.executable,str(HERE/'produce.py'),'run',tag]
                proc=subprocess.Popen(cmd,stdout=logfile,stderr=subprocess.STDOUT)
            row={'pid':proc.pid,'cpus':lanes,'started':now}
            active[tag]=row
            handles[tag]=proc
            write(HERE/'leases'/(tag+'.json'),row)
            print(time.ctime(),'started',tag,todo[tag]['events'],'cpus',lanes,flush=True)
        status='running'
        if not active and not incomplete and stop:
            status='drained_after_target'
        elif not active and not incomplete and all(completed[m]>=goals[m] for m in MODES):
            status='finished'
        progress=dict(status=status,pid=os.getpid(),updated_unix=now,active=active,completed=completed,
                      allocated=allocated,targets=goals,assigned_cpus=sorted(requested),free_GiB=disk_free,
                      blocked_requests=blocked,stop_requested=stop)
        write(HERE/'progress.json',progress)
        if status!=last_state:
            print(time.ctime(),status,completed,flush=True)
            last_state=status
        if status=='drained_after_target':
            return
        time.sleep(POLL_SECONDS)


if __name__=='__main__':
    main()
