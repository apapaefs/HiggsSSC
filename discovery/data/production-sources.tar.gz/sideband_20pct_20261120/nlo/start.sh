#!/usr/bin/env bash
set -eo pipefail
source /etc/profile.d/modules.sh
module load herwig/stable
export PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
cd /home/apapaefs/HiggsSSC/inputs/pipeline/sideband_20pct_20261120/nlo
exec /home/apapaefs/HiggsSSC/inputs/pipeline/venv/bin/python farm.py
