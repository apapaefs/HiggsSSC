"""One independent MG5/HERWIG parent and its summed signed-weight SSC spectrum."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
from types import SimpleNamespace

import numpy as np

HERE = Path(__file__).resolve().parent
CAMPAIGN = HERE.parent
SCRATCH = HERE / 'work'
ARCHIVE = HERE / 'parents'
READY = CAMPAIGN / 'ready/nlo'
LEGACY = CAMPAIGN.parent / 'sideband-20261119/nlo'
sys.path.insert(0, str(LEGACY))
import archive_shower as response
import grid_waves as grids

SAMPLES = {'prompt': 'bkg_prompt_aa', 'gammaj': 'bkg_gamma_j'}
BASE = {'prompt': 231000000, 'gammaj': 234000000}


def read(path):
    return json.loads(path.read_text())


def combine(folder, base):
    receipts = sorted(folder.glob('shard_*/receipt.json'))
    n = base['lhe']['events']
    total = signed = 0
    rates = np.zeros(55)
    cov = np.zeros((55, 55))
    retry_seeds = []
    for path in receipts:
        r = read(path)
        size = r['generated_events']
        if (r['first_source'] != total or r['last_source_exclusive'] != total + size
                or r['parent_events'] != n or r['parent_source'] != base['lhe']['source']
                or r['global_denominator'] != n-2*base['lhe']['negative_events']
                or r['shower_completion']['attempted_events'] != size):
            raise ValueError(f'Inconsistent finite shower coverage/normalization in {path}')
        total += size
        signed += r['signed_source_sum']
        rates += np.asarray(r['rate_fb']) * (size / n)
        cov += np.asarray(r['covariance_fb2']) * (size / n)**2
        if r.get('shower_retries'):
            retry_seeds.append({k:r[k] for k in ('first_source','last_source_exclusive','seed','shower_retries')})
    if (not receipts or total != n or signed != n-2*base['lhe']['negative_events']
            or not np.all(np.isfinite(rates)) or not np.all(np.isfinite(cov))
            or not np.allclose(cov, cov.T) or np.linalg.eigvalsh(cov).min() < -1.e-9 * max(1.0, cov.max())):
        raise ValueError(f'Invalid signed spectrum from {folder}')
    return rates, cov, signed, len(receipts), retry_seeds


def verify_reference():
    ready = CAMPAIGN.parent / 'sideband_campaign_20261119/nlo_ready'
    for mode in SAMPLES:
        tag = f'sb19_{mode}_grid002'
        metadata = read(LEGACY / tag / 'campaign.json')
        rates, cov, signed, n, _ = combine(LEGACY / (tag+'_response'), metadata)
        published = read(ready / (tag+'.json'))
        assert np.array_equal(rates, published['rate_fb']) and np.array_equal(cov, published['covariance_fb2'])
        assert signed == published['provenance']['source_signed_denominator'] and n == published['provenance']['complete_shards']
        print('Verified byte-equivalent 55-bin spectrum and covariance for', tag, metadata['lhe']['events'], flush=True)


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    response.put(path, value)


def hardlink(src, dst):
    if dst.exists():
        if not os.path.samefile(src, dst):
            raise RuntimeError(f'Archive collision {dst}')
    else:
        os.link(src, dst)


def preserve(tag, base, folder):
    """Keep the native gzip LHE and weighted SSC candidate trees for future analyses."""
    dest = ARCHIVE/tag
    dest.mkdir(parents=True, exist_ok=True)
    wd = SCRATCH/tag
    src = Path(base['lhe']['source'])
    hardlink(src, dest/'events.lhe.gz')
    for name in ('campaign.json','generator.log'):
        hardlink(wd/name, dest/name)
    for card in ('proc_card_mg5.dat','run_card.dat','param_card.dat','shower_card.dat','amcatnlo_configuration.txt'):
        hardlink(wd/'mg5_process/Cards'/card, dest/card)
    for p in src.parent.glob('*'):
        if p.is_file() and (p.name in ('summary.txt','RunMaterial.tar.gz') or p.name.endswith('_banner.txt')):
            hardlink(p, dest/p.name)
    for shard in sorted(folder.glob('shard_*')):
        sub = dest/shard.name
        sub.mkdir(exist_ok=True)
        for p in shard.iterdir():
            if p.is_file() and (p.name in ('receipt.json','shower_execution.json','retry_state.json','run.log','analysis.log') or p.name.endswith(('_var.root','.dat','.in'))):
                hardlink(p, sub/p.name)
        if not list(sub.glob('*_var.root')) or not (sub/'receipt.json').is_file():
            raise RuntimeError(f'Missing weighted SSC output: {sub}')
    return dest


def release(tag, packet):
    """Only disposable per-parent directories belonging to this new run can be removed."""
    if HERE.name != 'nlo' or CAMPAIGN.name != 'sideband_20pct_20261120' or not re.fullmatch(r'sb20_(prompt|gammaj)_\d{6}', tag):
        raise ValueError(f'Unexpected scratch owner for {tag}')
    dest = ARCHIVE/tag
    disk_lhe = dest/'events.lhe.gz'
    if (not disk_lhe.is_file() or disk_lhe.stat().st_size != read(dest/'campaign.json')['lhe']['source_size']
            or packet['provenance']['archived_parent_lhe'] != str(disk_lhe)
            or packet['provenance']['complete_shards'] != len(list(dest.glob('shard_*/receipt.json')))):
        raise RuntimeError('Cannot recover complete archive for published parent')
    for suffix in ('', '_response'):
        leaf = SCRATCH/(tag+suffix)
        if leaf.parent != SCRATCH or leaf.is_symlink():
            raise ValueError(f'Unsafe scratch directory {leaf}')
        if leaf.is_dir():
            shutil.rmtree(leaf)


def produce(tag):
    request = read(HERE/'requests'/(tag+'.json'))
    mode, index, n = (request[k] for k in ('mode','index','events'))
    if tag != f'sb20_{mode}_{index:06d}' or not 1 <= index < 1500 or not 0 < n <= 250000:
        raise ValueError(f'Invalid parent request {request!r}')
    sample = SAMPLES[mode]
    seed = BASE[mode] + 1000*index
    shower_seed = seed + 20000000
    available = sorted(os.sched_getaffinity(0))
    mask = ','.join(map(str,available))
    lock = (HERE/'requests'/(tag+'.lock')).open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    output = READY/(tag+'.json')
    if output.exists():
        release(tag,read(output))
        return
    grids.ROOT = SCRATCH
    grids.cpus = lambda _: (mask, len(available))
    previous = {read(p)['first_event_sha256'] for p in ARCHIVE.glob('*/campaign.json') if p.parent.name != tag}
    manifest, first = grids.hard(mode,tag,seed,n,response.OLD/sample,previous)
    base = read(manifest)
    if base['lhe']['events'] != n or first in previous or base['seed'] != seed:
        raise ValueError(f'Hard-parent identity/count mismatch for {tag}')
    cfg = SimpleNamespace(tag=tag+'_response', sample=sample, seed=shower_seed, lhe=base['lhe']['source'], shard=5000)
    wd = SCRATCH/cfg.tag
    wd.mkdir(exist_ok=True)
    denom = n-2*base['lhe']['negative_events']
    avg = base['lhe']['sum_abs_weight']/n
    if denom <= 0 or abs(avg-base['lhe']['sum_weight']/denom)>5.e-6*avg:
        raise ValueError('Expected equal absolute native MC@NLO source weights')
    with ThreadPoolExecutor(max_workers=len(available)) as pool:
        futures = [pool.submit(response.work,piece,cfg,base,denom,n) for piece in response.chunks(Path(cfg.lhe),wd,cfg.shard)]
        if sum(f.result() for f in futures) != n:
            raise ValueError('Incomplete finite-source shower')
    rates,cov,signed,nshards,retries = combine(wd,base)
    dest=preserve(tag,base,wd)
    digest=response.file_sha(dest/'events.lhe.gz')
    selection={'edges_gev':list(range(105,161)), 'rate_fb':rates.tolist(), 'covariance_fb2':cov.tolist()}
    packet=dict(**selection,sample=sample,stratum='full',independent_id=cfg.tag,seed=seed,
                generated_events=n,source_lhe_sha256=digest,
                provenance=dict(parent_lhe=str(dest/'events.lhe.gz'),archived_parent_lhe=str(dest/'events.lhe.gz'),
                                sha256=digest,first_event_sha256=first,hard_seed=seed,source_grid=base['source_grid'],
                                source_grid_seed=base['source_grid_seed'],shower_seed_start=shower_seed,
                                source_signed_denominator=signed,complete_shards=nshards,shard_directory=str(dest),
                                retry_seed_exceptions=retries,native_cross_section_pb=base['lhe']['cross_section_pb'],
                                native_cross_section_error_pb=base['lhe']['cross_section_error_pb'],matrix_element=base['process'],pdf=base['pdf']))
    save(output,packet)
    release(tag,read(output))
    print('Published',tag,n,'independent events, native SHA-256',digest,flush=True)


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation',choices=('verify','run'))
    parser.add_argument('tag',nargs='?')
    args=parser.parse_args()
    if args.operation=='verify':
        verify_reference()
    else:
        produce(args.tag)
