"""Run or recover one independently seeded 50,000-source dijet sample."""
import fcntl
import gzip
import os
import shutil
import json
from pathlib import Path
import subprocess
import sys
import time

import worker
from repair_slot import repair_one

repair_one()

base = Path(__file__).resolve().parent
idx = int(sys.argv[1])
events = 50000
if idx < 5000 or idx >= 30000:
    raise ValueError("index outside this campaign's reserved dijet seeds")
shard = base / "shards" / f"{idx:04d}"
shard.mkdir(parents=True,exist_ok=True)
lock=(shard/"production.lock").open("w")
fcntl.flock(lock,fcntl.LOCK_EX)
failure = shard / "native_failure.json"
spectrum = shard / "spectrum.json"
if not spectrum.is_file() and not failure.is_file():
    rc = subprocess.run([sys.executable, str(base/"worker.py"), str(idx), str(events)]).returncode
    if rc and not failure.is_file():
        raise RuntimeError(f"worker exited with {rc}")
if failure.is_file() and (not spectrum.is_file() or not (base/"recovery"/f"{idx:04d}"/"replacement_comparison.json").is_file()):
    from queue_abort_recovery import queue
    from recover import generate
    error = json.loads(failure.read_text())
    if error["code"] != -6:
        raise ValueError(f"unexpected native exit {error}")
    rec = base / "recovery" / f"{idx:04d}"
    for attempt in range(5):
        try:
            queue(idx, error["pid"], events)
            break
        except subprocess.CalledProcessError:
            if attempt == 4:
                raise
            time.sleep(12)
    taskbase = base / "recovery_tasks"
    for task in sorted(taskbase.glob(f"{idx:04d}_*.json")):
        generate(**json.loads(task.read_text()))
        task.rename(task.with_suffix(".done"))
result = json.loads(spectrum.read_text())
if result["generated_events"] != events or result["generator_seed"] != 19000000+101*idx:
    raise ValueError("Unexpected native sample manifest")
# Normal shards keep compact pair rows, cross sections, native logs, cards,
# spectra and file hashes. A failed seed keeps its replay diagnostics and ROOT.
if not failure.exists():
    root = shard / "events/minbias.root"
    if root.exists():
        if worker.digest(root) != result["source_root_sha256"]:
            raise ValueError("ROOT artifact changed after detector processing")
        root.unlink()
    if (shard / "minbias.run").exists():
        (shard / "minbias.run").unlink()
    evtlog=shard/"minbias-EvtGen.log"
    if evtlog.exists():
        packed=evtlog.with_suffix(".log.gz")
        tmp=packed.with_suffix(".tmp")
        with evtlog.open("rb") as source, gzip.open(tmp, "wb", compresslevel=1) as dest:
            shutil.copyfileobj(source,dest)
        tmp.replace(packed)
        evtlog.unlink()
ok=shard/"worker_complete.json"
tmp=ok.with_suffix(".tmp")
tmp.write_text(json.dumps({"seed":result["generator_seed"], "events":events,
                           "spectrum_sha256":worker.digest(spectrum)})+"\n")
tmp.replace(ok)
