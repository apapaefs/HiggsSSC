"""Borrow the next ordinary worker slot to recover a pre-existing failed task."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

base=Path(__file__).resolve().parents[1]
tasks=base/"known_repairs"

def enqueue():
    tasks.mkdir(exist_ok=True)
    for name in ("dijet_5053","dijet_7031","dijet_7169","dijet_7347","loop_focus_12"):
        if not list(tasks.glob(name+".*")):
            (tasks/(name+".pending")).touch(exist_ok=False)

def repair_one():
    if os.environ.get("SSC20_RUNNING_REPAIR") or not tasks.exists():return
    for path in sorted(tasks.glob("*.pending")):
        running=path.with_suffix(".running")
        try:path.rename(running)
        except FileNotFoundError:continue
        name=path.stem
        split=name.split("_")
        if split[0]=="dijet" and len(split)==2 and split[1].isdigit():
            cmd=[sys.executable,str(base/"dijet/one.py"),split[1]]
        elif split[0]=="loop" and len(split)==3 and split[1] in ("focus","broad") and split[2].isdigit():
            cmd=["bash",str(base/"loop/one.sh"),*split[1:]]
        else: raise ValueError(f"unknown recovery task {name}")
        log=path.with_suffix(".log")
        with log.open("a") as stream:
            proc=subprocess.Popen(cmd,env=dict(os.environ,SSC20_RUNNING_REPAIR="1"),stdout=stream,stderr=subprocess.STDOUT)
            running.write_text(json.dumps(dict(started=time.time(),pid=proc.pid,allowed_cpus=sorted(os.sched_getaffinity(0))))+"\n")
            rc=proc.wait()
        running.rename(path.with_suffix(".error" if rc else ".done"))
        return

if __name__=="__main__":enqueue()
