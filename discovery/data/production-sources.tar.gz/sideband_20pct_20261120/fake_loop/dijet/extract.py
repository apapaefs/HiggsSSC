import csv
import math
import re
import numpy as np
from scipy.sparse import coo_matrix


def package(run, seed, expected):
    stats = (run / "minbias.out").read_text()
    match = re.search(r"Total \(from generated events\):\s*(\d+)\s+\d+\s+([\d.]+)\((\d+)\)(?:e([+-]?\d+))?", stats)
    if not match or "Events carry unit weights." not in stats or "(nb)" not in stats:
        raise ValueError("Cannot verify native inclusive cross section")
    n = int(match[1])
    sigma = float(match[2]) * 10**int(match[4] or 0)
    if n != expected:
        raise ValueError(f"Expected {expected} events, got {n}")
    with (run / "moments.csv").open() as f:
        row = next(r for r in csv.DictReader(f) if r["scenario"]=="all_quark_independent" and float(r["fake_scale"])==1.)
    if int(row["events_read"]) != n:
        raise ValueError("Generator and detector event counts differ")
    pairs = np.genfromtxt(run / "pairs.csv", names=True, delimiter=",", ndmin=1)
    ids = pairs["source"].astype(int)
    weights = pairs["fq"]**2
    masses = pairs["m_gg"]
    if not (np.isfinite(weights).all() and np.isfinite(masses).all() and
            np.all(ids == pairs["source"]) and np.all(ids>=0) and np.all(ids<n) and
            (np.bincount(ids,weights=weights,minlength=n)<=1+1e-13).all()):
        raise ValueError("Bad response weights or indices")
    win = (masses>=120)&(masses<=130)
    if not math.isclose(float(row["sum_probability"]), float(weights[win].sum()), rel_tol=1e-10, abs_tol=1e-14):
        raise ValueError("Detector mass-window reference failed")
    bins = np.floor(masses-105).astype(int)
    keep = (bins>=0)&(bins<55)
    def moments(values):
        hist=coo_matrix((values[keep]*sigma*1.e6/n,(ids[keep],bins[keep])),shape=(n,55)).tocsr()
        return np.asarray(hist.sum(axis=0)).ravel().tolist(), (hist.T@hist).toarray().tolist()
    rate,cov=moments(weights)
    low, lowcov=moments(pairs["fg"]**2*(pairs["eligible_jets"]==2))
    return dict(sample="bkg_dijet_double_fake", independent_id=f"inclusive_minbias_seed_{seed}",
                generated_events=n, generator_seed=seed, response_seed=seed+100, sigma_nb=sigma,
                edges_gev=list(range(105,161)), rate_fb=rate, covariance_fb2=cov,
                lower_endpoint_rate_fb=low, lower_endpoint_covariance_fb2=lowcov,
                fit_range_sources=int(np.unique(ids[keep]).size), fit_range_pairs=int(keep.sum()))
