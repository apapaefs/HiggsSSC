set pagination off
set debuginfod enabled off
python
import gdb
import json
frame = gdb.newest_frame()
in_decay = False
decay_step = None
while frame is not None:
    if frame.name() and "Herwig::HwDecayHandler::performDecay" in frame.name():
        in_decay = True
    if frame.name() and "ThePEG::EventHandler::performStep" in frame.name():
        if in_decay:
            frame.select()
            decay_step = frame.read_var("this")["theCurrentStep"]["ptr"].dereference()
        break
    frame = frame.older()
assert decay_step is not None, "The failed step is outside the final native decay stage."
particle_set = gdb.default_visualizer(decay_step["theParticles"])
assert particle_set is not None
entries = []
for _, entry in particle_set.children():
    part = entry["ptr"].dereference()
    data = part["theData"]["ptr"].dereference()
    mom = part["theMomentum"].address.cast(gdb.lookup_type("double").pointer())
    entries.append({"particle_id": int(data["theId"]["id"]), "colour":str(data["theColour"]),
                    "stable":bool(data["isStable"]),
                    "momentum_gev":[float((mom+k).dereference())/1000. for k in range(5)]})
print("DECAY_PARTICLES="+json.dumps(entries))
end
