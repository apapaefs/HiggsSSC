"""Write a consistent summary of completed minimum-bias shards with disjoint seeds."""
import argparse
import hashlib
import json
import os
from pathlib import Path

import numpy as np

BASE = Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument("--output", default="pooled_new.json")
p.add_argument("--minimum", type=int, default=1)
p.add_argument("--first", type=int)
p.add_argument("--stop", type=int)
p.add_argument("--complete-waves", action="store_true")
args=p.parse_args()
if args.complete_waves and (args.first is not None or args.stop is not None):
    p.error("Choose waves or one fixed block.")
if args.complete_waves and args.output == "pooled_new.json":
    args.output="pooled_waves.json"
shards=[]
for f in sorted((BASE/"shards").glob("*/spectrum.json")):
    index=int(f.parent.name)
    if args.first is not None and index < args.first or args.stop is not None and index >= args.stop:
        continue
    raw=f.read_bytes()
    item=json.loads(raw)
    assert item['generated_events']>0 and item['edges_gev']==list(range(105,161))
    assert item['analyzer_sha256']=="899a024c89dd3a49109d0fc8fb2268b49adf019dcccb6225da7dced1ff460691"
    assert np.allclose(item['covariance_fb2'],np.array(item['covariance_fb2']).T)
    shards.append((item, str(f.relative_to(BASE)), hashlib.sha256(raw).hexdigest()))
if args.complete_waves:
    by_id={int(Path(path).parent.name):(item,path,digest) for item,path,digest in shards}
    assert len(by_id)==len(shards)
    all_seeds=set()
    third=(BASE/"third_wave.active").is_file()
    groups=((0,504,36),(504,624,12))+(((624,912,12),) if third else ())
    for index,(item,_,_) in by_id.items():
        if index not in range(912 if third else 624) or item['generator_seed'] != 19000000+101*index or item['generated_events']!=50000:
            raise ValueError(f"Unexpected seed or event count for shard {index}")
        if item['generator_seed'] in all_seeds: raise ValueError("Repeated independent seed")
        all_seeds.add(item['generator_seed'])
    waves=[]
    for first,stop,width in groups:
        for i in range(first,stop,width):
            if not all(j in by_id for j in range(i,i+width)): break
            waves.append((i,i+width))
    shards=[by_id[j] for first,stop in waves for j in range(first,stop)]
    if not shards:
        print("No complete predefined wave yet")
        raise SystemExit(0)
if args.first is not None and args.stop is not None:
    expected={f"shards/{i:04d}/spectrum.json" for i in range(args.first,args.stop)}
    if {path for _,path,_ in shards} != expected:
        raise SystemExit("The requested predefined block is incomplete")
if len(shards)<args.minimum:
    raise SystemExit(f"Only {len(shards)} complete shards")
ids=[s['generator_seed'] for s,*_ in shards]
dseeds=[s['response_seed'] for s,*_ in shards]
secondary=[seed for s,*_ in shards for field in ("auxiliary_generator_seeds","auxiliary_response_seeds") for seed in s.get(field,[])]
assert len(set(ids+dseeds+secondary))==len(ids+dseeds+secondary)
N=sum(i['generated_events'] for i,*_ in shards)
def pooled(field,order):
    return sum((s['generated_events']/N)**order*np.array(s[field]) for s,*_ in shards).tolist()
source_meta=[{'zero_response_native_aborts':s.get('zero_response_native_aborts',0),'continuation_generator_seeds':s.get('auxiliary_generator_seeds',[]),'continuation_response_seeds':s.get('auxiliary_response_seeds',[]),'seed':s['generator_seed'],'events':s['generated_events'],'sigma_nb':s['sigma_nb'],'path':f,'sha256':h} for s,f,h in shards]
for info,(s,_,_) in zip(source_meta,shards):
    if s.get("interrupted_sampler_proposals") or s.get("independently_replaced_native_decays"):
        info["interrupted_sampler_proposals"]=s.get("interrupted_sampler_proposals",0)
        if s.get("independently_replaced_native_decays"):
            info["independently_replaced_native_decays"]=s["independently_replaced_native_decays"]
        info["native_interruption_proof_sha256"]=s["native_interruption_proof_sha256"]
result=dict(zero_response_native_aborts=sum(s.get('zero_response_native_aborts',0) for s,*_ in shards),sample='bkg_dijet_double_fake', independent_id=f"new_minbias_pool_{hashlib.sha256(json.dumps(source_meta).encode()).hexdigest()[:20]}",
            edges_gev=list(range(105,161)),generated_events=N,shard_count=len(shards),shards=source_meta,
            fit_range_sources=sum(s['fit_range_sources'] for s,*_ in shards),
            fit_range_pairs=sum(s['fit_range_pairs'] for s,*_ in shards),
            rate_fb=pooled('rate_fb',1),covariance_fb2=pooled('covariance_fb2',2),
            lower_endpoint_rate_fb=pooled('lower_endpoint_rate_fb',1),
            lower_endpoint_covariance_fb2=pooled('lower_endpoint_covariance_fb2',2),
            method='Each seed uses its own unit-weight inelastic Herwig cross section, including diffraction. Pool rates with N_i / sum N_i and source-event covariance with the squares of those weights. The earlier 132 seeds are excluded.')
if args.complete_waves:
    result["complete_predeclared_waves"]=waves
out=Path(args.output)
if not out.is_absolute(): out=BASE/out
tmp=out.with_suffix(f'.{os.getpid()}.tmp')
tmp.write_text(json.dumps(result,separators=(',',':'))+'\n')
tmp.replace(out)
print(len(shards),N,result['fit_range_sources'],out)
