"""Generate and analyze one independent 40 TeV minimum-bias shard."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
REFERENCE = Path("/home/apapaefs/HiggsSSC/inputs/pipeline/bg-extra-20261118")
CARD = REFERENCE / "mb_part_0/minbias.in"
BINARY = REFERENCE / "verifier_v2/dijet_envelopes"
ANALYZER_SHA = "899a024c89dd3a49109d0fc8fb2268b49adf019dcccb6225da7dced1ff460691"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_logged(command, directory, name):
    with (directory / name).open("w") as output:
        process=subprocess.Popen(command, cwd=directory, stdout=output, stderr=subprocess.STDOUT)
        native=(command[0]=="Herwig" and command[1]=="run")
        if native:
            (directory/"native_pid.json").write_text(json.dumps({"pid":process.pid,"start_unix":time.time()}))
        code=process.wait()
        if code:
            if native:
                (directory/"native_failure.json").write_text(json.dumps({"pid":process.pid,"code":code,"finish_unix":time.time()}))
            raise subprocess.CalledProcessError(code,command)


def main():
    from recover import work_outstanding
    work_outstanding()
    index, n = map(int, sys.argv[1:])
    seed = 19000000 + 101 * index
    run = HERE / "shards" / f"{index:04d}"
    output = run / "spectrum.json"
    if output.exists():
        previous = json.loads(output.read_text())
        if previous["generated_events"] != n or previous["generator_seed"] != seed:
            raise ValueError("Existing shard uses a different event count or seed.")
        return
    if digest(BINARY) != ANALYZER_SHA:
        raise ValueError("Analyzer differs from the published dijet response.")
    run.mkdir(parents=True, exist_ok=True)
    (run / "events").mkdir(exist_ok=True)
    text = CARD.read_text()
    assert text.count("RandomNumberGenerator:Seed 931025") == text.count("EventGenerator:NumberOfEvents 10000") == 1
    text = text.replace("RandomNumberGenerator:Seed 931025", f"RandomNumberGenerator:Seed {seed}")
    text = text.replace("EventGenerator:NumberOfEvents 10000", f"EventGenerator:NumberOfEvents {n}")
    card = run / "minbias.in"
    if card.exists() and card.read_text() != text:
        raise ValueError("Card mismatch")
    card.write_text(text)
    start = time.time()
    receipt = run / "generator_complete.json"
    if not receipt.exists():
        run_logged(["Herwig", "read", "minbias.in"], run, "read.log")
        run_logged(["Herwig", "run", "minbias.run", "-N" + str(n)], run, "run.log")
        if "A root tree has been written" not in (run / "run.log").read_text():
            raise ValueError("Missing ROOT termination receipt")
        receipt.write_text(json.dumps(dict(seed=seed, generated=n, seconds=time.time()-start)))
    root = run / "events/minbias.root"
    run_logged([str(BINARY), "--dijet-bound", str(root), "moments.csv", str(seed+100), "pairs.csv"], run, "response.log")
    from extract import package
    result = package(run, seed, n)
    result.update(generator="Herwig 7.3 inclusive minimum-bias incl diffractive collisions", analyzer_sha256=ANALYZER_SHA,
                  reference_card_sha256=digest(CARD), card_sha256=digest(card), source_root_sha256=digest(root),
                  generator_output_sha256=digest(run/"minbias.out"), detector_pairs_sha256=digest(run/"pairs.csv"))
    draft = output.with_suffix(".tmp")
    draft.write_text(json.dumps(result, separators=(",",":")) + "\n")
    draft.replace(output)


if __name__ == "__main__":
    main()
