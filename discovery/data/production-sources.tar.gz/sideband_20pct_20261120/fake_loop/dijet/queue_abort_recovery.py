"""Recover a native RhoDMatrix abort from a campaign-owned process-core index.

No input model or detector response is changed. Only a diagnosed native
assertion is eligible. Each seed keeps its physical index, so no incomplete
fixed wave is emitted while the original-prefix recovery is pending.
"""
import argparse
import json
import hashlib
import math
import os
from pathlib import Path
import re
import subprocess
import time

HERE=Path(__file__).resolve().parent
GDB="/opt/rh/gcc-toolset-13/root/usr/bin/gdb"
GDB_PY="""python
f = gdb.newest_frame()
while f is not None:
    if f.name() and "ThePEG::EventGenerator::doShoot" in f.name():
        gen = f.read_var("this").dereference()
        print("HIGGSSSC_FAILED_EVENT=" + str(int(gen["ieve"])))
        break
    f = f.older()
end
"""

def certify_zero(index, bad, core):
    directory=core.parent
    result=subprocess.run([GDB,"-batch","-x",str(HERE/"inspect_failed_event.gdb"),
                           "/home/shared/Herwig/bin/Herwig",str(core)],capture_output=True,text=True,check=True)
    trace=directory/"event_data_verified.log"
    trace.write_text(result.stdout+"\n"+result.stderr)
    rows=json.loads(next(x.split("=",1)[1] for x in result.stdout.splitlines() if x.startswith("DECAY_PARTICLES=")))
    if not rows or any(p["colour"]!="ThePEG::PDT::ColourNeutral" for p in rows):
        raise ValueError("Final decay step contains non-singlet particles or no entries")
    momenta=[p["momentum_gev"] for p in rows]
    px,py,pz,energy=(sum(p[k] for p in momenta) for k in range(4))
    if max(abs(px),abs(py),abs(pz),abs(energy-40000))>0.1:
        raise ValueError("Native decay record does not account for full beam energy and momentum")
    # Require physical Lorentz vectors within the native numerical precision.
    if any(abs(p[3]-math.sqrt(p[0]**2+p[1]**2+p[2]**2+p[4]**2))>1.e-3 for p in momenta):
        raise ValueError("Decay-step momenta have an inconsistent mass shell")
    sum_mt=sum(math.sqrt(p[0]**2+p[1]**2+p[4]**2) for p in momenta)
    if not sum_mt < 19.99:
        # Count the accepted but uncompleted decay separately from unaccepted
        # matrix-element trials. Its replacement need not have the same response.
        max_jets=math.floor(sum_mt/10.)
        maximum_fake_probability=math.comb(max_jets,2)*0.000385**2 if max_jets>=2 else 0.
        details=dict(shard=index,pending_request_1based=bad,particle_count=len(rows),
                     replaced_native_decays=1,core_particle_sha256=hashlib.sha256(trace.read_bytes()).hexdigest(),
                     position_receipt_sha256=hashlib.sha256((directory/"position.log").read_bytes()).hexdigest(),
                     sum_transverse_masses_gev=sum_mt,maximum_number_of_native_jets=max_jets,
                     fit_range_fake_probability_bound=maximum_fake_probability,
                     method="An accepted collision aborted during decay. Its response is unknown. Complete the pending count on the independent continuation and compare with the independent full-shard control. A separate upper bound uses 10 GeV per disjoint generator jet and the maximum per-pair quark fake probability in the fitted range.")
        path=directory/"late_decay_replacement.json"
        tmp=path.with_suffix(".tmp"); tmp.write_text(json.dumps(details,indent=2)+"\n"); tmp.replace(path)
        return
    proof=dict(shard=index,failed_event_1based=bad,double_fake_rate_contribution_fb=0.,
               input_sha256=hashlib.sha256(trace.read_bytes()).hexdigest(),particle_count=len(rows),
               sum_transverse_masses_gev=sum_mt,sum_px_py_pz_energy_gev=[px,py,pz,energy],
               proof="All parents in the final native decay stage are colour singlets. Energy conservation in each parent's pz=0 frame bounds total daughter scalar pT by sum(mT). The two disjoint native jets require at least 10 GeV each before smearing.")
    output=directory/"kinematics_auto.json"
    tmp=output.with_suffix(".tmp")
    tmp.write_text(json.dumps(proof,indent=2)+"\n")
    tmp.replace(output)


def queue(index, pid, n=50000):
    sh=HERE/"shards"/f"{index:04d}"
    runlog=(sh/"run.log").read_text(errors="replace")
    decay_abort="RhoDMatrix.h" in runlog and "Assertion" in runlog
    sampler_abort="MEDiffraction.cc:204:" in runlog and "abs(costheta)<=1." in runlog
    if not (decay_abort or sampler_abort):
        raise ValueError("Native abort type requires manual diagnosis")
    progress=re.findall(r"event>\s+(\d+)\s+(\d+)",runlog)
    init_only=(not progress and sampler_abort and runlog.lstrip().startswith("event>     init") and not any((sh/"events").glob("*.root")))
    if not init_only and (not progress or int(progress[-1][1])!=n):
        raise ValueError("Unexpected job progress signature")
    directory=HERE/"recovery"/f"{index:04d}"
    directory.mkdir(exist_ok=True,parents=True)
    core=directory/"aborted.core"
    if not core.is_file():
        with (directory/"core_info.log").open("w") as log:
            subprocess.run(["coredumpctl",f"--output={core}","dump",str(pid)],stdout=log,stderr=subprocess.STDOUT,check=True)
    commands=directory/"event_number.gdb"
    commands.write_text("set pagination off\n"+GDB_PY)
    run=subprocess.run([GDB,"-batch","-ex","set debuginfod enabled off","-ex","bt","-x",str(commands),"/home/shared/Herwig/bin/Herwig",str(core)],
                       capture_output=True,text=True,check=True)
    pos=directory/"position.log"
    pos.write_text(run.stdout+"\n"+run.stderr)
    match=re.search(r"^HIGGSSSC_FAILED_EVENT=(\d+)$",run.stdout,re.M)
    if init_only:
        if match or "ThePEG::ACDCSampler::doinitrun" not in run.stdout or "ThePEG::InterfacedBase::initrun" not in run.stdout or "ThePEG::EventGenerator::doShoot" in run.stdout:
            raise ValueError("Core does not demonstrate a pre-event sampler initialization failure")
        bad=1
    else:
        if not match: raise ValueError("Event number unavailable from core")
        bad=int(match[1])
        if not int(progress[-1][0])<=bad<=n: raise ValueError("Event number does not match generator trace")
    if decay_abort:
        certify_zero(index,bad,core)
    else:
        # This is an unaccepted cross-section proposal, earlier than the event
        # record. An independent continuation completes the whole pending request.
        expected=["Herwig::MEDiffraction::generateKinematics","ThePEG::StandardXComb::dSigDR",
                  "ThePEG::ACDCSampler::generate","ThePEG::StandardEventHandler::generateEvent",
                  "ThePEG::EventGenerator::doShoot"]
        if init_only: expected=["Herwig::MEDiffraction::generateKinematics","ThePEG::StandardXComb::dSigDR","ThePEG::ACDCSampler::doinitrun","ThePEG::InterfacedBase::initrun"]
        where=[run.stdout.find(s) for s in expected]
        if min(where)<0 or where!=sorted(where): raise ValueError("Unexpected sampler backtrace")
        naming=directory/"sampler_interruption.json"
        data={"shard":index, "pending_request_1based":bad, "interrupted_sampler_proposals":1,
              "number_of_accepted_events_before_interruption":bad-1,"zero_events_during_initialization":init_only,
              "position_receipt_sha256":hashlib.sha256(pos.read_bytes()).hexdigest(),
              "classification":"The failure occurs during evaluation of an ACDC trial cross section before acceptance or production of a physical outgoing event. Restart the complete pending request on the independent continuation."}
        tmp=naming.with_suffix(".tmp"); tmp.write_text(json.dumps(data,indent=2)+"\n"); tmp.replace(naming)
    tasks=HERE/"recovery_tasks"
    tasks.mkdir(exist_ok=True)
    for i,part in enumerate(("prefix","continuation","independent_control")):
        if init_only and part=="prefix":continue
        name=f"{index:04d}_{i}_{part}"
        if any(tasks.glob(name+".*")): continue
        temp=tasks/(name+".staging")
        temp.write_text(json.dumps(dict(idx=index,bad=bad,part=part,n=n))+"\n")
        temp.replace(tasks/(name+".json"))
    print("Queued",index,"pid",pid,"native abort at",bad,flush=True)


def follow():
    failed=set()
    while True:
        for log in (HERE/"shards").glob("*/native_failure.json"):
            if log in failed: continue
            index=int(log.parent.name)
            if any((HERE/"recovery_tasks").glob(f"{index:04d}_0_prefix.*")): continue
            content=json.loads(log.read_text())
            if content["code"]!=-6: continue
            if time.time()-content["finish_unix"]<5.: continue
            try:
                queue(index,content["pid"])
            except Exception as exc:
                failed.add(log)
                print("MANUAL REVIEW",index,repr(exc),flush=True)
        time.sleep(30)


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--watch",action="store_true")
    p.add_argument("--index",type=int)
    p.add_argument("--pid",type=int)
    a=p.parse_args()
    if a.watch: follow()
    else: queue(a.index, a.pid)
