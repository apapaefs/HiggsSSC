"""Dispatch one worker per assigned CPU, with restartable fixed seed blocks."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
RUN = HERE.parent
BASE_IDX = 5000
BLOCK = 25

def dump(path, record):
    draft=path.with_suffix(".tmp")
    draft.write_text(json.dumps(record,indent=2,allow_nan=False)+"\n")
    draft.replace(path)

def read_mask(value):
    cpus = set()
    for token in value.split(","):
        edges=list(map(int,token.split("-")))
        if len(edges)==1: cpus.add(edges[0])
        elif len(edges)==2 and edges[0]<=edges[1]: cpus.update(range(edges[0],edges[1]+1))
        else: raise ValueError("Invalid CPU mask")
    if cpus - set(os.sched_getaffinity(0)): raise ValueError("CPU mask exceeds available CPUs")
    return cpus

def loop_tasks(nfocus, nbroad):
    # Interleave the two disjoint strata at the planned production ratio.
    tasks=[((i+.5)/num,channel,i) for channel,num in (("focus",nfocus),("broad",nbroad)) for i in range(num)]
    return [(channel,i) for _,channel,i in sorted(tasks)]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("kind",choices=("dijet","loop"))
    p.add_argument("--cpus",required=True)
    p.add_argument("--blocks",type=int,default=192)
    p.add_argument("--focused",type=int,default=44)
    p.add_argument("--broad",type=int,default=13)
    a=p.parse_args()
    base=HERE/a.kind
    ready=RUN/"ready"/a.kind
    ready.mkdir(parents=True,exist_ok=True)
    (base/"logs").mkdir(exist_ok=True)
    lock=(base/"dispatch.lock").open("w")
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    if a.kind=="dijet":
        if not 0<a.blocks<=1000: raise ValueError("Dijet block count outside campaign seed range")
        tasks=list(range(BASE_IDX,BASE_IDX+BLOCK*a.blocks))
        def receipt(i): return base/"shards"/f"{i:04d}"/"spectrum.json"
        def cmd(i): return [sys.executable,str(base/"one.py"),str(i)]
        def needs(i):
            path=receipt(i)
            if not path.is_file(): return True
            return (path.parent/"native_failure.json").is_file() and not (base/"recovery"/f"{i:04d}"/"replacement_comparison.json").is_file()
    else:
        if not (0<a.focused<=10000 and 0<a.broad<=10000): raise ValueError("Loop count outside campaign seed range")
        tasks=loop_tasks(a.focused,a.broad)
        def receipt(i): return ready/f"loop_{i[0]}_{i[1]:04d}.json"
        def cmd(i): return ["bash",str(base/"one.sh"),i[0],str(i[1])]
        def needs(i): return not receipt(i).is_file()
    solved={i for i in tasks if not needs(i)}
    keyed_tasks={str(item):item for item in tasks}
    cursor=0
    published=0
    failures={}
    running={}
    drain_limit=None
    state=base/"progress.json"
    maskfile=base/"cpus.txt"
    if not maskfile.exists(): maskfile.write_text(a.cpus+"\n")
    def publish():
        nonlocal published
        if a.kind!="dijet":return
        while published<a.blocks:
            first=BASE_IDX+BLOCK*published
            block=ready/f"dijet_{published:04d}.json"
            if not block.exists():
                if not all(k in solved for k in range(first,first+BLOCK)):break
                subprocess.run([sys.executable,str(base/"pool.py"),"--first",str(first),"--stop",str(first+BLOCK),"--output",str(block)],check=True)
            published+=1
    def progress(status,cpus):
        dump(state,dict(status=status,pid=os.getpid(),updated_unix=time.time(),requested_cpus=sorted(cpus),
                        active={str(k):{"task":item,"pid":proc.pid} for k,(item,proc) in running.items()},
                        completed=len(solved),completed_events=len(solved)*(50000 if a.kind=="dijet" else 8000),
                        target_tasks=len(tasks),published_dijet_blocks=published if a.kind=="dijet" else None,
                        failures=failures,stop_after_task_index=drain_limit))
    try:
        while True:
            for cpu,(item,proc) in list(running.items()):
                rc=proc.poll()
                if rc is None:continue
                del running[cpu]
                if rc==0 and not needs(item):solved.add(item)
                else:failures[str(item)]=rc if rc else "missing receipt"
            for key in list(failures):
                item=keyed_tasks[key]
                if not needs(item):
                    solved.add(item)
                    del failures[key]
            publish()
            mask=maskfile.read_text().strip()
            cpus=read_mask(mask) if mask else set()
            if drain_limit is None and (RUN/"fit/TARGET_REACHED.json").is_file():
                drain_limit=min(len(tasks), ((cursor+BLOCK-1)//BLOCK)*BLOCK) if a.kind=="dijet" else cursor
            limit=len(tasks) if drain_limit is None else drain_limit
            for cpu in sorted(cpus-set(running)):
                while cursor<limit and tasks[cursor] in solved:cursor+=1
                if cursor>=limit:break
                item=tasks[cursor]
                cursor+=1
                logname=str(item) if a.kind=="dijet" else f"{item[0]}_{item[1]:04d}"
                with (base/"logs"/f"{logname}.log").open("a") as log:
                    proc=subprocess.Popen(["taskset","-c",str(cpu),*cmd(item)],stdout=log,stderr=subprocess.STDOUT)
                running[cpu]=(item,proc)
            if not running and cursor>=limit:
                if failures: final="errors"
                elif drain_limit is None:final="finished"
                else:final="drained_after_target"
                progress(final,cpus)
                return int(bool(failures))
            progress("running" if drain_limit is None else "draining", cpus)
            time.sleep(7)
    except BaseException:
        progress("controller_exception",set())
        raise
if __name__=="__main__":
    sys.exit(main())
