"""Show receipts, current native progress and failures for both producers."""
import json
from pathlib import Path
import re
import time

base=Path(__file__).resolve().parent
now=time.time()
def tail(path,length=2048):
    if not path.is_file(): return ""
    with path.open("rb") as inp:
        inp.seek(max(0,path.stat().st_size-length))
        return inp.read().decode(errors="replace")
for kind in ("dijet","loop"):
    folder=base/kind
    state=folder/"progress.json"
    if not state.exists():
        print(kind,"awaiting controller",flush=True)
        continue
    p=json.loads(state.read_text())
    active=p["active"]
    native=[]
    stages={}
    for task in active.values():
        i=task["task"]
        if kind=="dijet":
            numbers=re.findall(r'event>\s+(\d+)\s+(\d+)',tail(folder/"shards"/f"{i:04d}"/"run.log"))
            if numbers: native.append(int(numbers[-1][0]))
        else:
            tag=f"ssc20pct_loop_{i[0]}_{i[1]}"
            manifest=folder/"runs"/tag/"Backgrounds/events/bkg_loop_gg_aa/campaign.json"
            if manifest.is_file():
                try: completed=json.loads(manifest.read_text())["completed"]
                except (KeyError,ValueError): completed=[]
                stage="after_"+completed[-1] if completed else "preparing_or_generating"
            else: stage="preparing"
            stages[stage]=stages.get(stage,0)+1
    errors={}
    for key in list(p["failures"])[-3:]:
        if kind=="dijet": log=folder/"logs"/f"{key}.log"
        else:
            import ast
            channel,index=ast.literal_eval(key)
            log=folder/"logs"/f"{channel}_{index:04d}.log"
        errors[key]=tail(log).splitlines()[-3:]
    packets=len(list((base.parent/"ready"/kind).glob("*.json")))
    print(json.dumps(dict(kind=kind,controller=p["pid"],status=p["status"],
                          updated_ago_seconds=int(now-p["updated_unix"]),workers=len(active),
                          completed_events=p["completed_events"],packets=packets,
                          indicated_events_in_active_shards=sum(native),loop_stages=stages,failures=errors)),flush=True)
