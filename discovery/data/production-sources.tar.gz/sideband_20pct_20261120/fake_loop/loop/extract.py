"""Project completed loop samples with no overlap at the Born-mass boundary."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from scipy.sparse import coo_matrix
import uproot

def sha(path):
    h=hashlib.sha256()
    with path.open("rb") as stream:
        for buf in iter(lambda: stream.read(1048576),b""):
            h.update(buf)
    return h.hexdigest()

def extract(directory,kind,mapping=None):
    from hgammagamma import ho_shower_completion as completion
    from hgammagamma.born_mass_mapping import audit
    mp=directory/"campaign.json"
    j=json.loads(mp.read_text())
    hard=j["lhe"]
    seed=j["seed"]
    assert j["process"]=="g g > a a / h [noborn=QCD]" and j["ebeam_gev"]==20000
    assert j["completed"][-1]=="analyze" and j["lhaid"]==335900
    assert j["analysis"]["detector_response"]=="ssc" and j["analysis"]["response_mode"]=="genuine"
    proof=completion.validate_completion(j["shower_completion"],j,directory=directory)
    ngen=hard["events"]
    assert ngen==proof["attempted_events"] and int(j["analysis"]["events_read"])==proof["saved_events"]
    assert hard["negative_events"]==0 and abs(hard["effective_events"]/ngen-1)<1.e-6
    assert float(j["weight_scale"])==1 and proof["source_weights"]["sum_weight"]==ngen
    root=directory/f'bkg_loop_gg_aa_hwsim_roots-{j["run_tag"]}_var.root'
    with uproot.open(root) as source:
        tr=source["Data2"]
        values=tr["variables"].array(library="np")
        weights=tr["eventweight"].array(library="np").reshape(-1)
        ids=tr["sourceevent"].array(library="np").reshape(-1)
    assert ids.dtype.kind in "iu" and np.array_equal(np.unique(ids),np.arange(proof["saved_events"]))
    assert np.allclose(np.bincount(ids,weights=weights),1.,rtol=1.e-9,atol=1.e-12)
    assert np.all(weights>=0) and np.all(np.isfinite(values[:,0]))
    domain="focused_inside" if kind=="focus" else "broad_outside"
    info={}
    cuts=j["generator_settings"]
    if kind=="focus":
        assert (cuts["mmaa"],cuts["mmaamax"])==(100.,150.)
        bound=hard["born_mgg_validation"]
        if not (100.<=bound["minimum_observed_gev"] and bound["maximum_observed_gev"]<150.):
            raise ValueError("Generated focused events straddle the stated partition")
        region=np.ones(len(ids),bool)
        info["native_born_mass_validation"]=bound
    else:
        assert (cuts.get("mmaa",0.),cuts.get("mmaamax",-1.))==(0.,-1.)
        mapping=mapping or directory/"sideband_born_map"
        summary=mapping/"summary.json"
        if not summary.exists():
            audit(mp,root,mapping)
        record=json.loads(summary.read_text())
        assert record["status"]=="validated" and record["synthetic_skip_recovery_passed"]
        assert record["inputs"]["manifest"]["sha256"]==sha(mp) and record["inputs"]["response"]["sha256"]==sha(root)
        assert (record["partition"]["low_gev"], record["partition"]["high_gev"],record["partition"]["high_edge_exclusive"])==(100.,150.,True)
        assert record["mapping_artifact"]["sha256"]==sha(mapping/"mapping.npz")
        with np.load(mapping/"mapping.npz",allow_pickle=False) as data:
            assert np.array_equal(data["response_sourceevent"],ids)
            region=~data["response_inside_window"]
        info["born_map_sha256"]=sha(summary)
        info["native_born_partition"]=record["partition"]
    edges=np.arange(105.,161.)
    keep=region & (values[:,-1]>=2) & (values[:,0]>=edges[0]) & (values[:,0]<edges[-1])
    bins=np.searchsorted(edges,values[keep,0],side="right")-1
    w=weights[keep]*(1000.*hard["cross_section_pb"]/ngen)
    matrix=coo_matrix((w,(ids[keep],bins)),shape=(proof["saved_events"],55)).tocsr()
    return dict(sample=j["sample"],stratum=domain,generated_events=ngen,seed=seed,run_tag=j["run_tag"],
                independent_id=hard["sha256"],source_lhe_sha256=hard["sha256"],response_root_sha256=sha(root),
                mass_bin_edges_GeV=edges.tolist(),rates_fb=np.asarray(matrix.sum(axis=0)).ravel().tolist(),
                covariance_fb2=(matrix.T@matrix).toarray().tolist(),selected_sources=int(len(np.unique(ids[keep]))),
                native_cross_section_pb=hard["cross_section_pb"],saved_events=proof["saved_events"],
                failed_showers=proof["discarded_events"],max_momentum_residual_MeV=proof["max_momentum_violation_mev"],**info)

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("directory",type=Path)
    p.add_argument("kind",choices=("focus","broad"))
    p.add_argument("output",type=Path)
    p.add_argument("--mapping",type=Path)
    p.add_argument("--repo",type=Path,default=Path("/home/apapaefs/HiggsSSC"))
    a=p.parse_args()
    sys.path.insert(0,str(a.repo.resolve()))
    out=extract(a.directory.resolve(),a.kind,a.mapping)
    if a.output.exists():
        if json.loads(a.output.read_text())!=out: raise ValueError("Existing packet differs")
    else:
        tmp=a.output.with_suffix(".tmp")
        tmp.write_text(json.dumps(out,separators=(",",":"),allow_nan=False)+"\n")
        tmp.replace(a.output)
