#!/usr/bin/env bash
set -euo pipefail
kind=$1
index=$2
here=$(cd "$(dirname "$0")" && pwd)
run_root=$(cd "$here/../.." && pwd)
pipeline=/home/apapaefs/HiggsSSC/inputs/pipeline
archive="$pipeline/loop-gammagamma-20261118"
py="$pipeline/venv/bin/python"
[[ "$index" =~ ^[0-9]+$ && "$index" -lt 10000 ]]
tag="ssc20pct_loop_${kind}_${index}"
case "$kind" in
   focus) seed=$((201120301+index)); opts=(--gen-mgg-min 100 --gen-mgg-max 150) ;;
   broad) seed=$((201140301+index)); opts=() ;;
   *) exit 2 ;;
esac
printf -v label 'loop_%s_%04d.json' "$kind" "$index"
out="$run_root/ready/loop/$label"
folder="$here/runs/$tag"
runtime="$here/runtime/$tag"
base="$folder/Backgrounds/events/bkg_loop_gg_aa"
smoke_export="$archive/source_v1/hgammagamma/HOAnalysis/runs/gg_aa_loop_smoke_20261118/Backgrounds/events/bkg_loop_gg_aa/mg5_process"
mkdir -p "$runtime" "$folder" "$run_root/ready/loop"
exec 9>"$folder/production.lock"
flock -x 9
if [[ ! -s "$out" ]]; then
    rsync -a --exclude='runs/' --exclude='results/' --exclude='.git/' --exclude='__pycache__/' "$archive/source_v4/" "$runtime/"
    cd "$runtime"
    if [[ -s "$base/herwig/run.log" ]] && grep -q "RhoDMatrix.h" "$base/herwig/run.log"; then
        exec "$py" "$here/retry_shower.py" "$folder" "$runtime" "$kind" "$out"
    fi
    if ! "$py" hgammagamma/run_loop_gammagamma.py --stage all --resume --output-dir "$folder" \
        --run-tag "$tag" --nevents 8000 --nb-core 1 "${opts[@]}" --reuse-loop-export "$smoke_export" \
        --seed-base "$seed" --ebeam 20000 --no-herwig-module --mg5-dir "$pipeline/MG5_aMC_v3_5_15" \
        --mg5-python "$py" --mg5-fortran /usr/bin/gfortran --mg5-cxx /usr/bin/g++ --analysis-cxx /usr/bin/g++; then
        if [[ -s "$base/herwig/run.log" ]] && grep -q "RhoDMatrix.h" "$base/herwig/run.log"; then
            exec "$py" "$here/retry_shower.py" "$folder" "$runtime" "$kind" "$out"
        fi
        exit 1
    fi
    "$py" "$here/extract.py" "$base" "$kind" "$out"
fi
