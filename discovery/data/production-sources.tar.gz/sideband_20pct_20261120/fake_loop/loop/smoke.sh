#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
p=/home/apapaefs/HiggsSSC/inputs/pipeline
py="$p/venv/bin/python"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
prior="$p/sideband_campaign_20261119"
pilot="$p/loop-gammagamma-20261118/source_v2/hgammagamma/HOAnalysis/runs/gg_aa_loop_pilot_20k_20261118"
mkdir -p commissioning
"$py" extract.py "$prior/loop/runs/sideband_loop_focus_20261119_0/Backgrounds/events/bkg_loop_gg_aa" focus commissioning/focused.json
"$py" extract.py "$pilot/Backgrounds/events/bkg_loop_gg_aa" broad commissioning/broad.json --mapping "$p/born-mass-mapping-20261118/broad_20k"
"$py" - "$prior" <<'PY'
from pathlib import Path
import sys,json,numpy as np
prior=Path(sys.argv[1])
r=json.loads((prior/"loop/sideband_loop_focus_20261119_0.json").read_text())
b=next(d for d in json.loads((prior/"fit/baseline.json").read_text())["datasets"] if d["sample"]=="bkg_loop_gg_aa" and d["stratum"]=="broad_outside")
for name,ref in (("broad",b),("focused",r)):
 new=json.loads(Path(f"commissioning/{name}.json").read_text())
 for field,k2 in (("rates_fb","rate_fb"),("covariance_fb2","covariance_fb2")):
  np.testing.assert_allclose(new[field], ref.get(field,ref.get(k2)),rtol=1.e-9,atol=1.e-9)
 print(name,new["generated_events"],new["selected_sources"],sum(new["rates_fb"]),flush=True)
PY
