"""Repeat only the shower for an identified RhoDMatrix abort, on its original hard events."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

p=argparse.ArgumentParser()
p.add_argument("folder",type=Path)
p.add_argument("runtime",type=Path)
p.add_argument("kind",choices=("focus","broad"))
p.add_argument("output",type=Path)
a=p.parse_args()
original=a.folder.resolve()/"Backgrounds/events/bkg_loop_gg_aa"
run=a.folder.resolve()/"shower_recovery"
work=run/"Backgrounds/events/bkg_loop_gg_aa"
sys.path.insert(0,str(a.runtime.resolve()))
from hgammagamma import run_loop_gammagamma as loop
from extract import extract,sha
source_manifest=original/"campaign.json"
m=json.loads(source_manifest.read_text())
log=(original/"herwig/run.log").read_text(errors="replace")
if m["completed"]!=["generate"] or "RhoDMatrix.h" not in log or "Assertion" not in log or "norm.real() > epsa" not in log:
    raise ValueError("Recovery requires a completed hard sample and the native spin-density assertion")
hard_seed=m["seed"]
shower_seed=hard_seed+3000000
lhe=Path(m["lhe_file"])
assert m["lhe"]["sha256"]==sha(lhe) and m["lhe"]["events"]==8000
herwig=work/"herwig"
herwig.mkdir(parents=True,exist_ok=True)
card=m["configuration"]["herwig_card"]
old=f"RandomNumberGenerator:Seed {hard_seed}"
new=f"RandomNumberGenerator:Seed {shower_seed}"
if card.count(old)!=1 or card!=(original/"herwig/bkg_loop_gg_aa.in").read_text():
    raise ValueError("original shower card disagrees with original manifest")
card=card.replace(old,new)
m["configuration"]["herwig_card"]=card
m["fingerprint"]=hashlib.sha256(json.dumps(m["configuration"],sort_keys=True).encode()).hexdigest()
m["shower_recovery"]={"reason":"native RhoDMatrix normalization assertion","hard_seed":hard_seed,
                       "detector_seed":hard_seed,"reshower_seed":shower_seed,"source_lhe_sha256":sha(lhe),
                       "original_manifest_sha256":sha(source_manifest),"failed_log_sha256":sha(original/"herwig/run.log"),
                       "scope":"reshower the complete original finite hard event sample once; original partial shower is excluded"}
mp=work/"campaign.json"
if mp.exists():
    existing=json.loads(mp.read_text())
    if existing["shower_recovery"]!=m["shower_recovery"]:raise ValueError("different recovery already present")
    m=existing
else:
    mp.write_text(json.dumps(m,indent=2)+"\n")
cardfile=herwig/"bkg_loop_gg_aa.in"
if cardfile.exists() and cardfile.read_text()!=card:raise ValueError("existing retry card differs")
cardfile.write_text(card)
conf=m["configuration"]
extra=["--gen-mgg-min","100","--gen-mgg-max","150"] if a.kind=="focus" else []
args=loop.parse_args(["--stage","all","--resume","--run-tag",m["run_tag"],"--output-dir",str(run),
                      "--seed-base",str(hard_seed),"--nevents","8000","--nb-core","1","--ebeam","20000",
                      "--no-herwig-module","--mg5-dir",conf["mg5_dir"],"--mg5-python",conf["mg5_python"],*extra])
loop.lhe_path=lambda args,sample=loop.SAMPLE:lhe
with loop.loop_adapter():
    if "shower" not in m["completed"]:
        loop.shower(args,loop.SAMPLE,m)
        m["completed"].append("shower")
        loop.ho.save_manifest(args,loop.SAMPLE,m)
    if "analyze" not in m["completed"]:
        loop.ho.analyze(args,loop.SAMPLE,m)
        m["completed"].append("analyze")
        loop.ho.save_manifest(args,loop.SAMPLE,m)
# Use the repository version of the Born association for broad samples.
sys.path.insert(0,"/home/apapaefs/HiggsSSC")
import hgammagamma
hgammagamma.__path__.append("/home/apapaefs/HiggsSSC/hgammagamma")
result=extract(work,a.kind)
result["shower_recovery"]=m["shower_recovery"]
assert result["source_lhe_sha256"]==m["lhe"]["sha256"] and result["generated_events"]==8000
temp=a.output.with_suffix(".tmp")
temp.write_text(json.dumps(result,allow_nan=False,separators=(",",":"))+"\n")
temp.replace(a.output)
