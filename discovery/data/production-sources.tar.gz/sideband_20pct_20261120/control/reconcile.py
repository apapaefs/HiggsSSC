"""Publish consecutive closed blocks and reconcile repaired inputs for the original live dispatchers."""
import ast
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


CONTROL = Path(__file__).resolve().parent
RUN = CONTROL.parent
FAKE = RUN / "fake_loop"
DIJET = FAKE / "dijet"
READY = RUN / "ready/dijet"
TEMP = CONTROL / "recovered_blocks"


def closed(index):
    shard = DIJET / "shards" / f"{index:04d}"
    if not (shard / "spectrum.json").is_file():
        return False
    if not (shard / "native_failure.json").is_file():
        return True
    return (DIJET / "recovery" / f"{index:04d}" / "replacement_comparison.json").is_file()


def publish_prefix(number_of_blocks):
    for block in range(number_of_blocks):
        name = f"dijet_{block:04d}.json"
        dest = READY / name
        if dest.is_file():
            continue
        start = 5000 + block * 25
        stop = start + 25
        if not all(closed(i) for i in range(start, stop)):
            return
        tmp = TEMP / name
        subprocess.run([sys.executable, str(DIJET / "pool.py"), "--first", str(start),
                        "--stop", str(stop), "--output", str(tmp)], check=True)
        packet = json.loads(tmp.read_bytes())
        seeds = {19000000 + 101 * i for i in range(start, stop)}
        if (packet["generated_events"] != 1250000 or {r["seed"] for r in packet["shards"]} != seeds
                or any(r["events"] != 50000 or hashlib.sha256((DIJET / r["path"]).read_bytes()).hexdigest()
                       != r["sha256"] for r in packet["shards"])):
            raise ValueError(f"Inconsistent input for {name}")
        try:
            os.link(tmp, dest)
        except FileExistsError:
            if dest.read_bytes() != tmp.read_bytes():
                raise ValueError(f"Simultaneous publications disagree for {name}")
        tmp.unlink()


def certified_failure(kind, key):
    if kind == "dijet":
        return closed(int(key))
    domain, index = ast.literal_eval(key)
    return (RUN / "ready/loop" / f"loop_{domain}_{index:04d}.json").is_file()


def reconcile_exit(kind, state):
    if state["status"] != "errors" or state["active"] or not state["failures"]:
        return
    if not all(certified_failure(kind, key) for key in state["failures"]):
        return
    proc = Path("/proc") / str(state["pid"]) / "cmdline"
    if proc.exists() and b"dispatch.py" in proc.read_bytes():
        return
    marker = CONTROL / f"reconcile_{kind}_{state['pid']}.json"
    if marker.exists() and time.time() - marker.stat().st_mtime < 300:
        return
    mask = (FAKE / kind / "cpus.txt").read_text().strip()
    args = [kind, "--cpus", mask]
    if kind == "dijet":
        args += ["--blocks", str(state["target_tasks"] // 25)]
    else:
        # The first campaign request is 44 focused plus 13 broad samples.
        if state["target_tasks"] != 57:
            raise ValueError("Unexpected loop request for original-controller recovery")
        args += ["--focused", "44", "--broad", "13"]
    subprocess.run(["screen", "-dmS", f"ssc20pct_reconcile_{kind}", "bash",
                    str(FAKE / "start.sh"), *args], check=True)
    marker.write_text(json.dumps(args) + "\n")


def main():
    lock = (CONTROL / ".reconcile.lock").open("a")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    TEMP.mkdir(exist_ok=True)
    while not (CONTROL / "final_reach.json").exists():
        for kind in ("dijet", "loop"):
            state = json.loads((FAKE / kind / "progress.json").read_bytes())
            if kind == "dijet":
                publish_prefix(state["target_tasks"] // 25)
            reconcile_exit(kind, state)
        time.sleep(60)


if __name__ == "__main__":
    main()
