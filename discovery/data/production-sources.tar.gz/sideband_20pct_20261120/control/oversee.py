"""Redistribute idle Timur cores and close the discovery fit after production drains."""
import datetime
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import time

HERE = Path(__file__).resolve().parent
RUN = HERE.parent
FOLDERS = {"dijet": RUN / "fake_loop/dijet", "loop": RUN / "fake_loop/loop", "nlo": RUN / "nlo"}
QUIET = {"finished", "drained_after_target"}


def read(path):
    return json.loads(path.read_text())


def replace(path, content):
    if path.exists() and path.read_text() == content:
        return
    temp = path.with_name(path.name + ".supervisor.tmp")
    temp.write_text(content)
    temp.replace(path)


def save(path, value):
    replace(path, json.dumps(value, indent=2, allow_nan=False) + "\n")


def parse_mask(mask):
    cpus = set()
    for part in mask.split(","):
        ends = list(map(int, part.split("-")))
        cpus.update(range(ends[0], ends[-1] + 1))
    return cpus


def distribute(initial, states):
    # Only donate a producer's CPUs once every one of its admitted jobs has drained.
    # Keep previously borrowed CPUs with their running owners.
    running = {g for g, s in states.items() if s.get("status") == "running"}
    quiet = {g for g, s in states.items() if s.get("status") in QUIET and not s.get("active")}
    loans = set().union(*(initial[g] for g in quiet))
    masks = {g: set(initial[g]) for g in running}
    for g in sorted(running):
        current = FOLDERS[g] / "cpus.txt"
        already = parse_mask(current.read_text().strip()) & loans if current.exists() else set()
        masks[g].update(already)
        loans -= already
    for cpu in sorted(loans, key=lambda n: (n % 40, n // 40)):
        if not running:
            break
        g = min(sorted(running), key=lambda name: len(masks[name]) / len(initial[name]))
        masks[g].add(cpu)
    for g, cpus in masks.items():
        path = FOLDERS[g] / "cpus.txt"
        if cpus != parse_mask(path.read_text().strip()):
            replace(path, ",".join(map(str, sorted(cpus))) + "\n")
    return {g: len(mask) for g, mask in masks.items()}


def inputs_current(reach, paths):
    hashes = reach["new_inputs_sha256"]
    return set(hashes) == set(map(str, paths)) and all(
        hashlib.sha256(p.read_bytes()).hexdigest() == hashes[str(p)] for p in paths)


def restart_drained(kind, states, arguments):
    folder = FOLDERS[kind]
    old_pid = states[kind]["pid"]
    # Suppress duplicate submissions while a replacement controller initializes.
    lease = HERE / (kind + "_restart.json")
    if lease.exists() and read(lease)["old_pid"] == old_pid and time.time() - read(lease)["time"] < 300:
        return
    if (Path("/proc") / str(old_pid) / "cmdline").exists():
        cmd = (Path("/proc") / str(old_pid) / "cmdline").read_bytes()
        if (kind == "nlo" and b"farm.py" in cmd) or (kind != "nlo" and b"dispatch.py" in cmd):
            return
    script = folder / "start.sh" if kind == "nlo" else folder.parent / "start.sh"
    subprocess.run(["screen", "-dmS", "ssc20pct_resume_" + kind, "bash", str(script), *arguments], check=True)
    save(lease, {"old_pid": old_pid, "time": time.time(), "arguments": arguments})


def after_drain(reach, states):
    paths = [p for g in FOLDERS for p in (RUN / "ready" / g).glob("*.json")]
    if not inputs_current(reach, paths):
        return "awaiting completed-packet refit"
    latest = RUN / "fit/latest_fit.json"
    if hashlib.sha256(latest.read_bytes()).hexdigest() != reach["fit_sha256"]:
        return "awaiting consistent fit and summary"
    ratios = reach["precision_target"]["ratios_by_model"]
    if (set(ratios) == {"exponential2", "power2", "exponential3"}
            and all(x is not None and 0 < x <= 1.20 for x in ratios.values())):
        marker = RUN / "fit/TARGET_REACHED.json"
        if not marker.exists() or read(marker)["fit_sha256"] != reach["fit_sha256"]:
            return "awaiting fitted target marker"
        expected = set(read(HERE / "campaign.json")["prior_generated_events"])
        if set(reach["new_generated_events"]) != expected:
            raise ValueError("Missing one or more production strata in the final refit")
        shutil.copyfile(latest, HERE / "final_fit.json.tmp")
        (HERE / "final_fit.json.tmp").replace(HERE / "final_fit.json")
        save(HERE / "final_reach.json", reach)
        return "complete"

    # On a close miss, accumulate another independently seeded tranche of the
    # two dominant sources. A fresh fit decides whether further work is needed.
    plan_path = FOLDERS["nlo"] / "targets.json"
    goals = read(plan_path)
    done = states["nlo"]["completed"]
    if any(done[k] < goals[k] for k in goals):
        restart_drained("nlo", states, [])
        return "extending NLO production"
    fit = read(latest)
    extend_other_sources = False
    for model in fit["models"].values():
        v = model["variance_by_sample"]
        fixed_variance = sum(x for k, x in v.items() if k not in {"bkg_prompt_aa", "bkg_gamma_j"})
        if fixed_variance > .075 ** 2:
            extend_other_sources = True
    if extend_other_sources:
        # Reclaim the original disjoint core sets before restarting more than one family.
        initial = read(HERE / "campaign.json")["initial_logical_cpu_masks"]
        for name, mask in initial.items():
            replace(FOLDERS[name] / "cpus.txt", mask + "\n")
        dijet_blocks = len(list((RUN / "ready/dijet").glob("dijet_*.json")))
        loop = RUN / "ready/loop"
        nfocus = len(list(loop.glob("loop_focus_*.json")))
        nbroad = len(list(loop.glob("loop_broad_*.json")))
        restart_drained("dijet", states, ["dijet", "--cpus", initial["dijet"], "--blocks",
                                          str(dijet_blocks + max(2, math.ceil(.10*dijet_blocks)))])
        restart_drained("loop", states, ["loop", "--cpus", initial["loop"], "--focused",
                                         str(nfocus + max(1, math.ceil(.10*nfocus))), "--broad",
                                         str(nbroad + max(1, math.ceil(.10*nbroad)))])
    totals = reach["total_generated_by_stratum"]
    for mode, sample in (("prompt", "bkg_prompt_aa/full"), ("gammaj", "bkg_gamma_j/full")):
        goals[mode] += 250000 * math.ceil(.08 * totals[sample] / 250000)
    save(plan_path, goals)
    restart_drained("nlo", states, [])
    return "extending NLO production"


def main():
    lock = (HERE / ".oversee.lock").open("a")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    initial = {g: parse_mask(mask) for g, mask in read(HERE / "campaign.json")["initial_logical_cpu_masks"].items()}
    while True:
        states = {g: read(f / "progress.json") if (f / "progress.json").exists() else {}
                  for g, f in FOLDERS.items()}
        reach_path = RUN / "fit/reach.json"
        reach = read(reach_path) if reach_path.exists() else {}
        marker = (RUN / "fit/TARGET_REACHED.json").exists()
        masks = distribute(initial, states) if not marker else {}
        stage = "draining after target" if marker else "production"
        if reach and all(s.get("status") in QUIET and not s.get("active") for s in states.values()):
            stage = after_drain(reach, states)
        status = {g: {"status": s.get("status", "starting"), "active": len(s.get("active", {})),
                      "completed": s.get("completed_events", s.get("completed")),
                      "failures": s.get("failures", s.get("blocked_requests", []))}
                  for g, s in states.items()}
        save(HERE / "status.json", {
            "updated_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "pid": os.getpid(), "stage": stage, "workers": status, "logical_cpus": masks,
            "disk_free_GiB": round(shutil.disk_usage(RUN).free / (1 << 30), 1),
            "fit_receipts": reach.get("extra_receipts"), "new_generated_events_in_fit": reach.get("new_generated_events"),
            "target": reach.get("precision_target")})
        if stage == "complete":
            return
        time.sleep(45)


if __name__ == "__main__":
    main()
