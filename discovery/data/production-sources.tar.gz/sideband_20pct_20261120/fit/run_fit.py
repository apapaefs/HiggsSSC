"""Update the 40 TeV discovery fit from immutable, complete background spectra."""
import argparse
import datetime
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import tempfile
import time

# Small Hessians and covariances use one CPU while the generators fill the machine.
for variable in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS",
                 "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[variable] = "1"

HERE = Path(__file__).resolve().parent
PRIOR = HERE / "prior"
sys.path.insert(0, str(PRIOR))
from compare_shapes import compare
from refit import EDGES, curve, pool, study


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def atomic_json(path, obj):
    with tempfile.NamedTemporaryFile("w", dir=path.parent, delete=False) as stream:
        json.dump(obj, stream, indent=2, allow_nan=False)
        stream.write("\n")
    Path(stream.name).replace(path)


def prior_inputs():
    manifest = json.loads((PRIOR / "manifest.json").read_text())
    if digest(PRIOR / "baseline.json") != manifest["baseline_sha256"]:
        raise ValueError("Original analysis baseline changed")
    if digest(PRIOR / "all_completed_fit.json") != manifest["prior_fit_sha256"]:
        raise ValueError("Precampaign fit changed")
    paths = []
    for row in manifest["packets"]:
        path = PRIOR / row["file"]
        if digest(path) != row["sha256"]:
            raise ValueError(f"Changed precampaign packet {path}")
        paths.append(path)
    return manifest, paths


def read_packet_hashes(ready):
    # Only direct descendants of the specified producer directory are consumable.
    return {str(path.resolve()): digest(path) for dirname in ready
            for path in sorted(dirname.glob("*.json"))}


def compare_prior(fit):
    expected = json.loads((PRIOR / "all_completed_fit.json").read_text())
    def check(value, old):
        if isinstance(old, dict):
            assert value.keys() == old.keys()
            for name in old:
                check(value[name], old[name])
        elif isinstance(old, list):
            assert len(value) == len(old)
            for entry, other in zip(value, old):
                check(entry, other)
        elif isinstance(old, float):
            if not math.isclose(old, value, abs_tol=3.e-6, rel_tol=2.e-6):
                raise ValueError(f"Precampaign replay changed: {value} vs {old}")
        elif value != old:
            raise ValueError(f"Precampaign replay changed: {value} vs {old}")
    for name in ("signal_per_bin_fb", "background_per_bin_fb", "models", "smooth_continuum",
                 "empirically_calibrated_bias", "fixed_125_GeV_background_only_closure",
                 "generated_exposures", "fourlepton_rates_fb"):
        check(fit[name], expected[name])


def update(out, manifest, old_packets, new_hashes):
    base = json.loads((PRIOR / "baseline.json").read_text())
    paths = old_packets + list(map(Path, sorted(new_hashes)))
    h, c, strata, independent, counts, inputs = pool(base, paths)
    result = study(h, c, strata, independent, base["fourlepton"])
    for receipt in inputs[len(old_packets):]:
        if receipt["sha256"] != new_hashes[receipt["path"]]:
            raise ValueError(f"Packet changed during fit: {receipt['path']}")
    result.pop("precision_target")   # Historical threshold was sigma_mu <= 0.2.
    result.update(generated_exposures=counts, fourlepton_rates_fb=base["fourlepton"],
                  independent_new_inputs=inputs, edges_gev=EDGES.tolist(),
                  reference_sha256=manifest["baseline_sha256"],
                  precampaign_fit_sha256=manifest["prior_fit_sha256"])
    if not new_hashes:
        compare_prior(result)

    candidate = out / "fit_candidate.json"
    atomic_json(candidate, result)
    shapes = compare(candidate)["continuum_models"]
    ratios = {}
    for name, model in shapes.items():
        lumi = model["calibrated_diphoton_fb_inverse"]
        ratios[name] = None if lumi is None else lumi / model["smooth_diphoton_fb_inverse"]
        model["smooth_diphoton_design_months"] = 1.2 * model["smooth_diphoton_fb_inverse"]
        information = result["models"][name]["shape_q0_per_fb"]
        model["smooth_combined"] = curve(lambda lum: information * lum, base["fourlepton"])
    passed = all(value is not None and value <= 1.2 for value in ratios.values())
    target = {"definition": "Each fitted calibrated diphoton-only median local 5-sigma luminosity"
                            " divided by its own smooth-continuum median must be at most 1.20.",
              "ratios_by_model": ratios, "achieved": passed}
    result["precision_target"] = target
    atomic_json(out / "latest_fit.json", result)
    candidate.unlink()
    added = {}
    for receipt in inputs[len(old_packets):]:
        name = receipt["sample"] + "/" + receipt["stratum"]
        added[name] = added.get(name, 0) + receipt["generated_events"]
    summary = {
        "updated_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "fit_sha256": digest(out / "latest_fit.json"),
        "precampaign_fit_sha256": manifest["prior_fit_sha256"],
        "precampaign_receipts": len(old_packets), "extra_receipts": len(new_hashes),
        "new_generated_events": added,
        "total_generated_by_stratum": {
            f"{sample}/{kind}": row["generated_including_reference"]
            for sample, groups in counts.items() for kind, row in groups.items()},
        "design_fb_inverse_per_year": 10, "fixed_mass_GeV": 125,
        "combination_method": "Gaussian diphoton score and exact Poisson four-lepton counts.",
        "precision_target": target, "continuum_models": shapes, "new_inputs_sha256": new_hashes}
    atomic_json(out / "reach.json", summary)
    marker = out / "TARGET_REACHED.json"
    if passed:
        atomic_json(marker, {"fit_sha256": summary["fit_sha256"],
                            "extra_receipts": len(new_hashes), **target})
    elif marker.exists():
        marker.unlink()
    print(summary["updated_utc"], len(new_hashes), added, ratios, flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--watch", action="store_true")
    parser.add_argument("--interval", type=int, default=120)
    parser.add_argument("--out", type=Path, default=HERE)
    parser.add_argument("--receipts", type=Path, nargs="+", default=[
        HERE.parent / "ready" / name for name in ("dijet", "loop", "nlo")])
    args = parser.parse_args()
    if args.interval <= 0:
        parser.error("Polling interval must be positive")
    args.out.mkdir(parents=True, exist_ok=True)
    manifest, prior = prior_inputs()
    while True:
        with (args.out / ".update.lock").open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            known = args.out / "reach.json"
            last = json.loads(known.read_text()) if known.is_file() else {}
            hashes = read_packet_hashes(args.receipts)
            if any(hashes.get(p) != h for p, h in last.get("new_inputs_sha256", {}).items()):
                raise ValueError("A previously analyzed packet changed or disappeared")
            fit_path = args.out / "latest_fit.json"
            marker = args.out / "TARGET_REACHED.json"
            consistent = (last and fit_path.is_file() and digest(fit_path) == last["fit_sha256"]
                          and (not marker.exists() and not last["precision_target"]["achieved"]
                               or marker.exists() and last["precision_target"]["achieved"]
                               and json.loads(marker.read_text())["fit_sha256"] == last["fit_sha256"]))
            if not consistent or last["new_inputs_sha256"] != hashes or not args.watch:
                update(args.out, manifest, prior, hashes)
        if not args.watch:
            break
        time.sleep(args.interval)


if __name__ == "__main__":
    main()
