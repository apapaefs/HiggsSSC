"""Prespecified closure diagnostics and empirical signal-shaped bias calibration at 125 GeV."""
from functools import lru_cache
import math

import numpy as np
from scipy.optimize import brentq, root
from scipy.stats import chi2, norm

from continuum_fit import ALL, BLIND, EDGES, Shape


def residuals(delta, covariance):
    sigma = np.sqrt(np.maximum(np.diag(covariance), 0.))
    pulls = [float(d/e) if e>0 else None for d,e in zip(delta,sigma)]
    return {"difference_fb":delta.tolist(),"mc_sigma_fb":sigma.tolist(),"pull":pulls}


def evaluate(hist, cov, independent):
    sum_background = sum(h for k,h in hist.items() if k.startswith("bkg"))
    sum_cov = sum(c for k,c in cov.items() if k.startswith("bkg"))
    signal = sum(h for k,h in hist.items() if k.startswith("signal"))
    shape = Shape("exponential",2)
    theta, curve, jac, sideband_grad = shape.fit(sum_background,~BLIND)
    # Propagate the same independent sources through both the sideband fit and the bins.
    nuisance_response = np.eye(len(curve))-jac@sideband_grad
    resid_cov = nuisance_response@sum_cov@nuisance_response.T
    difference = sum_background-curve
    center = difference[BLIND]
    center_cov = resid_cov[np.ix_(BLIND,BLIND)]
    rank = int(np.linalg.matrix_rank(center_cov,hermitian=True))
    chi = float(center@np.linalg.pinv(center_cov,hermitian=True)@center)
    params,_,_,full_derivative = shape.fit(sum_background,ALL,signal)
    g = full_derivative[-1]
    mu = float(params[-1])
    sigma = math.sqrt(float(g@sum_cov@g))
    z = mu/sigma
    central_ci = [mu-norm.ppf(.975)*sigma,mu+norm.ppf(.975)*sigma]
    sections={}
    for key,(ref,extra,cr,ce) in independent.items():
        change=extra-ref
        cm=cr+ce
        window=BLIND.astype(float)
        sections["/".join(key)] = dict(**residuals(change,cm),
              window_difference_fb=float(window@change),
              window_mc_error_fb=float(np.sqrt(window@cm@window)),
              induced_mu_difference=float(g@change),
              induced_mu_mc_error=float(np.sqrt(g@cm@g)))
    result={"definition":"Primary test fixed at 125 GeV in 55 bins of width 1 GeV, floating exponential quadratic. MC standard errors use complete signed source-event outer products. The single-mass Gaussian p-value tests zero fitted spurious strength. Binwise pulls use source covariance propagated through the fit to sidebands (no Higgs region used); the global chi-square sums only the 10 blinded bins and includes their covariance. The optional new-minus-reference comparisons use disjoint exposures with all other components shared.",
            "nominal_spurious_mu":mu,"mc_sigma_mu":sigma,"z_vs_zero":z,
            "two_sided_p_approx":float(2*norm.sf(abs(z))),"mc_95pct_interval_mu":central_ci,
            "zero_excluded_at_95pct":bool(central_ci[0]>0. or central_ci[1]<0.),
            "abs_mu_below_point_two_at_95pct":bool(central_ci[0]>-.2 and central_ci[1]<.2),
            "window_120_130":{"chi2":chi,"rank":rank,"p_approx":float(chi2.sf(chi,rank)) if rank else None,
                              "sum_residual_fb":float(center.sum()),"sigma_sum_fb":float(np.sqrt(np.maximum(center_cov.sum(),0.)))},
            "mass_bin_edges_GeV":EDGES.tolist(),"all_bin_sideband_fit_residuals":residuals(difference,resid_cov),
            "independent_new_minus_reference":sections}
    return result,shape,theta,curve,signal


class Calibration:
    """Profile the Poisson means of every bin and the Gaussian background calibration."""
    def __init__(self, shape, sideband_theta, continuum, signal, center, width):
        self.shape = shape
        self.theta = sideband_theta
        self.signal = signal
        self.center,self.width = center,width
        self.truth = continuum+(1.+center)*signal
        if np.any(self.truth<=0.) or np.any(continuum+center*signal<=0.) or width<=0.:
            raise ValueError("Invalid calibration or nonpositive nominal model")

    @lru_cache(maxsize=128)
    def q(self, luminosity):
        s = self.signal
        penalty_per_fb = 1./(self.width*self.width*luminosity)
        def score(a):
            m,db,hh = self.shape.get(a[:-1],True)
            m += (self.center+a[-1])*s
            if np.any(m<=0.):
                raise ValueError("Nonpositive mean encountered in calibration")
            D = np.column_stack((db,s))
            frac = (m-self.truth)/m
            grad = D.T@frac
            grad[-1] += a[-1]*penalty_per_fb
            H = D.T@((self.truth/m**2)[:,None]*D)
            H[:-1,:-1] += np.einsum("n,nij->ij",frac,hh)
            H[-1,-1] += penalty_per_fb
            return grad,H
        ans=root(score,np.r_[self.theta,1./(1.+penalty_per_fb/8.)],jac=True,tol=1.e-11)
        grad,H=score(ans.x)
        if np.max(np.abs(grad))>1.e-6 or np.min(np.linalg.eigvalsh(H))<=0.:
            raise ValueError("Poisson calibration did not reach a likelihood minimum")
        m=self.shape.get(ans.x[:-1])[0]+(self.center+ans.x[-1])*s
        r=(m-self.truth)/self.truth
        small = np.abs(r)<1.e-4
        kl = r-np.log1p(r)
        t = r[small]
        kl[small] = t**2*(.5+t*(-1./3.+t*(.25-.2*t)))
        return float(2*luminosity*(self.truth@kl)+(ans.x[-1]/self.width)**2)

    def diphoton_reach(self):
        if self.width>=.2:
            return None
        upper=1.
        while self.q(upper)<25.:
            upper*=2.
        return float(brentq(lambda L:self.q(L)-25.,1.e-8,upper))
