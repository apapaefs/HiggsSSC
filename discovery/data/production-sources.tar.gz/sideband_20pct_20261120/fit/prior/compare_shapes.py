"""Repeat the calibrated discovery test for each fitted continuum family."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from refit import BLIND, Calibration, Shape, curve


def compare(result_path):
    raw = result_path.read_bytes()
    fit = json.loads(raw)
    b = np.asarray(fit["background_per_bin_fb"])
    s = np.asarray(fit["signal_per_bin_fb"])
    rows = {}
    for family, degree in (("exponential", 2), ("power", 2), ("exponential", 3)):
        name = f"{family}{degree}"
        model = fit["models"][name]
        shape = Shape(family, degree)
        theta, continuum, _, _ = shape.fit(b, ~BLIND)
        width = model["spurious_signal_mc_error"]
        cal = Calibration(shape, theta, continuum, s, model["spurious_signal_mu"], width)
        luminosity = cal.diphoton_reach()
        rows[name] = {
            "spurious_mu": model["spurious_signal_mu"],
            "sigma_mu": width,
            "limiting_diphoton_significance": 1 / width,
            "smooth_diphoton_fb_inverse": 25 / model["shape_q0_per_fb"],
            "calibrated_diphoton_fb_inverse": luminosity,
            "calibrated_diphoton_design_months": 1.2 * luminosity if luminosity is not None else None,
            "calibrated_combined": curve(cal.q, fit["fourlepton_rates_fb"]),
        }
    return {"source_sha256": hashlib.sha256(raw).hexdigest(), "continuum_models": rows}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("fit", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.write_text(json.dumps(compare(args.fit), indent=2, allow_nan=False) + "\n")
