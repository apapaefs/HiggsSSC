"""Blinded sideband fits and spurious-signal closure using independent source weights."""
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.optimize import minimize, root
from scipy.sparse import coo_matrix

HERE = Path(__file__).resolve().parent
CSV = HERE.parent / 'scores.csv'
EDGES = np.arange(105., 161.)
MASS = (EDGES[1:] + EDGES[:-1]) / 2
BLIND = (MASS >= 120) & (MASS < 130)
ALL = np.ones_like(BLIND)
WINDOW = (MASS >= 123) & (MASS < 127)
NODES, WEIGHTS = np.polynomial.legendre.leggauss(6)
POINTS = MASS[:, None] + NODES / 2

def source_histograms():
    data = {}
    with CSV.open() as f:
        for r in csv.DictReader(f):
            m = float(r['m_gg'])
            if not EDGES[0] <= m < EDGES[-1] or float(r['n_selected_photons']) < 2:
                continue
            source, bins, weights = data.setdefault(r['sample'], ([], [], []))
            source.append(int(r['sourceevent']))
            bins.append(int(m - EDGES[0]))
            weights.append(float(r['physical_weight']) / 100.)
    h, covariance = {}, {}
    for sample, (sources, bins, weights) in data.items():
        _, rid = np.unique(sources, return_inverse=True)
        matrix = coo_matrix((weights, (rid, bins)), shape=(1+max(rid), MASS.size)).tocsr()
        h[sample] = np.asarray(matrix.sum(axis=0)).ravel()
        covariance[sample] = (matrix.T @ matrix).toarray()
    return h, covariance

class Shape:
    def __init__(self, family, degree):
        t = (POINTS - 125.) / 25. if family=='exponential' else 5 * np.log(POINTS/125.)
        self.x = np.stack([t**i for i in range(degree+1)], axis=-1)
        self.degree = degree

    def get(self, theta, hessian=False):
        expterms = np.exp(self.x @ theta) * WEIGHTS / 2
        mean = expterms.sum(axis=1)
        jac = np.einsum('nq,nqd->nd', expterms, self.x)
        if hessian:
            return mean, jac, np.einsum('nq,nqi,nqj->nij', expterms, self.x, self.x)
        return mean, jac

    def fit(self, observation, mask, signal=None):
        pars = self.degree+1
        init = [np.log(np.median(observation[mask])), -.65] + [0.]*(pars-2)
        if signal is not None: init += [0.]
        def objective(a):
            mean, jac = self.get(a[:pars])
            if signal is not None:
                mean += a[-1] * signal
                jac = np.column_stack((jac, signal))
            mean, y, jac = mean[mask], observation[mask], jac[mask]
            if np.min(mean) <= 0 or not np.isfinite(mean).all():
                return 1e32, np.ones_like(a)*1e12
            return np.sum(mean-y+y*np.log(y/mean)), jac.T@(1-y/mean)
        opt = minimize(objective, init, jac=True, method='BFGS',options={'gtol':1e-8})
        if np.linalg.norm(opt.jac,np.inf)>1.e-4:
            def scores_and_hess(a):
                m,jac,hm=self.get(a[:pars],True)
                if signal is not None:
                    m+=a[-1]*signal
                    jac=np.column_stack((jac,signal))
                mj,obs,j=m[mask],observation[mask],jac[mask]
                h=j.T@((obs/mj**2)[:,None]*j)
                h[:pars,:pars]+=np.einsum('n,nij->ij',(1-obs/mj),hm[mask])
                return j.T@(1-obs/mj),h
            trial=root(scores_and_hess,opt.x,jac=True,tol=1.e-10)
            if not trial.success or np.linalg.norm(scores_and_hess(trial.x)[0],np.inf)>1.e-4 or objective(trial.x)[0]>opt.fun+1.e-6:
                raise ValueError((opt.message,opt.jac.tolist(),trial.message))
            opt.x=trial.x
        theta = opt.x[:pars]
        mean, jac, hb = self.get(theta, True)
        m = mean.copy()
        if signal is not None:
            m += opt.x[-1] * signal
            jac = np.column_stack((jac, signal))
        hess = jac[mask].T @ ((observation[mask]/m[mask]**2)[:,None]*jac[mask])
        hess[:pars,:pars] += np.einsum('n,nij->ij', (1-observation[mask]/m[mask]),hb[mask])
        sensitivity = np.zeros((len(opt.x),len(mask)))
        sensitivity[:,mask] = np.linalg.solve(hess,(jac[mask]/m[mask,None]).T)
        return opt.x, mean, jac, sensitivity

def analyze(hist, cov):
    s = sum(v for k,v in hist.items() if k.startswith('signal'))
    b = sum(v for k,v in hist.items() if k.startswith('bkg'))
    cb = sum(v for k,v in cov.items() if k.startswith('bkg'))
    def stat(deriv, cm):
        return float(np.sqrt(np.maximum(deriv@cm@deriv,0.)))
    models = {}
    for family, degree in [('exponential',2),('power',1),('power',2),('exponential',1),('exponential',3)]:
        shape = Shape(family,degree)
        _,fitted,j,dth=shape.fit(b,~BLIND)
        def window_test(w):
            grad = w.astype(float) - j[w].sum(axis=0)@dth
            return {'predicted_fb':fitted[w].sum(), 'MC_fb':b[w].sum(), 'signal_fb':s[w].sum(),
                    'closure_difference_MC_minus_fit_fb':(b[w]-fitted[w]).sum(),
                    'closure_MC_error_fb':stat(grad,cb)}
        truth=fitted+s
        _,fit0,_,_=shape.fit(truth,ALL)
        q=2*np.sum(fit0-truth+truth*np.log(truth/fit0))
        spur,_,_,ds=shape.fit(b,ALL,s)
        alt_truth=Shape('exponential',2).fit(b,~BLIND)[1] + s
        altfit0=shape.fit(alt_truth,ALL)[1]
        altfit1=shape.fit(alt_truth,ALL,s)
        fit1=altfit1[1]+altfit1[0][-1]*s
        q_on_same_truth=2*np.sum(altfit0-fit1+alt_truth*np.log(fit1/altfit0))
        sbfit_spur,_,_,_=shape.fit(alt_truth-s,ALL,s)
        models[f'{family}{degree}']={'blinded_fit_per_bin_fb':fitted.tolist(),'shape_parameters':shape.fit(b,~BLIND)[0].tolist(),'sideband_mc_residual_rms_frac':float(np.std((b/fitted-1)[~BLIND])),
           'closure_123_127':window_test(WINDOW),'closure_120_130':window_test(BLIND),
           'q0_per_fb_Asimov_fitted_continuum':q,'L5_Asimov_fb_inverse':25./q,
           'q0_per_fb_fix_truth_to_exponential2':q_on_same_truth,
           'spurious_signal_mu_on_exponential2_blinded_truth':sbfit_spur[-1],
           'spurious_signal_mu_on_actual_bkg_MC':spur[-1], 'spurious_signal_mc_standard_error':stat(ds[-1],cb),
           'spurious_mu_mc_errors_by_source':{k:stat(ds[-1],v) for k,v in cov.items() if k.startswith('bkg')}}
    return {'input':str(CSV),'input_sha256':hashlib.file_digest(CSV.open('rb'),'sha256').hexdigest(),
            'method':'All partitions with physical weights projected to 1 fb^-1, eligible photon pairs, inclusive in classifier score. Fit continuum shape in the 105–120 and 130–160 GeV sidebands only. For Asimov discovery, use all 55 bins, full signal template, free shape coefficients including normalization and nonnegative signal strength. Each simple shape forecasts data in its own smooth fitted model. The two additional diagnostics use the same smooth quadratic truth or all actual background MC bins and allow signed spurious signal. Projected shape follows pseudo-data Poisson weights; independent source-event covariances quantify MC closure error using the derivative of the fit equations.',
            'mass_bin_edges_GeV':EDGES.tolist(), 'signal_per_bin_fb':s.tolist(), 'simulated_total_background_per_bin_fb':b.tolist(),
            'sample_rates_fb_by_bin':{k:v.tolist() for k,v in hist.items()},
            'component_covariance_fb_squared':{k:v.tolist() for k,v in cov.items()},
            'signal_total_fit_range_fb':s.sum(), 'signal_sideband_fb':s[~BLIND].sum(),'minimum_signal_bin_fb':s.min(),
            'models':models}
if __name__=='__main__':
    hist,cov=source_histograms()
    result=analyze(hist,cov)
    (HERE/'continuum_fit.json').write_text(json.dumps(result,indent=2)+'\n')
    print('signal range and sidebands',result['signal_total_fit_range_fb'],result['signal_sideband_fb'])
    for model,r in result['models'].items():
        print(model,'central',r['closure_123_127'],'L5',r['L5_Asimov_fb_inverse'],'spurious',r['spurious_signal_mu_on_actual_bkg_MC'],r['spurious_signal_mc_standard_error'],r['spurious_mu_mc_errors_by_source'])
