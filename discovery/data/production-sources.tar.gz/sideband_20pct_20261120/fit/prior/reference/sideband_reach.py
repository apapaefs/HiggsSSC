"""Profile a mass-sideband counting experiment and combine it with sparse 4l.

All input rates are per inverse femtobarn. The sideband rate can include
multiple disjoint intervals. Signal in the sidebands enters both hypotheses
at its appropriate strength. The total continuum normalization floats freely.
"""
from dataclasses import dataclass
import math

import numpy as np
from scipy.optimize import brentq
from scipy.special import betainc, expit, ndtr, xlogy
from scipy.stats import binom, norm, poisson


ALPHA = norm.sf(5.)


@dataclass(frozen=True)
class OnOff:
    signal_peak: float
    background_peak: float
    signal_side: float
    background_side: float
    log_transfer_error: float = 0.

    def __post_init__(self):
        if min(self.background_peak, self.background_side) <= 0 or min(
                self.signal_side, self.signal_peak, self.log_transfer_error) < 0:
            raise ValueError("Invalid signal, background or transfer input")
        if self.signal_peak * self.background_side <= self.signal_side * self.background_peak:
            raise ValueError("Signal must be enriched in the chosen peak region")

    @property
    def total_alternative(self):
        return self.background_peak + self.background_side + self.signal_peak + self.signal_side

    @property
    def p0(self):
        return self.background_peak / (self.background_peak + self.background_side)

    @property
    def p1(self):
        return (self.background_peak + self.signal_peak) / self.total_alternative

    @property
    def log_transfer_shift(self):
        return (math.log1p(self.signal_peak / self.background_peak)
                - math.log1p(self.signal_side / self.background_side))

    def q_asimov(self, luminosity):
        """Profile a Gaussian auxiliary measurement of log(Bpeak/Bside)."""
        theta0 = math.log(self.background_peak / self.background_side)
        expected_total = luminosity * self.total_alternative
        p1 = self.p1
        penalty = 0.
        shifted = self.p0
        if self.log_transfer_error > 0:
            variance = self.log_transfer_error ** 2
            shift = brentq(lambda x: variance * expected_total * (expit(theta0 + x) - p1) + x,
                           0., self.log_transfer_shift)
            shifted = expit(theta0 + shift)
            penalty = shift * shift / variance
        kl = xlogy(p1, p1/shifted) + xlogy(1.-p1, (1.-p1)/(1.-shifted))
        return max(0., 2. * expected_total * kl + penalty)

    def limiting_z(self):
        return self.log_transfer_shift / self.log_transfer_error if self.log_transfer_error else math.inf

    def diphoton_asimov(self):
        if self.limiting_z() <= 5.:
            return None
        return reach(lambda L: self.q_asimov(L)-25.)


def reach(difference):
    upper = 1.
    while difference(upper) < 0.:
        upper *= 2.
        if upper > 1.e7:
            raise ValueError("No crossing within luminosity range")
    return float(brentq(difference, 1.e-8, upper, xtol=2.e-7))


def fourlepton_information(signal, background):
    return 2.*((signal+background)*math.log1p(signal/background)-signal)


def joint_power(qgamma, luminosity, s4, b4):
    """Gaussian diphoton likelihood score and the exact discrete 4l counts.

    Under H0 the gamma log likelihood ratio is N(-q/2,q). Under H1 it is
    N(q/2,q). This local normal approximation is appropriate for a smooth,
    high-count diphoton fit. The two independent channels share SM strength
    one and the 4l background is fixed at the supplied scenario.
    """
    q = qgamma(luminosity)
    if q <= 0.:
        raise ValueError("This Gaussian-score combination requires positive diphoton information")
    sd = math.sqrt(q)
    k = np.arange(2+int(poisson.isf(1.e-14,(s4+b4)*luminosity)))
    weight = math.log1p(s4/b4)
    score4 = k*weight
    p0 = poisson.pmf(k, b4*luminosity)
    p1 = poisson.pmf(k, (b4+s4)*luminosity)
    def difference(c):
        return p0 @ ndtr((score4-c)/sd)-ALPHA
    threshold = brentq(difference, -10.*sd, 10.*sd+score4[-1])
    return float(p1 @ ndtr((score4+q-threshold)/sd))


def combined_reach(qgamma, s4, b4):
    information = fourlepton_information(s4,b4)
    return {"gaussian_score_exact_fourlepton_fb_inverse": reach(lambda L: joint_power(qgamma,L,s4,b4)-.5),
            "all_channels_asimov_fb_inverse": reach(lambda L: qgamma(L)+information*L-25.)}


def _binomial_ge(k, n, p):
    # The regularized incomplete beta gives the inclusive upper binomial tail.
    # Limit the domain supplied to betainc to improve throughput for arrays.
    count = np.clip(k, 1, n)
    tail = betainc(count, n-count+1, p)
    return np.where(k<=0, 1., np.where(k>n, 0., tail))


def fixed_transfer_power(model, luminosity, s4=None, b4=None, tail=1.e-12):
    """Conditional binomial peak count, with optional exact 4l Poisson LR.

    For known transfer, condition under H0 on the observed peak+side total T.
    Under H1, average the power over its Poisson law. For each T the critical
    conditional null probability is at most alpha. A small probability budget
    covers the omitted high 4l null counts in the two-channel calculation.
    """
    if model.log_transfer_error:
        raise ValueError("Exact conditional binomial test requires known transfer")
    mean = luminosity * model.total_alternative
    t = np.arange(int(poisson.ppf(tail/2.,mean)), 1+int(poisson.isf(tail/2.,mean)))
    weights = poisson.pmf(t,mean)
    if s4 is None:
        cutoff = binom.isf(ALPHA,t,model.p0).astype(int)+1
        return float(weights @ _binomial_ge(cutoff,t,model.p1))
    mu0 = b4 * luminosity
    mu1 = (s4+b4)*luminosity
    k0 = np.arange(2+int(poisson.isf(1.e-14,mu0)))
    k1 = np.arange(2+int(poisson.isf(tail,mu1)))
    p0 = poisson.pmf(k0,mu0)
    p1 = poisson.pmf(k1,mu1)
    alpha = ALPHA - poisson.sf(k0[-1],mu0)
    ratio = math.log1p(s4/b4)/model.log_transfer_shift
    offsets0 = np.ceil(-k0*ratio).astype(int)
    offsets1 = np.ceil(-k1*ratio).astype(int)
    shifts = np.ceil((k1[:,None]-k0)*ratio).astype(int)
    power = 0.
    for pos in range(0,len(t),80):
        tt = t[pos:pos+80]
        dim = tt[:,None]
        lo = np.full(len(tt),-1)
        hi = tt + int(math.ceil(k0[-1]*ratio)) + 1
        while np.any(hi-lo > 1):
            mid = (lo+hi)//2
            null_tail = _binomial_ge(mid[:,None]+offsets0,dim,model.p0) @ p0
            passed = null_tail <= alpha
            hi = np.where(passed,mid,hi)
            lo = np.where(passed,lo,mid)
        cutoff = hi[:,None] + offsets1
        tail_at_previous = _binomial_ge(cutoff[:,:,None]-1+shifts,dim[:,:,None],model.p0) @ p0
        cutoff -= tail_at_previous <= alpha
        power += weights[pos:pos+80] @ (_binomial_ge(cutoff,dim,model.p1) @ p1)
    return float(power)
