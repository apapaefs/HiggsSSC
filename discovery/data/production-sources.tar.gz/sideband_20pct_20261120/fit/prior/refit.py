"""Pool independent SSC diphoton spectra and update the 125 GeV discovery projection.

python refit.py --output result.json packet1.json packet2.json ...
The established 1M/1M samples are part of baseline.json. Supply only new
full-phase-space or corresponding Born-stratified estimates. Supplying no
extra inputs exercises the published reference analysis.
"""
import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import re
import sys
import tempfile

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "reference"))
from continuum_fit import ALL, BLIND, EDGES, Shape
from sideband_reach import combined_reach
from closure_calibration import Calibration, evaluate

BASELINE = HERE / "baseline.json"


def canonical(packet):
    """Read the producer contract, including historical field spellings."""
    sample = packet["sample"]
    kind = packet.get("stratum", "full")
    if sample=="bkg_dijet_double_fake" and kind in ("inclusive_minbias","inclusive_minimum_bias","minimum_bias","inclusive minimum bias"):
        kind = "full"
    edges = packet.get("edges_gev",packet.get("mass_bin_edges_GeV"))
    if not np.array_equal(edges, EDGES):
        raise ValueError(f"Incompatible reconstructed mass edges for {sample}")
    rate = np.array(packet.get("rate_fb",packet.get("rates_fb")),dtype=float)
    cov = np.array(packet["covariance_fb2"],dtype=float)
    if rate.shape!=(55,) or cov.shape!=(55,55) or not np.isfinite(rate).all() or not np.isfinite(cov).all():
        raise ValueError(f"Nonfinite or malformed spectrum for {sample}")
    if not np.allclose(cov,cov.T,rtol=1.e-10,atol=1.e-12) or np.linalg.eigvalsh((cov+cov.T)/2.)[0] < -1.e-9*max(1.,np.max(cov)):
        raise ValueError(f"Invalid source covariance for {sample}")
    n = int(packet["generated_events"])
    if n<=0 or n!=packet["generated_events"]:
        raise ValueError(f"Invalid independent event exposure for {sample}")
    if "first_source" in packet or "last_source_exclusive" in packet:
        raise ValueError("Individual shower pieces must first be combined into their complete hard parent")
    provenance = packet.get("provenance", {})
    ids = {str(packet["independent_id"])}
    digests = [packet.get("source_lhe_sha256")]
    if provenance.get("parent_lhe"):
        digests.append(provenance["sha256"])
    for digest in digests:
        if digest is not None:
            if not isinstance(digest, str) or not re.fullmatch(r"[a-fA-F0-9]{64}", digest):
                raise ValueError("Invalid hard-parent LHE SHA-256")
            ids.add(digest.lower())
    seeds = set()
    def add_seeds(record):
        # Multiple fields on one record can be aliases of the same hard seed.
        primary = {int(record[k]) for k in ("seed","generator_seed","hard_seed") if k in record}
        auxiliary = [int(s) for k in ("auxiliary_generator_seeds","continuation_generator_seeds")
                     for s in record.get(k,[])]
        all_seeds = list(primary) + auxiliary
        if len(set(all_seeds)) != len(all_seeds) or seeds.intersection(all_seeds):
            raise ValueError("Repeated hard seed within one sample receipt")
        seeds.update(all_seeds)
    add_seeds({**packet, **({"hard_seed":provenance["hard_seed"]} if "hard_seed" in provenance else {})})
    for shard in packet.get("shards",[]):
        add_seeds(shard)
    return (sample,kind),n,rate,cov,ids,seeds


def pool(base, paths):
    groups=defaultdict(list)
    independent, seeds, provenance = set(), set(), []
    supported = {(p["sample"],p["stratum"]) for p in base["datasets"]}
    def append(packet, path=None):
        key,n,h,c,ids,seedvals = canonical(packet)
        if key not in supported or (path and key[0] not in ("bkg_gamma_j","bkg_prompt_aa","bkg_dijet_double_fake","bkg_loop_gg_aa")):
            raise ValueError(f"Unexpected sample or phase-space stratum {key}.")
        # A hard file has one physical identity even if its response label changes.
        ids={(None,i.lower()) if re.fullmatch(r"[a-fA-F0-9]{64}",i) else (key[0],i) for i in ids}
        tagged_seeds={(key[0],i) for i in seedvals}
        if independent & ids or seeds & tagged_seeds:
            raise ValueError(f"Repeated hard source or generator seed in {key}: {path}")
        independent.update(ids)
        seeds.update(tagged_seeds)
        groups[key].append((n,h,c))
        if path:
            provenance.append({"path":str(path), "sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
                               "sample":key[0],"stratum":key[1],"generated_events":n,
                               "independent_id":packet["independent_id"]})
    for packet in base["datasets"]:
        append(packet)
    for path in paths:
        append(json.loads(path.read_text()),path)
    hist,cov,exposure = {},{},{}
    stratum_cov, separate = {}, {}
    for (sample,stratum),members in groups.items():
        total = sum(n for n,h,c in members)
        addition = sum(h*(n/total) for n,h,c in members)
        errors = sum(c*(n/total)**2 for n,h,c in members)
        hist[sample] = hist.get(sample,0.)+addition
        cov[sample] = cov.get(sample,0.)+errors
        stratum_cov[(sample,stratum)] = errors
        if len(members)>1:
            n1 = total-members[0][0]
            h1 = sum(h*(n/n1) for n,h,c in members[1:])
            c1 = sum(c*(n/n1)**2 for n,h,c in members[1:])
            separate[(sample,stratum)] = members[0][1],h1,members[0][2],c1
        if sample.startswith("bkg") and sample!="bkg_dy_ee":
            exposure.setdefault(sample,{})[stratum] = {"generated_including_reference":total,
                                                         "added_generated":total-members[0][0],
                                                         "pooling_exposures":[m[0] for m in members]}
    return hist,cov,stratum_cov,separate,exposure,provenance


def curve(q, four):
    def formatted(lumi):
        return {"luminosity_fb_inverse":float(lumi),"months_at_10_fb_inverse_per_year":1.2*float(lumi)}
    return {name:{k:formatted(v) for k,v in combined_reach(q,row["signal_fb"],row["background_fb"]).items()}
            for name,row in four.items()}


def study(hist,cov,stratum_cov,separate,four):
    b = sum(h for k,h in hist.items() if k.startswith("bkg"))
    s = sum(h for k,h in hist.items() if k.startswith("signal"))
    if np.any(b<=0) or np.any(b+s<=0):
        raise ValueError("The combined reference spectrum must be positive in every fitted bin.")
    models = {}
    for family,degree in (("exponential",2),("power",2),("exponential",3)):
        shape=Shape(family,degree)
        _,continuum,_,_=shape.fit(b,~BLIND)
        truth=continuum+s
        _,null,_,_=shape.fit(truth,ALL)
        q=2*np.sum(null-truth+truth*np.log(truth/null))
        params,_,_,d=shape.fit(b,ALL,s)
        g=d[-1]
        variance={k:float(g@v@g) for k,v in cov.items() if k.startswith("bkg")}
        sigma=float(np.sqrt(sum(variance.values())))
        # Fits to background-only pseudo-data at a few displaced masses diagnose localized structure.
        away = {}
        for mass in (113,137,147):
            shift=mass-125
            moved=np.zeros_like(s)
            if shift<0:
                moved[:shift]=s[-shift:]
            else:
                moved[shift:]=s[:-shift]
            a,_,_,dd=shape.fit(b,ALL,moved)
            err=np.sqrt(sum(dd[-1]@v@dd[-1] for k,v in cov.items() if k.startswith("bkg")))
            away[str(mass)]={"fitted_signal_strength":float(a[-1]),"mc_error":float(err)}
        models[f"{family}{degree}"]={"sideband_fitted_continuum_fb":continuum.tolist(),
            "shape_q0_per_fb":float(q), "spurious_signal_mu":float(params[-1]),
            "spurious_signal_mc_error":sigma,"variance_by_sample":variance,
            "variance_by_sample_and_stratum":{"/".join(k):float(g@v@g) for k,v in stratum_cov.items() if k[0].startswith("bkg")},
            "off_peak_template_checks":away}
    model=models["exponential2"]
    q,err=model["shape_q0_per_fb"],model["spurious_signal_mc_error"]
    limit=1./err
    L=25./q
    con=25./(q*(1.-25.*err**2)) if err<.2 else None
    closure,shape,theta,continuum,signal=evaluate(hist,cov,separate)
    calibrated={}
    measured=closure["nominal_spurious_mu"]
    for name,center in (("measured_background_bias",measured),
                        ("lower_background_bias",measured-err),("upper_background_bias",measured+err)):
        profile=Calibration(shape,theta,continuum,signal,center,err)
        lum=profile.diphoton_reach()
        calibrated[name]={"background_bias_center_in_Higgs_yields":center,"gaussian_calibration_width_mu":err,
                          "diphoton_luminosity_fb_inverse":lum,"diphoton_months":lum*1.2 if lum is not None else None,
                          "limiting_gamma_significance":1./err,"combined":curve(profile.q,four)}
    return {"models":models,
        "smooth_continuum":{"diphoton_luminosity_fb_inverse":L,"diphoton_months":1.2*L,
                            "combined":curve(lambda l:q*l,four)},
        "illustrative_additive_signal_like_uncertainty":{"sigma_mu":err,"limiting_diphoton_significance":limit,
                 "diphoton_luminosity_fb_inverse":con,"diphoton_months":None if con is None else 1.2*con,
                 "combined":curve(lambda l:1./(1./(q*l)+err**2),four)},
        "precision_target":{"sigma_mu_target":.2,"achieved":bool(err<=.2),
                            "uniform_factor_for_further_exposure":max(1.,(err/.2)**2)},
        "fixed_125_GeV_background_only_closure":closure,
        "empirically_calibrated_bias":{
           "method":"Use fitted sideband continuum plus a fixed signal-shaped background offset in both hypotheses. Under signal plus background add one SM Higgs. Profile all continuum parameters and the offset against a Gaussian calibration with the source-event MC standard error. The primary illustrative center equals the measured background-only spurious signal; two alternatives move that background center by one MC sigma in both hypotheses. This tests compensation of a real signal-shaped bias to the precision of the calibration. Its interpretation assumes the simulated bias represents the physical one.",
           "scenarios":calibrated},
        "background_per_bin_fb":b.tolist(),"signal_per_bin_fb":s.tolist()}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output",type=Path, required=True)
    p.add_argument("packets",nargs="*",type=Path)
    args=p.parse_args()
    base=json.loads(BASELINE.read_text())
    h,c,cs,separate,totals,provenance=pool(base,args.packets)
    result=study(h,c,cs,separate,base["fourlepton"])
    if not args.packets:
        ref=base["published_median_reach"]["diphoton"]["luminosity_fb_inverse"]
        assert np.isclose(result["smooth_continuum"]["diphoton_luminosity_fb_inverse"],ref,rtol=1.e-7)
        assert np.isclose(result["models"]["exponential2"]["spurious_signal_mc_error"],base["published_spurious_mu_error"],rtol=1.e-7)
    result.update({"method":"Same 55-bin 105–160 GeV inclusive fit and unchanged four-lepton classifier as the reference. Rates are averaged over independent generator seeds with coefficients proportional to all generated event counts within a common domain; covariance coefficients are squared. Disjoint loop Born domains are added. The smooth fit uses a high-count diphoton Asimov likelihood with free continuum normalization, slope and curvature, combined with an exact Poisson four-lepton count. The additive-uncertainty scenario uses zero mean and the fitted MC standard error for the width of a signal-like background constraint; this does not establish the true continuum bias.",
             "generated_exposures":totals,"independent_new_inputs":provenance,
             "fourlepton_rates_fb":base["fourlepton"],"edges_gev":EDGES.tolist(),
             "reference_sha256":hashlib.sha256(BASELINE.read_bytes()).hexdigest()})
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w",dir=args.output.parent,delete=False) as tmp:
        json.dump(result,tmp,indent=2,allow_nan=False)
        tmp.write("\n")
    Path(tmp.name).replace(args.output)
    nominal=result["models"]["exponential2"]
    print(f"{len(args.packets)} independent input receipts, mu(spurious)={nominal['spurious_signal_mu']:.5f} +/- {nominal['spurious_signal_mc_error']:.5f}, diphoton L5={result['smooth_continuum']['diphoton_luminosity_fb_inverse']:.5f} fb^-1")


if __name__=="__main__":
    main()
