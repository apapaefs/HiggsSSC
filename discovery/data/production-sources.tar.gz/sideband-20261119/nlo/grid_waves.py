"""Generate independent native MC@NLO event samples from verified archived MINT grids."""
import argparse
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
from types import SimpleNamespace

import archive_shower as shower
from hgammagamma import run_gammagamma_ho_campaign as generator

ROOT = shower.ROOT
FIT = Path('/home/apapaefs/HiggsSSC/inputs/pipeline/sideband_campaign_20261119')
READY = FIT / 'nlo_ready'
PYTHON = Path(sys.executable)
SAMPLES = {'prompt': ('bkg_prompt_aa', 12000000, 195330000),
           'gammaj': ('bkg_gamma_j', 7000000, 195630000)}
TRANSFER = ['rsync', '-a', '--exclude=/Events/***', '--exclude=/HTML/***',
            '--exclude=events.lhe*', '--exclude=*.rwgt', '--exclude=*.tar.gz',
            '--exclude=*.log']


import balance


def cpus(mode):
    return balance.available(mode)


def set_parameter(card, variable, value):
    text, changed = re.subn(rf'(?m)^\s*[^\n=!#]+?\s*=\s*{variable}\s*!',
                            f' {value} = {variable} !', card.read_text())
    if changed != 1:
        raise ValueError(f'Could not uniquely identify {variable} in {card}')
    card.write_text(text)


def first_event(path):
    with gzip.open(path, 'rb') as f:
        event = bytearray()
        active = False
        for line in f:
            if line.strip() == b'<event>':
                active = True
            if active:
                event.extend(line)
                if line.strip() == b'</event>':
                    return hashlib.sha256(event).hexdigest()
    raise ValueError(f'no first event in {path}')


def inspect(path, mode, seed, n, parent, previous):
    with gzip.open(path, 'rt') as f:
        header = ''
        for line in f:
            if line.strip() == '<init>':
                break
            header += line
    required = {'iseed': seed, 'nevents': n}
    for key, value in required.items():
        if not re.search(rf'(?m)^\s*{value}\s*=\s*{key}[^\S\n]*(?:[!#]|$)', header):
            raise ValueError(f'{path} has mismatched {key}')
    spec = next(s for s in generator.SAMPLES if s.name == SAMPLES[mode][0])
    lhe = generator.inspect_lhe(path, spec, SimpleNamespace(ebeam=20000, nevents=n))
    if lhe['events'] != n:
        raise ValueError('Unexpected exposure')
    old = parent['lhe']
    old_sigma = old['cross_section_pb']
    if abs(lhe['cross_section_pb']-old_sigma)>0.10*old_sigma:
        raise ValueError('Native LHE cross section differs by >10% from canonical sample')
    fingerprint = first_event(path)
    if fingerprint == first_event(Path(old['source'])) or fingerprint in previous:
        raise ValueError('Duplicate hard-event stream')
    return lhe, fingerprint


def proc_children(pid):
    return Path(f'/proc/{pid}/task/{pid}/children').read_text().split()


def retire_old_controller(mode):
    # The gamma+jet controller owns one distinct 1M generation, which must run
    # through finite showers. Pause its controller only after it starts those
    # showers. The children keep running until the finished receipt is published.
    marker = ROOT / f'{mode}_controller_transition.json'
    if marker.is_file():
        return
    match = []
    for path in Path('/proc').glob('[0-9]*/cmdline'):
        try:
            parts = path.read_bytes().split(b'\0')
            if parts[1:3] == [b'waves.py', mode.encode()]:
                match.append(int(path.parent.name))
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            continue
    if len(match) != 1:
        raise RuntimeError(f'Unclear prior supervisor ownership: {match}')
    pid = match[0]
    if mode == 'gammaj':
        while not (READY / 'sb19_gammaj01.json').is_file():
            children = proc_children(pid)
            if any(b'archive_shower.py' in Path(f'/proc/{p}/cmdline').read_bytes()
                   for p in children):
                break
            time.sleep(5)
    os.kill(pid, signal.SIGSTOP)
    if mode == 'prompt' and proc_children(pid):
        os.kill(pid, signal.SIGCONT)
        raise RuntimeError('Prompt supervisor started another stage; inspect before takeover')
    if mode == 'gammaj':
        while not (READY / 'sb19_gammaj01.json').is_file():
            time.sleep(10)
    shower.put(marker, {'old_controller': pid, 'time': time.time(), 'mode': mode})
    os.kill(pid, signal.SIGTERM)
    os.kill(pid, signal.SIGCONT)


def hard(mode, tag, seed, n, archive, previous):
    wd = ROOT/tag
    wd.mkdir(exist_ok=True)
    with (wd/'hard.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        return generate_hard(mode,tag,seed,n,archive,previous)


def generate_hard(mode, tag, seed, n, archive, previous):
    wd = ROOT / tag
    wd.mkdir(exist_ok=True)
    process = wd / 'mg5_process'
    proc_log = wd / 'generator.log'
    native = process / 'Events' / tag / 'events.lhe.gz'
    manifest = wd / 'campaign.json'
    if manifest.is_file():
        meta = json.loads(manifest.read_text())
        if not native.is_file() or meta['seed'] != seed or meta['lhe']['source'] != str(native):
            raise ValueError('Cannot adopt mismatched generation')
        if not (0 < meta['lhe']['events'] <= 250000) or meta['lhe']['source_size'] != native.stat().st_size:
            raise ValueError('Cannot adopt an invalid complete independent parent')
        return manifest, meta['first_event_sha256']
    if not native.is_file():
        if shutil.disk_usage(ROOT).free < 25 * 2**30:
            raise RuntimeError('Less than 25 GiB free for the next private hard sample')
        subprocess.run(TRANSFER+[str(archive / 'mg5_process')+'/', str(process)+'/'], check=True)
        (process / 'Events').mkdir(exist_ok=True)
        (process / 'HTML').mkdir(exist_ok=True)
        card = process / 'Cards/run_card.dat'
        for key, value in [('iseed', seed), ('nevents', n), ('nevt_job', 1000)]:
            set_parameter(card, key, value)
        mask, lanes = cpus(mode)
        config = process / 'Cards/amcatnlo_configuration.txt'
        text = re.sub(r'(?m)^\s*(?:nb_core|run_mode)\s*=.*\n', '', config.read_text())
        config.write_text(text + f'\nnb_core = {lanes}\nrun_mode = 2\n')
        cmd = ['taskset','-c', mask, str(PYTHON),'bin/generate_events','aMC@NLO',
               '--only_generation','--parton','-f','-n',tag]
        with proc_log.open('a') as f:
            print('Starting',time.time(),lanes,cmd,file=f,flush=True)
            subprocess.run(cmd,cwd=process,stdout=f,stderr=subprocess.STDOUT,check=True)
    parent = json.loads((archive / 'campaign.json').read_text())
    lhe, fingerprint = inspect(native, mode, seed, n, parent, previous)
    manifest_data = {key:parent[key] for key in ['sample','process','pdf']}
    manifest_data.update(seed=seed, run_tag=tag, lhe=lhe, first_event_sha256=fingerprint,
                         source_grid=str(archive/'mg5_process'),
                         source_grid_seed=parent['seed'], generator_log=str(proc_log))
    shower.put(manifest, manifest_data)
    return manifest, fingerprint


def main():
    p=argparse.ArgumentParser()
    p.add_argument('mode', choices=SAMPLES)
    p.add_argument('--retire-controller', action='store_true')
    args=p.parse_args()
    mode=args.mode
    if args.retire_controller:
        retire_old_controller(mode)
        return
    lock = (ROOT / f'{mode}_grid_waves.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
    sample, budget, seed_base = SAMPLES[mode]
    archive = shower.OLD / sample
    previous=set()
    exposure=0
    i=0
    while exposure < budget:
        if (FIT / 'fit/target_fit.json').is_file():
            print('Fit precision target reached.',flush=True)
            return
        next_tag=f'sb19_{mode}_grid{i+1:03}'
        existing=READY/f'{next_tag}.json'
        if existing.is_file():
            n=json.loads(existing.read_text())['generated_events']
        else:
            global_done=balance.completed()
            desired=balance.targets(global_done)[mode]
            planned=ROOT/next_tag/'campaign.json'
            if planned.exists():
                n=json.loads(planned.read_text())['lhe']['events']
            elif global_done[mode]>=budget:
                print('All queues together reached the hard cap',mode,global_done[mode],flush=True)
                return
            elif global_done[mode]>=desired:
                time.sleep(60)
                continue
            else:
                n=min(budget-global_done[mode],desired-global_done[mode],50000 if i==0 else 250000)
        i+=1
        seed=seed_base+i*1000
        tag=next_tag
        if existing.is_file():
            previous.add(json.loads((ROOT/tag/'campaign.json').read_text())['first_event_sha256'])
        else:
            manifest, fingerprint=hard(mode, tag, seed, n, archive, previous)
            n=json.loads(manifest.read_text())['lhe']['events']
            previous.add(fingerprint)
            mask,lanes=cpus(mode)
            with (ROOT/tag/'shower.log').open('a') as f:
                cmd=['taskset','-c',mask,str(PYTHON),str(ROOT/'archive_shower.py'),
                     '--sample',sample,'--tag',tag+'_response','--output-id',tag,
                     '--campaign',str(manifest),'--seed',str(seed+20000000),
                     '--shard','5000','--workers',str(lanes)]
                subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
            if not (READY / f'{tag}.json').is_file():
                raise RuntimeError(f'{tag} failed to publish an independent packet')
        exposure+=n
        print(time.time(),mode,exposure,'of',budget,flush=True)
    print('Bounded run complete.',flush=True)


if __name__=='__main__':
    main()
