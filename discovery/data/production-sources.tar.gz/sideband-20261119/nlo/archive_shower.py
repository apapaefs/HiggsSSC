"""Split one independent MC@NLO native run into disjoint finite-LHE showers."""
import argparse
import concurrent.futures
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

import numpy as np
import uproot

ROOT = Path('/home/apapaefs/HiggsSSC/inputs/pipeline/sideband-20261119/nlo')
OLD = Path('/home/apapaefs/Projects/HiggsSSC/hgammagamma/HOAnalysis/runs/ho_bg_5m_01/Backgrounds/events')
EXE = Path('/home/apapaefs/Projects/HiggsSSC/hgammagamma/LOAnalysis/Code/HwSimPostAnalysis_gammagamma_SSC')
LIB = Path('/home/apapaefs/HiggsSSC/inputs/pipeline/loop-gammagamma-20261118/source_v4')
sys.path.insert(0, str(LIB))
from hgammagamma import ho_shower_completion as completion

def put(path, value):
    tmp = path.with_suffix('.json.tmp')
    tmp.write_text(json.dumps(value, allow_nan=False, indent=2)+'\n')
    tmp.replace(path)

def run(args, wd, name, permit_eof=False):
    with (wd/name).open('w') as out:
        p = subprocess.run(args,cwd=wd,stdout=out,stderr=subprocess.STDOUT)
    if p.returncode and not (permit_eof and 'More events requested than available in LesHouchesReader' in (wd/name).read_text(errors='replace')):
        raise RuntimeError(f'{wd}/{name}: exit {p.returncode}')

def file_sha(path):
    value=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(2**20),b''):
            value.update(block)
    return value.hexdigest()


class FiniteSource:
    def __init__(self,folder):
        self.path=folder/'shard.lhe'
        self.partial=folder/'shard.lhe.part'
        self.fp=None if self.path.is_file() else self.partial.open('wb')
        self.digest=hashlib.sha256()
    def write(self,block):
        if self.fp is None:
            self.digest.update(block)
        else:
            self.fp.write(block)
    def finish(self):
        if self.fp is not None:
            self.fp.close()
            self.partial.replace(self.path)
        elif self.digest.hexdigest()!=file_sha(self.path):
            raise RuntimeError(f'Existing finite source differs from its hard parent: {self.path}')


def chunks(source, directory, per):
    """Stream event records; publish each atomic finite file before its consumer runs."""
    with gzip.open(source,'rb') as f:
        header = bytearray()
        for line in f:
            if b'<eventgroup' in line: raise ValueError('grouped LHE input')
            if re.search(rb'<event(?:>|\s)',line):
                opener=line
                break
            header.extend(line)
        else: raise ValueError('empty source')
        i = count = signs = 0
        active = False
        tmp = None
        for line in __import__('itertools').chain([opener],f):
            if b'<eventgroup' in line: raise ValueError('grouped events')
            if b'</LesHouchesEvents>' in line: break
            if re.search(rb'<event(?:>|\s)',line):
                if active: raise ValueError('nested event')
                if count==0:
                    folder=directory/f'shard_{i:05d}'
                    folder.mkdir(parents=True, exist_ok=True)
                    out=FiniteSource(folder);out.write(header)
                active=True
                need_weight=True
                out.write(line)
            elif active:
                if need_weight and line.strip():
                    w=float(line.split()[2]); signs+=int(w>0)-int(w<0); need_weight=False
                out.write(line)
                if b'</event>' in line:
                    active=False; count+=1
                    if count==per:
                        out.write(b'</LesHouchesEvents>\n');out.finish()
                        yield folder,i,count,signs
                        i+=1;count=signs=0
        if active: raise ValueError('truncated source')
        if count:
            out.write(b'</LesHouchesEvents>\n');out.finish()
            yield folder,i,count,signs

def finite_shower(wd,sample,n,original_seed):
    record=wd/'retry_state.json'
    history=json.loads(record.read_text()) if record.exists() else []
    while True:
        attempt=len(history)
        seed=original_seed if not attempt else original_seed+250000000*attempt
        log=wd/'run.log'
        msg=log.read_text(errors='replace') if log.exists() else ''
        if 'More events requested than available in LesHouchesReader' in msg:
            return seed,history
        if 'RhoDMatrix::normalize()' in msg and 'Assertion' in msg and 'failed' in msg:
            if attempt>=2:
                raise RuntimeError(f'Repeated Herwig spin-density assertion on {wd}')
            failure=wd/f'failed_spin_density_attempt_{attempt:02d}'
            failure.mkdir(exist_ok=True)
            # Preserve failed cards, logs and partial detector records. Keep
            # the verified finite hard input in place for the next attempt.
            for name in ['events',f'{sample}.in',f'{sample}.run',f'{sample}.out',f'{sample}.log',f'{sample}-EvtGen.log','read.log','run.log','shower_execution.json']:
                item=wd/name
                if item.exists():item.rename(failure/name)
            info={'failed_seed':seed,'replacement_seed':original_seed+250000000*(attempt+1),
                  'failed_log':str(failure/'run.log'),'failed_log_sha256':file_sha(failure/'run.log'),
                  'finite_lhe_sha256':file_sha(wd/'shard.lhe'),'reason':'Herwig RhoDMatrix::normalize assertion'}
            history.append(info)
            put(record,history)
            continue
        template=(OLD/sample/'herwig'/f'{sample}.in').read_text()
        vals={'LesHouchesReader:FileName':wd/'shard.lhe',
              'EventGenerator:RandomNumberGenerator:Seed':seed,
              'EventGenerator:NumberOfEvents':n+2}
        for name,value in vals.items():
            template,changed=re.subn(r'(?m)^(set '+re.escape(name)+r') .*',lambda m:m[1]+' '+str(value),template)
            if changed!=1:raise RuntimeError(f'Missing parameter {name} in canonical shower card')
        (wd/'events').mkdir(exist_ok=True)
        (wd/f'{sample}.in').write_text(template)
        put(wd/'shower_execution.json',completion.finite_shower_plan(sample,n,n))
        run(['Herwig','read',f'{sample}.in'],wd,'read.log')
        try:
            run(['Herwig','run',f'{sample}.run',f'-N{n+2}'],wd,'run.log',True)
        except RuntimeError:
            msg=log.read_text(errors='replace')
            if 'RhoDMatrix::normalize()' not in msg or 'Assertion' not in msg or 'failed' not in msg:raise
            continue
        if 'More events requested than available in LesHouchesReader' not in log.read_text(errors='replace'):
            raise RuntimeError(f'Herwig stopped without finite-source EOF: {wd}')
        return seed,history


def work(piece, cfg, base, denominator, ngen):
    wd,i,n,signed=piece
    if (wd/'receipt.json').exists():
        return n
    sample=cfg.sample
    actual_seed,history=finite_shower(wd,sample,n,cfg.seed+i)
    root=wd/'events'/f'{sample}.root'
    with uproot.open(root) as f:
        tree=next(o for o in f.values() if hasattr(o,'keys') and 'evweight' in o.keys())
        weights=tree['evweight'].array(library='np').reshape(-1)
    info=[dict(path=str(root),entries=len(weights),sum_weight=float(weights.sum()),sum_abs_weight=float(np.abs(weights).sum()),sum_weight_squared=float(weights@weights),size=root.stat().st_size,mtime_ns=root.stat().st_mtime_ns)]
    sw=completion.source_weight_summary(wd/'shard.lhe',n)
    rec=completion.build_completion(wd,sample,n,n,info,'source_exhausted',source_weights=sw)
    if rec['attempted_events']!=n:raise ValueError((wd,'incomplete source',rec['attempted_events'],n))
    if abs(sw['sum_weight']-signed)>1e-6:raise ValueError(('different signed-source units',sw,signed))
    prefix=wd/'ssc.input';prefix.write_text(str(root)+'\n')
    run([str(EXE),str(prefix),'-t','side','-w','1','--response-mode','genuine' if sample=='bkg_prompt_aa' else 'gammajet','--seed',str(actual_seed)],wd,'analysis.log')
    vr=next(wd.glob('*_var.root'))
    with uproot.open(vr) as f:
        t=f['Data2'];v=t['variables'].array(library='np');ids=t['sourceevent'].array(library='np').reshape(-1);w=t['eventweight'].array(library='np').reshape(-1)
    mask=(v[:,9]>=2)&(v[:,0]>=105)&(v[:,0]<160)
    # Normalize all shards using the parent run's signed source denominator. The
    # aggregate weights each shard by its share n/ngen of generated hard events.
    rate_weight=w[mask]*1000*base['lhe']['cross_section_pb']*ngen/(denominator*n)
    from scipy.sparse import coo_matrix
    rows=int(ids.max())+1 if ids.size else 0
    arr=coo_matrix((rate_weight,(ids[mask],np.floor(v[mask,0]-105).astype(int))),shape=(rows,55)).tocsr()
    receipt=dict(sample=sample,independent_id=f'{cfg.tag}_{i:05d}',generated_events=n,rate_fb=np.asarray(arr.sum(0)).ravel().tolist(),covariance_fb2=(arr.T@arr).toarray().tolist(),edges_gev=list(range(105,161)),parent_source=str(cfg.lhe),first_source=i*cfg.shard,last_source_exclusive=i*cfg.shard+n,seed=actual_seed,shower_completion=rec,signed_source_sum=signed,global_denominator=denominator,parent_events=ngen)
    if history:receipt['shower_retries']=history
    put(wd/'receipt.json',receipt)
    return n


def publish(wd,base,cfg,src,n):
    receipts=[json.loads(p.read_text()) for p in sorted(wd.glob('shard_*/receipt.json'))]
    cursor=0
    rates=np.zeros(55);cov=np.zeros((55,55));signed=0
    for rec in receipts:
        if rec['parent_source']!=str(src) or rec['first_source']!=cursor or rec['edges_gev']!=list(range(105,161)):
            raise ValueError('Unverified parent source coverage')
        size=rec['generated_events']
        cursor+=size
        if rec['last_source_exclusive']!=cursor: raise ValueError('Invalid source interval')
        rates+=np.array(rec['rate_fb'])*(size/n)
        cov+=np.array(rec['covariance_fb2'])*(size/n)**2
        signed+=rec['signed_source_sum']
    if cursor!=n or signed!=n-2*base['lhe']['negative_events']:
        raise ValueError('Parent source normalization mismatch')
    out=Path('/home/apapaefs/HiggsSSC/inputs/pipeline/sideband_campaign_20261119/nlo_ready')
    out.mkdir(exist_ok=True,parents=True)
    checksum=hashlib.sha256()
    with src.open('rb') as f:
        for block in iter(lambda:f.read(2**20),b''):checksum.update(block)
    packet=dict(sample=cfg.sample,independent_id=cfg.tag,generated_events=n,edges_gev=list(range(105,161)),rate_fb=rates.tolist(),covariance_fb2=cov.tolist(),provenance=dict(parent_lhe=str(src),sha256=checksum.hexdigest(),hard_seed=base['seed'],shower_seed_start=cfg.seed,shard_directory=str(wd),source_signed_denominator=signed,complete_shards=len(receipts),matrix_element=base['process'],pdf=base['pdf'],native_cross_section_pb=base['lhe']['cross_section_pb']))
    packet['provenance']['retry_seed_exceptions']=[dict(first_source=r['first_source'],last_source_exclusive=r['last_source_exclusive'],actual_seed=r['seed'],shower_retries=r['shower_retries']) for r in receipts if r.get('shower_retries')]
    packet['provenance']['native_cross_section_error_pb']=base['lhe'].get('cross_section_error_pb')
    if 'source_grid' in base:
        packet['provenance']['source_grid']=base['source_grid']
        packet['provenance']['source_grid_seed']=base['source_grid_seed']
    put(out/((getattr(cfg,'output_id',None) or cfg.tag)+'.json'),packet)

def main():
    p=argparse.ArgumentParser()
    for k in ('sample','tag','campaign'):p.add_argument('--'+k,required=True)
    p.add_argument('--output-id')
    p.add_argument('--workers',type=int,required=True)
    p.add_argument('--shard',type=int,default=5000)
    p.add_argument('--seed',type=int,required=True)
    cfg=p.parse_args()
    base=json.loads(Path(cfg.campaign).read_text())
    cfg.lhe=base['lhe']['source']; src=Path(cfg.lhe)
    n=base['lhe']['events']; denom=n-2*base['lhe']['negative_events']
    assert n>0 and denom>0 and abs(base['lhe']['sum_abs_weight']/base['lhe']['events']-base['lhe']['sum_weight']/denom)<5e-6*base['lhe']['sum_abs_weight']/n
    wd=ROOT/cfg.tag;wd.mkdir(parents=True,exist_ok=True)
    owner=(wd/'shower_owner.lock').open('a')
    fcntl.flock(owner,fcntl.LOCK_EX)
    ready=Path('/home/apapaefs/HiggsSSC/inputs/pipeline/sideband_campaign_20261119/nlo_ready')/((cfg.output_id or cfg.tag)+'.json')
    if ready.exists():
        certified=json.loads(ready.read_text())
        if certified['generated_events']!=n or certified['provenance']['hard_seed']!=base['seed'] or certified['provenance']['parent_lhe']!=str(src):
            raise RuntimeError('Existing complete parent does not match the requested hard source')
        return
    if os.sched_getscheduler(0)!=os.SCHED_IDLE:
        allocations={}
        markers=(['prompt_pipeline_reservation.json','prompt_collect_reservation.json']
                 if cfg.sample=='bkg_prompt_aa' else ['gamma_pipeline_reservation.json'])
        for name in markers:
            try:
                shared=json.loads((ROOT/name).read_text())
            except FileNotFoundError:
                continue
            if cfg.tag==shared['preceding_parent']+'_response' and Path('/proc',str(shared['pid'])).exists():
                parent=shared['hard_parent']
                allocations[parent]=max(allocations.get(parent,0),shared['lanes'])
        if allocations:
            cfg.workers=max(1,cfg.workers-sum(allocations.values()))
            print('Separate hard generation and shower workers',allocations,cfg.workers,flush=True)
    layout=wd/'layout.json'
    if layout.exists():
        prior=json.loads(layout.read_text())
        assert prior['source']==str(src) and prior['shower_seed']==cfg.seed and prior['hard_events']==n
        cfg.shard=prior['shard']
    else:
        # Record immutable ranges before their first shower. Older directories
        # already have source ranges fixed by their original command.
        if cfg.workers>40 and not any(wd.glob('shard_*')):
            cfg.shard=min(cfg.shard,max(1000,n//(2*cfg.workers)))
        put(layout,dict(source=str(src),shower_seed=cfg.seed,hard_events=n,shard=cfg.shard))
    if re.fullmatch(r'sb19_(prompt|gammaj)_grid[0-9]+_response',cfg.tag):
        if (n+cfg.shard-1)//cfg.shard>1000:
            raise ValueError('Detector and shower seeds would reach the next independent batch')
    futures=set();total=0;issued=0
    with concurrent.futures.ThreadPoolExecutor(max_workers=cfg.workers) as pool:
        for piece in chunks(src,wd,cfg.shard):
            issued+=piece[2]
            futures.add(pool.submit(work,piece,cfg,base,denom,n))
            if len(futures)>=cfg.workers*2:
                done,futures=concurrent.futures.wait(futures,return_when=concurrent.futures.FIRST_COMPLETED)
                for fut in done: total+=fut.result()
                print('finished',total,'issued',issued,'of',n,flush=True)
        for fut in concurrent.futures.as_completed(futures):total+=fut.result()
    assert total==issued==n
    put(wd/'complete.json',dict(events=n,sample=cfg.sample,tag=cfg.tag,source=str(src)))
    publish(wd,base,cfg,src,n)
if __name__=='__main__':main()
