"""Evaluate SSC dijet double-fake envelopes for the mass window and frozen classifier."""
import argparse
import json
import math
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hgammagamma import ho_shower_completion as completion
from hgammagamma.dijet_response import load_model, response_rows


def evaluate(bin_dirs, analyzer, model=None):
    records=[]
    totals={}
    previous=None
    seen=set()
    roots=set()
    reader_sha256=completion._artifact(analyzer)["sha256"]
    for directory in bin_dirs:
        s=json.loads((directory/"source.json").read_text())
        low,high=s["bin_GeV"]
        if low<=0 or (high != -1 and high<=low) or (previous is not None and previous!=low):
            raise ValueError("supply consecutive, non-overlapping Born bins in increasing order")
        if s["lhe_sha256"] in seen:
            raise ValueError("repeated dijet source")
        previous=high
        seen.add(s["lhe_sha256"])
        proof=json.loads((directory/"shower.json").read_text())
        n=s["events"]
        completion.validate_completion(proof,dict(sample="dijet",nevents_requested=n,lhe=dict(events=n)),directory=directory)
        if (proof["source_weights"]["artifact"]["sha256"]!=s["lhe_sha256"] or
            proof["source_weights"]["sum_weight"]!=n or proof["attempted_events"]!=n):
            raise ValueError("inconsistent hard source")
        generated_rate_pb=s["cross_section_pb"]
        groups={}
        for root in proof["artifacts"]["roots"]:
            if root["sha256"] in roots: raise ValueError("reused HwSim ROOT")
            roots.add(root["sha256"])
            for row in response_rows(analyzer,root["path"],s["seed"]+2,model):
                key=row["scenario"]+"@"+row["fake_scale"]
                vals=groups.setdefault(key,[0.,0.,0,0])
                for i,(field,convert) in enumerate([("sum_probability",float),("sum_probability_squared",float),
                                                    ("events_read",int),("contributing_events",int)]):
                    vals[i]+=convert(row[field])
        result={}
        for key,(sw,sw2,read,count) in groups.items():
            if read!=proof["saved_events"] or n<2:
                raise ValueError("analyzer source count differs from finite shower")
            rate=generated_rate_pb*1000*sw/n
            var=(generated_rate_pb*1000)**2*max(0,sw2-sw*sw/n)/(n*(n-1))
            # Include the independent MG integration error separately.
            integration_error=1000*sw/n*s["integration_error_pb"]
            result[key]=dict(rate_fb=rate,mc_error_fb=math.sqrt(var),integration_error_fb=integration_error,
                             contributing_sources=count)
            total=totals.setdefault(key,[0.,0.,0.])
            total[0]+=rate
            total[1]+=var
            total[2]+=integration_error**2
        records.append(dict(bin_GeV=s["bin_GeV"],generated=n,saved=proof["saved_events"],seed=s["seed"],
                            source_sha256=s["lhe_sha256"],cross_section_pb=generated_rate_pb,estimates=result))
    return dict(window_GeV=[120,130], bins=records, frozen_model=model[1] if model else None, analyzer_sha256=reader_sha256,
                interpretation="Pair-probability union bounds in the generated Born domain. MC errors describe sampled events; empty bins can still contribute. No contribution assigned outside the generated range.",
                totals={k:dict(rate_fb=v,mc_error_fb=math.sqrt(q),integration_error_fb=math.sqrt(g))
                        for k,(v,q,g) in totals.items()})


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bins",type=Path,nargs="+",required=True)
    parser.add_argument("--analyzer",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--frozen-dir",type=Path)
    args=parser.parse_args()
    report=evaluate(args.bins,args.analyzer.resolve(),load_model(args.frozen_dir))
    args.output.write_text(json.dumps(report,indent=2)+"\n")
