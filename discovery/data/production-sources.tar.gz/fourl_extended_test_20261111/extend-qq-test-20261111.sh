#!/usr/bin/env bash
set -eo pipefail
cd /home/apapaefs/HiggsSSC
source /etc/profile.d/modules.sh
module load herwig/stable
set -u
export PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export MPLCONFIGDIR=/home/apapaefs/HiggsSSC/inputs/pipeline/matplotlib
py=/home/apapaefs/HiggsSSC/inputs/pipeline/venv/bin/python
base=hfourlepton/runs/fourl40_minimal_qq200k
date -Is
"$py" hfourlepton/extend_xgboost_test.py prepare \
  --base-analysis "$base/revisions/ssc_qq1m/xgboost" \
  --additional-manifest "$base/manifest_ssc.json" \
  --output-dir "$base/revisions/ssc_qq1m_extended_test"
"$py" hfourlepton/extend_xgboost_test.py evaluate \
  --output-dir "$base/revisions/ssc_qq1m_extended_test"
date -Is
