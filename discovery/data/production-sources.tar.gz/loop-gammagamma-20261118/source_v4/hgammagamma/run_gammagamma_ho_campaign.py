#!/usr/bin/env python3
"""Prepare/run POWHEG HJMiNNLO + Herwig and MG5 MC@NLO diphoton backgrounds.

The default stage only writes cards. Signal LHE production is handled by
run_powheg_hjminnlo.py; pass its merged output with --signal-lhe.
"""

from __future__ import annotations

import argparse
import copy
import fcntl
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from string import Template
from types import SimpleNamespace
from uuid import uuid4

try:
    from . import run_gammagamma_campaign as lo
    from . import ho_signal_normalization as signal_normalization
    from . import ho_shower_completion as shower_completion
except ImportError:
    import run_gammagamma_campaign as lo
    import ho_signal_normalization as signal_normalization
    import ho_shower_completion as shower_completion

SCRIPT_DIR = Path(__file__).resolve().parent
HO_DIR = SCRIPT_DIR / "HOAnalysis"
ANALYSIS_DIR = SCRIPT_DIR / "LOAnalysis" / "Code"
ANALYSIS_EXE = ANALYSIS_DIR / "HwSimPostAnalysis_gammagamma_SSC"

# Read only the saved event count and nominal-weight branch. This never
# invokes the detector-response analysis or modifies a ROOT file.
ROOT_METADATA_SCRIPT = r'''
import json, math, sys
from pathlib import Path
import ROOT
ROOT.gROOT.SetBatch(True)
metadata = []
for filename in sys.argv[1:]:
    path = Path(filename)
    before = path.stat()
    handle = ROOT.TFile.Open(str(path), "READ")
    if not handle or handle.IsZombie() or handle.TestBit(ROOT.TFile.kRecovered):
        raise ValueError("missing, corrupt or recovered ROOT file: " + str(path))
    tree = handle.Get("Data")
    if not tree or not tree.InheritsFrom("TTree"):
        raise ValueError("missing HwSim Data tree: " + str(path))
    branch = tree.GetBranch("evweight")
    leaf = tree.GetLeaf("evweight")
    if not branch or not leaf:
        raise ValueError("missing HwSim nominal weight branch: " + str(path))
    entries = int(tree.GetEntries())
    weights = []
    for index in range(entries):
        if branch.GetEntry(index) <= 0:
            raise ValueError("unreadable nominal weight entry in " + str(path))
        value = float(leaf.GetValue())
        if not math.isfinite(value):
            raise ValueError("non-finite nominal weight in " + str(path))
        weights.append(value)
    handle.Close()
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError("ROOT file changed during inspection: " + str(path))
    metadata.append({"path": str(path), "entries": entries,
                     "sum_weight": math.fsum(weights),
                     "sum_abs_weight": math.fsum(abs(w) for w in weights),
                     "sum_weight_squared": math.fsum(w*w for w in weights),
                     "size": after.st_size, "mtime_ns": after.st_mtime_ns})
print(json.dumps(metadata, allow_nan=False))
'''


@dataclass(frozen=True)
class Sample:
    name: str
    category: str
    process: str
    response_mode: str
    matching: str

    @property
    def signal(self) -> bool:
        return self.category == "Signal"

    @property
    def pdf_name(self) -> str:
        return lo.NNLO_PDF_NAME if self.signal else lo.NLO_PDF_NAME

    @property
    def lhaid(self) -> int:
        return lo.NNLO_PDF_LHAID if self.signal else lo.NLO_PDF_LHAID


SAMPLES = (
    Sample("signal_gg_h_aa", "Signal", "HJMiNNLO; h -> gamma gamma", "genuine", "POWHEG"),
    Sample("bkg_prompt_aa", "Backgrounds", "p p > a a [QCD]", "genuine", "MC@NLO"),
    Sample("bkg_gamma_j", "Backgrounds", "p p > a j [QCD]", "gammajet", "MC@NLO"),
    Sample("bkg_dy_ee", "Backgrounds", "p p > e+ e- [QCD]", "dielectron", "MC@NLO"),
)


def signal_campaign_identity(args):
    """Rate provenance independent of generation/shower configuration."""
    sample = SAMPLES[0]
    return {
        "schema_version": 1, "run_tag": args.run_tag, "sample": sample.name,
        "process": sample.process, "matching": sample.matching,
        "hard_accuracy": "NNLO+PS (HJMiNNLO)", "hard_model": "pure_heft",
        "higgs_mass_gev": 125.0, "pdf": sample.pdf_name,
        "lhaid": sample.lhaid, "ebeam_gev": args.ebeam,
    }


def preflight_signal_normalization(args, manifest):
    try:
        record = signal_normalization.load_signal_record(args.signal_normalization, manifest)
    except (OSError, ValueError) as error:
        if not args.dry_run:
            raise ValueError(f"HO signal requires a validated --signal-normalization record: {error}") from error
        print(f"+ pending HO signal normalization: {error}; dry-run commands only")
        return None
    args.expected_native_parameters = record.get("native_parameters", {})
    args.expected_higgs_mass = record["higgs_mass_gev"]
    return record


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("prepare", "build", "generate", "shower", "analyze", "normalize", "all"), default="prepare")
    parser.add_argument("--run-tag", default="ho_run_01")
    parser.add_argument("--output-dir", type=Path, help="default: HOAnalysis/runs/RUN_TAG")
    parser.add_argument("--run-samples", default="all", help="all, backgrounds, or comma-separated names")
    parser.add_argument("--signal-lhe", type=Path, help="complete merged HJMiNNLO LHE (.gz accepted), with undecayed Higgs")
    parser.add_argument("--signal-normalization", type=Path, default=signal_normalization.DEFAULT_RECORD,
                        help="validated ihixs N3LO record required for HO signal analysis; normalize updates an existing run's rate only")
    parser.add_argument("--nevents", type=int, default=10000, help="events per background and maximum signal shower events")
    parser.add_argument("--ebeam", type=float, default=20000.)
    parser.add_argument("--seed-base", type=int, default=730001)
    parser.add_argument("--nb-core", type=int, default=1)
    parser.add_argument("--higgs-br", type=float, default=lo.YR4_BR_H_TO_GAMMAGAMMA)
    parser.add_argument("--mg5-dir", type=Path, default=lo.REPO_ROOT / "MG5_aMC_v3_5_15")
    parser.add_argument("--mg5-python", default=os.environ.get("MG5_PYTHON", "python3"))
    parser.add_argument("--mg5-fortran", help="override MG5 Fortran compiler (e.g. gfortran)")
    parser.add_argument("--mg5-cxx", help="override MG5 C++ compiler, compatible with LHAPDF")
    parser.add_argument("--mg5-dependencies", choices=("internal", "external"), default="internal",
                        help="internal keeps rebuildable dependency copies inside each exported process")
    parser.add_argument("--analysis-cxx", default="/usr/bin/clang++" if sys.platform == "darwin" else "c++",
                        help="C++ compiler compatible with the installed ROOT")
    parser.add_argument("--herwig", default=os.environ.get("HERWIG", "Herwig"))
    parser.add_argument("--herwig-max-errors", type=int,
                        help="override the per-class event-error limit; default: retain an existing sample's limit, "
                             "or max(100, ceil(nevents/5000)) for a new sample")
    parser.add_argument("--herwig-env", type=Path, default=lo.maybe_path(os.environ.get("HERWIG_ENV")))
    parser.add_argument("--herwig-module", default=os.environ.get("HERWIG_MODULE"))
    parser.add_argument("--no-herwig-module", action="store_true")
    parser.add_argument("--gen-photon-pt-min", type=float, default=10.)
    parser.add_argument("--gen-jet-pt-min", type=float, default=10.)
    parser.add_argument("--gen-lepton-pt-min", type=float, default=10.)
    parser.add_argument("--gen-eta-max", type=float, default=6.)
    parser.add_argument("--gen-mll-min", type=float, default=30.)
    parser.add_argument("--isolation-radius", type=float, default=0.4)
    parser.add_argument("--isolation-epsilon", type=float, default=1.)
    parser.add_argument("--isolation-power", type=float, default=1.)
    parser.add_argument("--resume", action="store_true", help="reuse completed stages with identical configuration")
    parser.add_argument("--restart-failed-shower", action="store_true",
                        help="with --stage prepare --resume, archive an error-limit-stopped shower and raise only its error budget")
    parser.add_argument("--dry-run", action="store_true", help="print cards and commands without writing or running")
    cli_arguments = list(argv) if argv is not None else sys.argv[1:]
    args = parser.parse_args(cli_arguments)
    if args.restart_failed_shower and (args.stage != "prepare" or not args.resume):
        parser.error("--restart-failed-shower requires --stage prepare --resume")
    if args.restart_failed_shower and args.herwig_max_errors is None:
        parser.error("--restart-failed-shower requires an explicit --herwig-max-errors increase")
    if args.herwig_max_errors is not None and args.herwig_max_errors <= 0:
        parser.error("herwig-max-errors must be positive")
    args.run_tag_explicit = any(value == "--run-tag" or value.startswith("--run-tag=")
                                for value in cli_arguments)
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]*", args.run_tag):
        parser.error("run-tag must contain only letters, digits, underscores and hyphens")
    for key in ("nevents", "nb_core", "seed_base", "ebeam", "gen_photon_pt_min", "gen_jet_pt_min",
                "gen_lepton_pt_min", "gen_eta_max", "gen_mll_min", "isolation_radius",
                "isolation_epsilon", "isolation_power"):
        if not math.isfinite(getattr(args, key)) or getattr(args, key) <= 0:
            parser.error(f"{key.replace('_', '-')} must be finite and positive")
    if not 0 < args.higgs_br <= 1:
        parser.error("higgs-br must be in (0, 1]")
    args.output_dir = (args.output_dir or HO_DIR / "runs" / args.run_tag).expanduser().resolve()
    args.mg5_dir = args.mg5_dir.expanduser().resolve()
    args.signal_normalization = args.signal_normalization.expanduser().resolve()
    if args.signal_lhe:
        args.signal_lhe = args.signal_lhe.expanduser().resolve()
    if args.herwig_env:
        args.herwig_env = args.herwig_env.expanduser().resolve()
        if args.herwig_env.is_dir():
            args.herwig_env /= "bin/activate"
    if args.no_herwig_module:
        args.herwig_module = None
    elif not args.herwig_env and not args.herwig_module:
        args.herwig_module = (lo.DEFAULT_DARWIN_HERWIG_MODULE if sys.platform == "darwin"
                              else lo.DEFAULT_LINUX_HERWIG_MODULE)
    if args.herwig_module:
        args.herwig_env = None
    # MG5/ThePEG card parsers do not share shell quoting rules.
    for path in (args.output_dir, args.mg5_dir, args.signal_lhe):
        if path and (re.search(r"\s|[;#\"']", str(path))):
            parser.error(f"generator paths must not contain whitespace or card metacharacters: {path}")
    return args


def selected_samples(args):
    if args.run_samples == "all":
        return list(SAMPLES)
    if args.run_samples == "backgrounds":
        return [s for s in SAMPLES if not s.signal]
    names = set(args.run_samples.split(","))
    unknown = names - {s.name for s in SAMPLES}
    if unknown:
        raise ValueError(f"unknown samples: {', '.join(sorted(unknown))}")
    return [s for s in SAMPLES if s.name in names]


def sample_dir(args, sample):
    return args.output_dir / sample.category / "events" / sample.name


def lhe_path(args, sample):
    if sample.signal:
        return args.signal_lhe or args.output_dir / "powheg" / "powheg-hjminnlo-merged.lhe"
    return sample_dir(args, sample) / "mg5_process" / "Events" / args.run_tag / "events.lhe.gz"


def run_settings(args, sample):
    """NLO run-card keys, deliberately distinct from MadEvent LO cuts."""
    return {
        "nevents": args.nevents, "iseed": args.seed_base + SAMPLES.index(sample),
        "ebeam1": args.ebeam, "ebeam2": args.ebeam, "lpp1": 1, "lpp2": 1,
        "pdlabel": "lhapdf", "lhaid": lo.NLO_PDF_LHAID,
        "parton_shower": "HERWIGPP", "event_norm": "average", "ickkw": 0,
        "fixed_ren_scale": False, "fixed_fac_scale": False,
        "dynamical_scale_choice": 3, "mur_over_ref": 1., "muf_over_ref": 1.,
        "reweight_scale": True, "reweight_PDF": False,
        "jetalgo": -1, "jetradius": 0.4, "maxjetflavor": 5,
        # No generation cut on the extra real-emission jet in colour-singlet samples.
        "ptj": args.gen_jet_pt_min if sample.response_mode == "gammajet" else 0.,
        "etaj": args.gen_eta_max,
        "ptl": args.gen_lepton_pt_min if sample.response_mode == "dielectron" else 0.,
        "etal": args.gen_eta_max, "mll": args.gen_mll_min, "mll_sf": args.gen_mll_min,
        "drll": 0., "drll_sf": 0.,
        "gamma_is_j": False, "ptgmin": args.gen_photon_pt_min,
        "etagamma": args.gen_eta_max, "R0gamma": args.isolation_radius,
        "epsgamma": args.isolation_epsilon, "xn": args.isolation_power, "isoEM": True,
    }


def mg5_cards(args, sample):
    process_dir = sample_dir(args, sample) / "mg5_process"
    setup = "set automatic_html_opening False\n"
    for option, value in (("fortran_compiler", args.mg5_fortran), ("cpp_compiler", args.mg5_cxx)):
        if value:
            setup += f"set {option} {value} --no_save\n"
    # A massless five-flavour model and p/j definitions consistent with the NLO PDF.
    process = (setup + f"set output_dependencies {args.mg5_dependencies}\n" +
               "import model loop_sm-no_b_mass\n"
               "define p = g u c d s b u~ c~ d~ s~ b~\n"
               "define j = g u c d s b u~ c~ d~ s~ b~\n"
               f"generate {sample.process}\noutput {process_dir}\n")
    launch = (setup +
              f"set nb_core {args.nb_core}\n"
              f"launch {process_dir} aMC@NLO --parton --name={args.run_tag}\n")
    launch += "".join(f"set {key} {value}\n" for key, value in run_settings(args, sample).items())
    launch += "done\n"
    return process, launch


def default_herwig_error_budget(nevents):
    """Allow for cumulative rare event errors without an unlimited budget."""
    return max(100, (nevents + 4999) // 5000)


def stored_herwig_error_budget(manifest):
    card = manifest.get("configuration", {}).get("herwig_card", "")
    limits = re.findall(r"(?m)^set EventGenerator:MaxErrors ([0-9]+)$", card)
    if len(limits) != 1 or int(limits[0]) <= 0:
        raise ValueError("campaign card must record exactly one positive MaxErrors setting")
    return int(limits[0])


def herwig_error_budget(args, sample):
    if args.herwig_max_errors is not None:
        return args.herwig_max_errors
    manifest_path = sample_dir(args, sample) / "campaign.json"
    if manifest_path.is_file():
        # A software update must not silently change an existing campaign's
        # card or fingerprint. Resolve per sample without changing shared args.
        return stored_herwig_error_budget(json.loads(manifest_path.read_text()))
    return default_herwig_error_budget(args.nevents)


def validate_error_limit_stop(parsed, manifest):
    """Require consistent partial counts at the recorded per-class limit."""
    limit = stored_herwig_error_budget(manifest)
    counts = parsed["exception_counts"]
    error_classes = [entry["count"] for entry in parsed["exception_classes"]
                     if entry["severity"] == "eventerror"]
    if (any(counts.get(key, 0) for key in ("runerror", "setuperror", "maybeabort", "abortnow", "unknown"))
            or not error_classes or max(error_classes) != limit
            or counts["eventerror"] != sum(error_classes)):
        raise ValueError("failed shower did not stop at its recorded MaxErrors limit")
    generated, attempted = parsed["generated_events"], parsed["attempted_events"]
    if (generated != parsed["saved_events"] or generated <= 0
            or generated >= manifest["nevents_requested"] or attempted >= manifest["lhe"]["events"]
            or attempted - generated != counts["eventerror"]):
        raise ValueError("failed shower lacks consistent partial source-event bookkeeping")
    return limit


def error_limit_recovery_hint(args, sample, manifest):
    """Diagnose a known failure without changing or adopting partial outputs."""
    herwig_dir = sample_dir(args, sample) / "herwig"
    try:
        parsed = shower_completion._parse_logs(herwig_dir, sample.name, "error_limit")
        limit = validate_error_limit_stop(parsed, manifest)
    except (OSError, ValueError, KeyError, TypeError, IndexError):
        return None
    suggested = max(default_herwig_error_budget(args.nevents), limit * 2)
    return (
        f"Herwig stopped {sample.name} at its per-class event-error limit ({limit}): "
        f"{parsed['saved_events']} saved events from {parsed['attempted_events']} source attempts. "
        f"See {herwig_dir / 'run.log'}. The generated LHE and partial shower outputs are preserved.\n"
        "To prepare recovery, repeat the original campaign command, retaining all generation "
        "settings, paths and seeds, but replace its stage/sample options with "
        f"--stage prepare --run-samples {sample.name} --resume --restart-failed-shower "
        f"--herwig-max-errors {suggested}. This validates and archives the failed shower.\n"
        f"Then repeat it with --stage all --run-samples {sample.name} --resume and "
        f"--herwig-max-errors {suggested}, without --restart-failed-shower. "
        "Herwig re-showers the existing LHE from the beginning; completed generation is reused. "
        "Other samples can resume with their original options and saved budgets."
    )


def herwig_card(args, sample):
    decay = ""
    if sample.signal:
        decay = ("# Unit-probability forced decay; physical BR is applied only by post-analysis.\n"
                 "set /Herwig/Particles/h0:NominalMass 125.0*GeV\n"
                 "do /Herwig/Particles/h0:SelectDecayModes h0->gamma,gamma;\n"
                 "set /Herwig/Particles/h0/h0->gamma,gamma;:BranchingRatio 1.0\n")
    matching = ((HO_DIR / "MCatNLO.in").read_text() if not sample.signal
                else "# POWHEG SCALUP veto; retain the default POWHEG recoil settings.")
    return Template((HO_DIR / "HW-LHE.in").read_text()).substitute(
        lhe_file=lhe_path(args, sample), pdf_name=sample.pdf_name,
        matching_settings=matching, decay_settings=decay, nevents=args.nevents,
        seed=args.seed_base + SAMPLES.index(sample), sample_name=sample.name,
        max_errors=herwig_error_budget(args, sample),
    )


def write_text(path, value, args):
    if args.dry_run:
        print(f"+ write {path}\n{value}", end="" if value.endswith("\n") else "\n")
    else:
        if path.is_file() and path.read_text() == value:
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name + ".tmp")
        temporary.write_text(value)
        temporary.replace(path)


def write_json(path, value, args):
    write_text(path, json.dumps(value, indent=2, sort_keys=True) + "\n", args)


def command(args, argv, cwd, log_name):
    print(f"+ [{cwd}] {shlex.join(str(x) for x in argv)}", flush=True)
    if args.dry_run:
        return
    setup = lo.runtime_setup_commands(args)
    # Activation scripts may export FC/CXX and thereby override MG5's
    # make_opts compiler selection. Honour explicit overrides after activation.
    for key, value in (("FC", args.mg5_fortran), ("F77", args.mg5_fortran), ("CXX", args.mg5_cxx)):
        if value:
            setup.append(f"export {key}={shlex.quote(value)}")
    shell = "\n".join([*setup, shlex.join(str(x) for x in argv)])
    log = cwd / log_name
    with log.open("w") as stream:
        result = subprocess.run(["bash", "-c", shell], cwd=cwd, env=lo.clean_shell_env(),
                                stdout=stream, stderr=subprocess.STDOUT)
    if result.returncode or re.search(r"interrupted with error:|Error detected in", log.read_text(errors="replace")):
        raise RuntimeError(f"generator/build error (exit status {result.returncode}); see {log}")


def recover_failed_shower(args, sample, old, new_configuration, new_fingerprint):
    """Archive an error-limit abort and prepare a fresh shower of the same LHE.

    This operation never invokes Herwig or MG5. The caller holds the campaign
    lock; only the per-class Herwig error limit may change between attempts.
    """
    def fingerprint(configuration):
        return hashlib.sha256(json.dumps(configuration, sort_keys=True).encode()).hexdigest()

    previous_configuration = old.get("configuration")
    if not isinstance(previous_configuration, dict) or old.get("fingerprint") != fingerprint(previous_configuration):
        raise ValueError("failed-shower recovery requires an intact configuration fingerprint")
    if new_fingerprint != fingerprint(new_configuration):
        raise ValueError("invalid replacement configuration fingerprint")
    if old["fingerprint"] == new_fingerprint and previous_configuration == new_configuration:
        return old
    if (not getattr(args, "restart_failed_shower", False) or not args.resume
            or args.stage != "prepare"):
        raise ValueError("failed-shower recovery requires --restart-failed-shower --resume --stage prepare")

    directory = sample_dir(args, sample)
    herwig_dir = directory / "herwig"
    manifest_path = directory / "campaign.json"
    if (directory.is_symlink() or herwig_dir.is_symlink() or manifest_path.is_symlink()
            or not herwig_dir.is_dir()):
        raise ValueError("failed-shower recovery requires an original local sample directory")
    if (old.get("sample") != sample.name or old.get("run_tag") != args.run_tag
            or old.get("ebeam_gev") != args.ebeam or old.get("nevents_requested") != args.nevents
            or old.get("seed") != args.seed_base + SAMPLES.index(sample)):
        raise ValueError("failed-shower recovery cannot change the campaign identity")
    completed = old.get("completed", [])
    if (not isinstance(completed, list) or "generate" not in completed
            or any(stage in completed for stage in ("shower", "analyze"))
            or any(key in old for key in ("shower_completion", "analysis", "rate_normalization", "root_files"))
            or (directory / f"normalization-{args.run_tag}.json").exists()):
        raise ValueError("failed-shower recovery requires completed generation and an incomplete, unanalyzed shower")
    old_card = previous_configuration.get("herwig_card", "")
    new_card = new_configuration.get("herwig_card", "")
    limit_pattern = r"(?m)^set EventGenerator:MaxErrors ([0-9]+)$"
    old_limits, new_limits = re.findall(limit_pattern, old_card), re.findall(limit_pattern, new_card)
    if len(old_limits) != 1 or len(new_limits) != 1:
        raise ValueError("failed-shower recovery requires exactly one MaxErrors setting")
    old_limit, new_limit = int(old_limits[0]), int(new_limits[0])
    normalized = dict(new_configuration)
    normalized["herwig_card"] = re.sub(limit_pattern, f"set EventGenerator:MaxErrors {old_limit}", new_card)
    if old_limit <= 0 or new_limit <= old_limit or normalized != previous_configuration:
        raise ValueError("failed-shower recovery permits only an increase in MaxErrors")
    card_path = herwig_dir / f"{sample.name}.in"
    if not card_path.is_file() or card_path.read_text() != old_card:
        raise ValueError("persisted Herwig card differs from the failed campaign configuration")
    original_manifest = manifest_path.read_bytes()
    if json.loads(original_manifest) != old:
        raise ValueError("failed campaign manifest changed before recovery")
    source = lhe_path(args, sample)
    if (Path(old.get("lhe_file", "")).resolve() != source.resolve()
            or not old.get("lhe") or inspect_lhe(source, sample, args) != old["lhe"]):
        raise ValueError("LHE changed since completed generation; refusing shower recovery")

    parsed = shower_completion._parse_logs(herwig_dir, sample.name, "error_limit")
    validate_error_limit_stop(parsed, old)
    inventory = root_inventory(directory)
    root_paths = {str(Path(entry["path"]).resolve()) for entry in inventory}
    if root_paths != set(parsed["root_writers"]) or len(root_paths) != len(inventory):
        raise ValueError("failed shower ROOT inventory differs from finalized writers")
    root_artifacts = []
    for entry in inventory:
        path = Path(entry["path"]).resolve()
        if not path.is_relative_to(herwig_dir.resolve() / "events"):
            raise ValueError("failed shower ROOT artifact lies outside its events directory")
        artifact = shower_completion._artifact(path)
        if any(artifact[key] != entry[key] for key in ("size", "mtime_ns")):
            raise ValueError("failed shower ROOT artifact changed during recovery inspection")
        root_artifacts.append(artifact)
    if root_inventory(directory) != inventory or manifest_path.read_bytes() != original_manifest:
        raise ValueError("failed shower changed during recovery inspection")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    archive = directory / "shower-recovery" / f"{stamp}-{uuid4().hex[:12]}"
    updated = copy.deepcopy(old)
    updated.update(configuration=copy.deepcopy(new_configuration), fingerprint=new_fingerprint)
    updated.setdefault("shower_restarts", []).append({
        "reason": "herwig_error_limit", "archive": str(archive), "prepared_at_utc": stamp,
        "previous_fingerprint": old["fingerprint"], "previous_max_errors": old_limit,
        "max_errors": new_limit, "generated_events": parsed["generated_events"],
        "attempted_events": parsed["attempted_events"], "saved_events": parsed["saved_events"],
        "exception_counts": copy.deepcopy(parsed["exception_counts"]),
        "exception_classes": copy.deepcopy(parsed["exception_classes"]),
        "artifacts": {**copy.deepcopy(parsed["artifacts"]), "roots": root_artifacts,
                      "herwig_card": shower_completion._artifact(card_path),
                      "campaign_manifest": shower_completion._artifact(manifest_path)},
    })
    print(f"+ archive failed shower in {archive}; prepare MaxErrors {old_limit} -> {new_limit}")
    if args.dry_run:
        return updated

    archive.mkdir(parents=True, exist_ok=False)
    moved_herwig = moved_manifest = False
    try:
        herwig_dir.rename(archive / "herwig")
        moved_herwig = True
        manifest_path.rename(archive / "campaign.json")
        moved_manifest = True
        write_text(card_path, new_card, args)
        write_json(manifest_path, updated, args)
    except BaseException:
        # Retain any attempted replacement as evidence, then restore original
        # paths and bytes. Never delete pre-existing campaign or shower files.
        if moved_herwig and herwig_dir.exists():
            herwig_dir.rename(archive / "replacement-herwig")
        if moved_manifest and manifest_path.exists():
            manifest_path.rename(archive / "replacement-campaign.json")
        temporary = manifest_path.with_name(manifest_path.name + ".tmp")
        if moved_manifest and temporary.exists():
            temporary.rename(archive / "replacement-campaign.json.tmp")
        if moved_manifest:
            (archive / "campaign.json").rename(manifest_path)
        if moved_herwig:
            (archive / "herwig").rename(herwig_dir)
        raise
    return updated


def prepare(args, sample):
    directory = sample_dir(args, sample)
    process, launch = ("", "") if sample.signal else mg5_cards(args, sample)
    herwig = herwig_card(args, sample)
    identity = {"process_card": process, "launch_card": launch, "herwig_card": herwig,
                "higgs_br": args.higgs_br if sample.signal else 1.0,
                "response_mode": sample.response_mode,
                "herwig": args.herwig, "herwig_env": str(args.herwig_env),
                "herwig_module": args.herwig_module, "mg5_dir": str(args.mg5_dir),
                "mg5_python": args.mg5_python}
    fingerprint = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()
    manifest_path = directory / "campaign.json"
    manifest = {
        "schema_version": 1, "run_tag": args.run_tag, "sample": sample.name,
        "process": sample.process, "matching": sample.matching,
        "hard_accuracy": "NNLO+PS (HJMiNNLO)" if sample.signal else "NLO QCD + PS",
        "response_mode": sample.response_mode, "detector_response": "ssc",
        "pdf": sample.pdf_name, "lhaid": sample.lhaid, "ebeam_gev": args.ebeam,
        "nevents_requested": args.nevents, "seed": args.seed_base + SAMPLES.index(sample),
        "weight_scale": args.higgs_br if sample.signal else 1.0,
        "normalization_rule": "inclusive LHE cross section times physical BR once" if sample.signal
                              else "signed MC@NLO cross section; no K factor",
        "lhe_file": str(lhe_path(args, sample)), "fingerprint": fingerprint,
        "configuration": identity, "completed": [],
    }
    if sample.signal:
        manifest.update(hard_model="pure_heft", higgs_mass_gev=125.0)
    if manifest_path.exists():
        old = json.loads(manifest_path.read_text())
        if args.restart_failed_shower:
            old = recover_failed_shower(args, sample, old, identity, fingerprint)
        if old["fingerprint"] != fingerprint or old["ebeam_gev"] != args.ebeam:
            raise ValueError(f"configuration changed in {directory}; use a new --run-tag/output-dir")
        manifest = old
    elif args.restart_failed_shower:
        raise ValueError("failed-shower recovery requires an existing campaign manifest")
    elif directory.exists() and any(directory.iterdir()):
        raise ValueError(f"unmanaged non-empty sample directory: {directory}")
    persisted_card = directory / "herwig" / f"{sample.name}.in"
    if (not (args.dry_run and args.restart_failed_shower)
            and any((directory / "herwig/events").glob("**/*.root"))) and (
            not persisted_card.is_file() or persisted_card.read_text() != herwig):
        raise ValueError(f"persisted Herwig card differs from existing ROOT products in {directory}; preserve them for inspection")
    if not sample.signal:
        write_text(directory / "cards/process.mg5", process, args)
        write_text(directory / "cards/launch.mg5", launch, args)
    write_text(persisted_card, herwig, args)
    write_json(manifest_path, manifest, args)
    return manifest


def number(value):
    result = float(value.replace("D", "E").replace("d", "e"))
    if not math.isfinite(result):
        raise ValueError(f"non-finite LHE value: {value}")
    return result


def inspect_lhe(path, sample, args, *, powheg_validator=None):
    """Stream full LHE: signed cross section, weights, beams/PDFs, and decay state."""
    opener = gzip.open if path.suffix == ".gz" else open
    header = []
    init = []
    in_init = in_event = closed = False
    particle_lines = 0
    higgs = stable_higgs = count = negatives = 0
    non_nominal_higgs_mass = False
    expected_higgs_mass = getattr(args, "expected_higgs_mass", 125.0)
    sumw = sumabs = sumw2 = 0.
    with opener(path, "rt") as stream:
        for line in stream:
            stripped = line.strip()
            if count == 0 and not in_init and not in_event:
                header.append(line)
            if stripped == "<init>":
                in_init = True
            elif stripped == "</init>":
                in_init = False
            elif in_init and stripped and not stripped.startswith(("#", "<")):
                init.append(stripped.split())
            elif re.match(r"<event(?:\s[^>]*)?>$", stripped):
                if in_event:
                    raise ValueError(f"nested/incomplete LHE event in {path}")
                in_event = True
                particle_lines = -1
                higgs = stable_higgs = 0
            elif stripped == "</event>":
                if not in_event or particle_lines != 0:
                    raise ValueError(f"incomplete LHE particle record in {path}")
                if sample.signal and (higgs != 1 or stable_higgs != 1):
                    raise ValueError("signal LHE must contain exactly one undecayed, status-1 Higgs per event")
                in_event = False
                count += 1
            elif in_event and stripped and not stripped.startswith(("#", "<")):
                fields = stripped.split()
                if particle_lines == -1:
                    particle_lines = int(fields[0])
                    weight = number(fields[2])
                    if not math.isfinite(weight):
                        raise ValueError(f"non-finite signed LHE weight in {path}")
                    sumw += weight
                    sumabs += abs(weight)
                    sumw2 += weight * weight
                    negatives += weight < 0
                elif particle_lines > 0:
                    if len(fields) < 13:
                        raise ValueError(f"short LHE particle record in {path}")
                    higgs += int(fields[0]) == 25
                    stable_higgs += int(fields[0]) == 25 and int(fields[1]) == 1
                    if sample.signal and int(fields[0]) == 25:
                        mass = number(fields[10])
                        if not math.isfinite(mass) or mass <= 0:
                            raise ValueError(f"invalid Higgs mass in LHE particle record: {path}")
                        non_nominal_higgs_mass |= not math.isclose(
                            mass, expected_higgs_mass, rel_tol=0., abs_tol=1.e-6)
                    particle_lines -= 1
            elif stripped == "</LesHouchesEvents>":
                closed = True
    if not closed or in_event or not count or len(init) < 2:
        raise ValueError(f"empty or incomplete LHE file: {path}")
    beam = init[0]
    if [int(x) for x in beam[:2]] != [2212, 2212]:
        raise ValueError("expected two proton beams")
    if any(not math.isclose(number(x), args.ebeam) for x in beam[2:4]):
        raise ValueError("LHE beam energy differs from --ebeam")
    if len(init) != 1 + int(beam[9]):
        raise ValueError("LHE init subprocess count is inconsistent")
    header_text = "".join(header)
    pdf_ids = [int(x) for x in beam[6:8]]
    if sample.signal and pdf_ids == [-1, -1]:
        # HJMiNNLO uses IDWTUP=-4 and leaves PDF and cross-section init fields
        # unspecified. Its complete POWHEG input is embedded in the header.
        matches = [re.search(rf"(?m)^\s*lhans{i}\s+(\d+)", header_text) for i in (1, 2)]
        if not all(matches):
            raise ValueError("unspecified LHE PDF IDs without embedded POWHEG lhans1/lhans2")
        pdf_ids = [int(match[1]) for match in matches]
    if pdf_ids != [sample.lhaid, sample.lhaid]:
        raise ValueError(f"LHE PDF IDs differ from required {sample.lhaid}")
    if (not sample.signal and getattr(sample, "matching", "MC@NLO") == "MC@NLO"
            and not re.search(r"HERWIGPP\s*['\"]?\s*=\s*parton_shower", header_text, re.I)):
        raise ValueError("MC@NLO LHE lacks parton_shower=HERWIGPP provenance")
    if sample.signal and powheg_validator is None and not re.search(r"\bminnlo\s+1\b", header_text, re.I):
        raise ValueError("signal LHE lacks HJMiNNLO provenance (minnlo 1)")
    if sample.signal:
        (powheg_validator or validate_signal_hard_inputs)(header_text, args, non_nominal_higgs_mass)
    if count < args.nevents:
        raise ValueError(f"only {count} LHE events, but --nevents={args.nevents}")
    xsec = sum(number(row[0]) for row in init[1:])
    error = math.sqrt(sum(number(row[1]) ** 2 for row in init[1:]))
    normalization_source = "LHE init"
    if xsec <= 0 and abs(int(beam[8])) == 4:
        # LHA IDWTUP=+/-4: average signed XWGTUP is the cross section in pb.
        xsec = sumw / count
        error = math.sqrt(max(0., sumw2 / count - xsec ** 2) / (count - 1)) if count > 1 else 0.
        normalization_source = "mean signed XWGTUP (IDWTUP=+/-4; unspecified init cross section)"
    if xsec <= 0 or sumw <= 0:
        raise ValueError("non-positive signed cross section/weight sum; inspect integration statistics")
    return {"cross_section_pb": xsec,
            "cross_section_error_pb": error, "normalization_source": normalization_source,
            "events": count, "negative_events": negatives, "negative_fraction": negatives / count,
            "sum_weight": sumw, "sum_abs_weight": sumabs, "sum_weight_squared": sumw2,
            "effective_events": sumw * sumw / sumw2 if sumw2 else 0,
            "idwtup": int(beam[8]), "source": str(path), "source_size": path.stat().st_size,
            "source_mtime_ns": path.stat().st_mtime_ns}


def validate_signal_hard_inputs(header_text, args, non_nominal_higgs_mass=False):
    """Check supplied POWHEG inputs; retain legacy LHE inventory fields."""
    expected = {
        "hmass": getattr(args, "expected_higgs_mass", 125.0),
        "ih1": 1., "ih2": 1., "alphas_from_pdf": 1.,
        "use_NNLOPS_pdfs": 1., "renscfact": 1., "facscfact": 1.,
    }
    physics_keys = {
        "hmass", "hwidth", "tmass", "topmass", "bmass", "cmass", "gf", "gfermi", "fermi_g",
        "gf_gev_minus2", "ih1", "ih2", "ebeam1", "ebeam2", "lhans1", "lhans2",
        "minlo", "minnlo", "alphas_from_pdf", "use_NNLOPS_pdfs", "renscfact", "facscfact",
        "lhapdf_in_hoppet",
    }
    expected.update({key: value for key, value in getattr(args, "expected_native_parameters", {}).items()
                     if key in physics_keys})
    expected.setdefault("topmass", 173.2)
    expected.setdefault("lhapdf_in_hoppet", 0.)
    for key in ("quarkmasseffects", "nnlo", "nnloint", "nnlopsreweight"):
        matches = re.findall(rf"(?mi)^\s*{key}\s+([-+0-9.eEdD]+)(?:\s|$)", header_text)
        if any(number(value) > 0 for value in matches):
            raise ValueError(f"signal LHE {key} must be disabled for pure-HEFT ihixs normalization")
    for key, wanted in expected.items():
        if not isinstance(wanted, (int, float)):
            continue
        matches = re.findall(rf"(?mi)^\s*{re.escape(key)}\s+([-+0-9.eEdD]+)(?:\s|$)", header_text)
        if not matches:
            if key == "hmass" and non_nominal_higgs_mass:
                raise ValueError("signal LHE Higgs mass differs from the normalization record; embedded hmass is missing")
            continue
        if key == "topmass":
            # POWHEG uses the source fallback for absent/non-positive topmass.
            # A supplied positive mass overrides that fallback in the Wilson coefficient.
            matches = [value for value in matches if number(value) > 0]
        if any(not math.isclose(number(value), float(wanted), rel_tol=1.e-9, abs_tol=1.e-12)
               for value in matches):
            raise ValueError(f"signal LHE hard input {key} differs from the normalization record ({wanted})")


def save_manifest(args, sample, manifest):
    write_json(sample_dir(args, sample) / "campaign.json", manifest, args)


def run_mg5(args, directory, card_name, log_name):
    # MG5 3.5.15 can turn a bare fastjet-config from its saved configuration
    # into a nonexistent path under MG5_DIR. Resolve both tools in exactly
    # the activated runtime used for generation, and pass absolute paths.
    card = directory / "cards" / card_name
    runtime_card = card.with_name("runtime-" + card.name)
    if args.dry_run:
        print("+ resolve fastjet-config and lhapdf-config in the Herwig runtime")
    else:
        command(args, ["bash", "-c", "command -v fastjet-config && command -v lhapdf-config"],
                directory, "mg5-runtime-paths.log")
        paths = (directory / "mg5-runtime-paths.log").read_text().splitlines()
        if len(paths) != 2 or any(not Path(p).is_file() for p in paths):
            raise ValueError("could not resolve FastJet/LHAPDF executables; see mg5-runtime-paths.log")
        prefix = "".join(f"set {key} {Path(path).resolve()} --no_save\n"
                         for key, path in zip(("fastjet", "lhapdf"), paths))
        # The launch interface reloads the exported configuration and does
        # not forward every option from the parent MG5 session (FastJet in
        # particular). Repair only this campaign's process-local settings.
        configure_mg5_runtime(directory / "mg5_process", paths)
        write_text(runtime_card, prefix + card.read_text(), args)
    command(args, [args.mg5_python, args.mg5_dir / "bin/mg5_aMC", runtime_card], directory, log_name)


def configure_mg5_runtime(process_dir, paths):
    config = process_dir / "Cards/amcatnlo_configuration.txt"
    if not config.exists():
        return  # A new export inherits the runtime card's settings.
    if not config.resolve().is_relative_to(process_dir.resolve()):
        raise ValueError(f"refusing to change a shared MG5 configuration outside {process_dir}")
    text = config.read_text()
    for key, path in zip(("fastjet", "lhapdf"), paths):
        text = re.sub(rf"(?m)^\s*{key}\s*=.*\n?", "", text)
        text += f"\n{key} = {Path(path).resolve()}\n"
    config.write_text(text)


def build(args, sample, manifest):
    directory = sample_dir(args, sample)
    if not sample.signal:
        process_dir = directory / "mg5_process"
        if not process_dir.exists():
            run_mg5(args, directory, "process.mg5", "mg5-process.log")
            if not args.dry_run and not (process_dir / "bin/generate_events").exists():
                raise RuntimeError(f"MG5 process export failed; see {directory / 'mg5-process.log'}")
        elif not args.resume and "build" not in manifest["completed"]:
            raise ValueError(f"process exists: {process_dir}; use --resume to reuse it")
        if not args.dry_run:
            patch_mg5_fortran(process_dir)


def patch_mg5_fortran(process_dir):
    """Declare the MG5 3.5.15 procedure argument required by gfortran 16.

    Modify only the exported copy. This does not change the phase-space
    mapping or touch the MG5 installation used by other campaigns.
    """
    path = process_dir / "SubProcesses/genps_fks.f"
    if not path.exists():
        raise ValueError(f"incomplete MG5 process export: missing {path}")
    if not path.resolve().is_relative_to(process_dir.resolve()):
        raise ValueError(f"refusing to patch a shared MG5 source outside {process_dir}")
    original = path.read_text()
    anchor = "      external derivative,ran2,virtgranny,xinv_redvirtgranny\n"
    updated = anchor + "      external virtgranny_red\n"
    if updated in original or "derivative(virtgranny_red" not in original:
        return
    if anchor not in original:
        # A different MG5 version may already declare it on a continued line.
        return
    path.write_text(original.replace(anchor, updated, 1))


def generate(args, sample, manifest):
    directory = sample_dir(args, sample)
    if sample.signal:
        if not args.signal_lhe:
            raise ValueError("generate signal LHE with run_powheg_hjminnlo.py, then pass --signal-lhe")
    else:
        build(args, sample, manifest)
        # A complete existing LHE is recoverable even if the wrapper was interrupted.
        if not lhe_path(args, sample).exists():
            run_mg5(args, directory, "launch.mg5", "mg5-generate.log")
    if not args.dry_run:
        if not lhe_path(args, sample).exists():
            raise RuntimeError(f"expected LHE file missing; inspect logs in {directory}")
        manifest["lhe"] = inspect_lhe(lhe_path(args, sample), sample, args)


def shower(args, sample, manifest):
    directory = sample_dir(args, sample)
    herwig_dir = directory / "herwig"
    if not args.dry_run:
        metadata = inspect_lhe(lhe_path(args, sample), sample, args)
        if "lhe" in manifest and metadata != manifest["lhe"]:
            raise ValueError("LHE changed since the previous stage; use a new run tag")
        manifest["lhe"] = metadata
        # Adopt only a finalized shower that demonstrably consumed the
        # complete finite input. Other partial outputs remain untouched.
        if list((herwig_dir / "events").glob("**/*.root")):
            if args.resume:
                hint = error_limit_recovery_hint(args, sample, manifest)
                if hint:
                    raise ValueError(hint)
                record_shower_completion(args, sample, manifest, "source_exhausted")
                print(f"Recovered finalized finite-LHE shower: {sample.name} "
                      f"({manifest['shower_completion']['saved_events']} saved events)")
                return
            raise ValueError(f"existing HwSim events in {herwig_dir}; use analyze or a new run tag")
        (herwig_dir / "events").mkdir(exist_ok=True)
        save_manifest(args, sample, manifest)
    command(args, [args.herwig, "--version"], herwig_dir, "version.log")
    command(args, [args.herwig, "read", f"{sample.name}.in"], herwig_dir, "read.log")
    try:
        command(args, [args.herwig, "run", f"{sample.name}.run", f"-N{args.nevents}"], herwig_dir, "run.log")
    except RuntimeError as error:
        if args.dry_run:
            raise
        try:
            run_log = (herwig_dir / "run.log").read_text(errors="replace")
        except OSError:
            run_log = ""
        if "More events requested than available in LesHouchesReader" not in run_log:
            hint = error_limit_recovery_hint(args, sample, manifest)
            if hint:
                raise RuntimeError(hint) from error
            raise
        record_shower_completion(args, sample, manifest, "source_exhausted")
        print(f"Consumed the complete finite LHE input: {sample.name}; "
              f"saved {manifest['shower_completion']['saved_events']} events, "
              f"discarded {manifest['shower_completion']['discarded_events']} during showering")
        return
    if not args.dry_run:
        record_shower_completion(args, sample, manifest, "requested_events")


def record_shower_completion(args, sample, manifest, termination):
    directory = sample_dir(args, sample)
    herwig_dir = directory / "herwig"
    card = manifest.get("configuration", {}).get("herwig_card", "")
    required = ("set LesHouchesHandler:WeightOption VarNegWeight",
                "set LesHouchesReader:AllowedToReOpen No",
                "set /Herwig/Analysis/HwSim:OnTheFlyAnalysis No",
                "set LesHouchesReader:Cuts /Herwig/Cuts/NoCuts")
    if any(line not in card.splitlines() for line in required):
        raise ValueError("shower recovery requires the recorded unfiltered, non-recycling signed-weight card")
    if re.search(r"(?m)^\s*(?:set|insert)\s+\S+:(?:MaxScan|NormalizeWeights|NormWeight|WeightNormalization|Reweights|Preweights)\b", card):
        raise ValueError("unsupported shower weight customization; preserve these products for manual inspection")
    if (herwig_dir / f"{sample.name}.in").read_text() != card:
        raise ValueError("persisted Herwig card differs from the campaign configuration")
    inventory = root_inventory(directory)
    command(args, [args.mg5_python, "-c", ROOT_METADATA_SCRIPT,
                   *[entry["path"] for entry in inventory]], herwig_dir, "root-metadata.log")
    metadata = json.loads((herwig_dir / "root-metadata.log").read_text().splitlines()[-1])
    if root_inventory(directory) != inventory:
        raise ValueError("ROOT outputs changed while recording shower completion")
    completion = shower_completion.build_completion(
        herwig_dir, sample.name, args.nevents, manifest["lhe"]["events"], metadata, termination)
    completion["source_weights"] = shower_completion.source_weight_summary(
        lhe_path(args, sample), completion["attempted_events"])
    completion["fingerprint"] = shower_completion.completion_fingerprint(completion)
    shower_completion.validate_completion(
        completion, {**manifest, "root_files": inventory}, directory=directory)
    manifest["root_files"] = inventory
    manifest["shower_completion"] = completion


def root_inventory(directory):
    roots = sorted((directory / "herwig/events").glob("**/*.root"))
    if not roots or any(path.stat().st_size == 0 for path in roots):
        raise ValueError(f"missing or empty HwSim ROOT files in {directory}")
    return [{"path": str(path), "size": path.stat().st_size, "mtime_ns": path.stat().st_mtime_ns}
            for path in roots]


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def validate_root_inventory(directory, manifest, *, allow_legacy_snapshot=False):
    """Adopt a missing legacy inventory only after checking recorded inputs."""
    current = root_inventory(directory)
    stored = manifest.get("root_files")
    provenance = manifest.get("root_inventory_provenance", {})
    input_list = directory / f"{manifest['sample']}_hwsim_roots.input"
    summary = directory / f"{manifest['sample']}_hwsim_roots-{manifest['run_tag']}.dat"
    if stored is not None:
        if current != stored:
            raise ValueError("ROOT products changed since the completed analyze stage")
        if provenance.get("kind") == "legacy_snapshot_at_normalize":
            hashes = [{"path": entry["path"], "sha256": file_sha256(entry["path"])} for entry in current]
            if hashes != provenance.get("root_sha256"):
                raise ValueError("ROOT contents changed since the legacy normalization snapshot")
            if file_sha256(input_list) != provenance.get("root_input_list_sha256"):
                raise ValueError("ROOT input list changed since the legacy normalization snapshot")
            if file_sha256(summary) != provenance.get("analysis_summary_sha256"):
                raise ValueError("analysis summary changed since the legacy normalization snapshot")
        return
    if not allow_legacy_snapshot:
        raise ValueError("completed campaign lacks a ROOT inventory; use --stage normalize for legacy migration")
    if not input_list.is_file() or not summary.is_file():
        raise ValueError("legacy normalization requires the recorded ROOT input list and analysis summary")
    listed = [Path(line.strip()) for line in input_list.read_text().splitlines() if line.strip()]
    listed = sorted(str((path if path.is_absolute() else directory / path).resolve()) for path in listed)
    if listed != sorted(str(Path(entry["path"]).resolve()) for entry in current):
        raise ValueError("legacy ROOT input list differs from the present HwSim inventory")
    recorded_input = manifest.get("analysis", {}).get("input")
    if recorded_input is not None and Path(recorded_input).resolve() != input_list.resolve():
        raise ValueError("legacy analysis summary identifies a different ROOT input list")
    if input_list.stat().st_mtime_ns > summary.stat().st_mtime_ns or any(
            entry["mtime_ns"] > summary.stat().st_mtime_ns for entry in current):
        raise ValueError("legacy ROOT inputs are newer than the completed analysis; rerun analysis with a new run tag")
    manifest["root_files"] = current
    manifest["root_inventory_provenance"] = {
        "kind": "legacy_snapshot_at_normalize", "historical_inventory_available": False,
        "evidence": "completed campaign, unchanged recorded analysis summary, matching saved input list and input timestamps",
        "root_sha256": [{"path": entry["path"], "sha256": file_sha256(entry["path"])} for entry in current],
        "root_input_list_sha256": file_sha256(input_list),
        "analysis_summary_sha256": file_sha256(summary),
    }
    print("+ adopted present legacy ROOT inventory; no historical content hashes were available")


def analysis_summary(directory, run_tag, nevents, weight_scale=None, previous=None):
    prefix = directory / f"{SAMPLES[0].name}_hwsim_roots-{run_tag}"
    for suffix in (".dat", ".top", "_var.root"):
        path = Path(str(prefix) + suffix)
        if not path.is_file() or path.stat().st_size == 0:
            raise ValueError(f"completed analysis output is missing or empty: {path}")
    data = dict(line.split(maxsplit=1) for line in Path(str(prefix) + ".dat").read_text().splitlines()
                if line.strip())
    if "events_read" not in data or (weight_scale is not None and "weight_scale" not in data):
        raise ValueError(f"analysis summary lacks event count or weight scale: {prefix}.dat")
    if int(data["events_read"]) != nevents:
        raise ValueError(f"HwSim event count {data['events_read']} differs from recorded/requested {nevents}")
    for key in ("sum_weight", "sum_abs_weight", "sum_weight_squared", "sum_tree_weight"):
        if key not in data or not math.isfinite(number(data[key])):
            raise ValueError(f"missing or non-finite analysis {key} in {prefix}.dat")
    if number(data["sum_weight"]) <= 0:
        raise ValueError("non-positive signed analysis weight sum; increase the pilot statistics")
    if number(data["sum_abs_weight"]) + 1.e-12 < abs(number(data["sum_weight"])):
        raise ValueError("analysis sum_abs_weight is smaller than the signed sum_weight")
    if number(data["sum_weight_squared"]) <= 0:
        raise ValueError("non-positive analysis sum_weight_squared")
    if not math.isclose(number(data["sum_tree_weight"]), number(data["sum_weight"]),
                        rel_tol=1.e-8, abs_tol=1.e-12):
        raise ValueError("analysis tree weight closure failed")
    if weight_scale is not None and not math.isclose(number(data["weight_scale"]), weight_scale,
                                                    rel_tol=1.e-9, abs_tol=1.e-12):
        raise ValueError("analysis weight_scale differs from the physical Higgs branching ratio")
    if previous is not None and data != previous:
        raise ValueError("analysis summary changed since the completed analyze stage")
    return data


def write_signal_normalization(args, sample, manifest, native_lhe, weight_scale):
    sidecar = signal_normalization.signal_sidecar(
        args.signal_normalization, manifest, native_lhe, weight_scale)
    path = sample_dir(args, sample) / f"normalization-{args.run_tag}.json"
    write_json(path, sidecar, args)
    manifest["rate_normalization"] = {
        "normalization_kind": sidecar["normalization_kind"],
        "record_path": str(args.signal_normalization),
        "record_fingerprint": sidecar["ihixs_record_sha256"],
        "sidecar_sha256": hashlib.sha256(json.dumps(sidecar, sort_keys=True,
                                                    separators=(",", ":")).encode()).hexdigest(),
    }
    manifest["normalization_rule"] = "ihixs N3LO inclusive ggF cross section times physical BR once"
    return sidecar


def normalize_existing(args, sample):
    """Update an analyzed HO signal's rate without invoking its generators."""
    directory = sample_dir(args, sample)
    manifest_path = directory / "campaign.json"
    if not manifest_path.is_file():
        raise ValueError(f"normalize requires an existing campaign manifest: {manifest_path}")
    manifest = json.loads(manifest_path.read_text())
    if not signal_normalization.is_ho_signal(manifest):
        raise ValueError("normalize supports only the existing HJMiNNLO ggF signal campaign")
    if "analyze" not in manifest.get("completed", []):
        raise ValueError("normalize requires a completed analyze stage")
    if args.run_tag_explicit and args.run_tag != manifest.get("run_tag"):
        raise ValueError("--run-tag differs from the existing campaign; use its recorded run tag")
    required = ("run_tag", "ebeam_gev", "nevents_requested", "weight_scale", "lhe_file", "lhe", "analysis")
    if any(key not in manifest for key in required):
        raise ValueError("normalize requires the recorded LHE and completed analysis summary")
    inferred = dict(vars(args))
    inferred.update(
        run_tag=manifest["run_tag"], ebeam=float(manifest["ebeam_gev"]),
        nevents=int(manifest["nevents_requested"]), higgs_br=float(manifest["weight_scale"]),
        signal_lhe=Path(manifest["lhe_file"]).expanduser().resolve(),
    )
    existing_args = SimpleNamespace(**inferred)
    if not 0 < existing_args.higgs_br <= 1 or existing_args.nevents <= 0:
        raise ValueError("invalid recorded Higgs BR or event count")
    record = preflight_signal_normalization(existing_args, manifest)
    # Missing/unfinished ihixs inputs are printable during dry-run preparation.
    # A migration still validates its existing products before printing writes.
    current = inspect_lhe(existing_args.signal_lhe, sample, existing_args)
    if current != manifest.get("lhe"):
        raise ValueError("LHE changed since the completed analyze stage")
    if "shower_completion" in manifest:
        shower_completion.validate_completion(manifest["shower_completion"], manifest, directory=directory)
    analysis_summary(directory, existing_args.run_tag, shower_completion.expected_analysis_events(manifest),
                     existing_args.higgs_br, manifest.get("analysis"))
    validate_root_inventory(directory, manifest, allow_legacy_snapshot=True)
    if record is None:
        print(f"+ pending normalization-only update for {directory}; no products will be changed")
        return
    write_signal_normalization(existing_args, sample, manifest, current, existing_args.higgs_br)
    save_manifest(existing_args, sample, manifest)
    print(f"Updated HO signal normalization: {directory} (run tag {existing_args.run_tag})")


def verify_signal_rate(args, sample, manifest):
    record = preflight_signal_normalization(args, manifest)
    path = sample_dir(args, sample) / f"normalization-{manifest['run_tag']}.json"
    if not path.is_file():
        raise ValueError("completed signal normalization is missing; use --stage normalize")
    sidecar = json.loads(path.read_text())
    try:
        signal_normalization.validate_sidecar(sidecar, manifest, args.higgs_br)
    except ValueError as error:
        raise ValueError(f"{error}; use --stage normalize to update only the signal rate") from error
    if sidecar["ihixs_record_sha256"] != record["fingerprint"]:
        raise ValueError("signal normalization changed; use --stage normalize to update only the rate")
    rate = manifest.get("rate_normalization", {})
    digest = hashlib.sha256(json.dumps(sidecar, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    if rate.get("record_fingerprint") != record["fingerprint"] or rate.get("sidecar_sha256") != digest:
        raise ValueError("signal rate metadata changed; use --stage normalize to refresh its provenance")


def verify_completed(args, sample, stage, manifest):
    directory = sample_dir(args, sample)
    if stage == "build" and not sample.signal:
        if not (directory / "mg5_process/bin/generate_events").exists():
            raise ValueError(f"completed process export is missing in {directory}")
    if stage in ("generate", "shower", "analyze"):
        current = inspect_lhe(lhe_path(args, sample), sample, args)
        if current != manifest.get("lhe"):
            raise ValueError(f"LHE changed since completed {stage}: {directory}")
    if stage in ("shower", "analyze"):
        if "shower_completion" in manifest:
            shower_completion.validate_completion(manifest["shower_completion"], manifest, directory=directory)
        if sample.signal:
            validate_root_inventory(directory, manifest)
        elif root_inventory(directory) != manifest.get("root_files"):
            raise ValueError(f"ROOT products changed since completed {stage}: {directory}")
    if stage == "analyze":
        prefix = directory / f"{sample.name}_hwsim_roots-{args.run_tag}"
        for suffix in (".dat", ".top", "_var.root"):
            if not Path(str(prefix) + suffix).is_file():
                raise ValueError(f"completed analysis output is missing: {prefix}{suffix}")
        if not (directory / f"normalization-{args.run_tag}.json").is_file():
            raise ValueError(f"completed analysis normalization is missing in {directory}")
        sidecar = json.loads((directory / f"normalization-{args.run_tag}.json").read_text())
        completion = manifest.get("shower_completion", {})
        if (completion or "shower_completion_sha256" in sidecar) and (
                sidecar.get("shower_completion_sha256") != completion.get("fingerprint")):
            raise ValueError(f"completed analysis sidecar differs from its shower population: {directory}")
        if sample.signal:
            analysis_summary(directory, args.run_tag, shower_completion.expected_analysis_events(manifest), args.higgs_br,
                             manifest.get("analysis"))
            verify_signal_rate(args, sample, manifest)


def analyze(args, sample, manifest):
    directory = sample_dir(args, sample)
    if sample.signal:
        preflight_signal_normalization(args, manifest)
        if not args.dry_run:
            current = inspect_lhe(lhe_path(args, sample), sample, args)
            if "lhe" in manifest and current != manifest["lhe"]:
                raise ValueError("LHE changed since the previous stage; use a new run tag")
            manifest["lhe"] = current
    roots = sorted((directory / "herwig/events").glob("**/*.root"))
    if not roots and not args.dry_run:
        raise ValueError(f"no HwSim ROOT files in {directory}")
    if not args.dry_run:
        if "shower_completion" in manifest:
            shower_completion.validate_completion(manifest["shower_completion"], manifest, directory=directory)
        inventory = root_inventory(directory)
        if "root_files" in manifest and inventory != manifest["root_files"]:
            raise ValueError("HwSim ROOT inputs changed since showering")
        manifest["root_files"] = inventory
    root_input = directory / f"{sample.name}_hwsim_roots.input"
    write_text(root_input, "".join(f"{p}\n" for p in roots), args)
    weight_scale = args.higgs_br if sample.signal else 1.
    command(args, [ANALYSIS_EXE, root_input, "-t", args.run_tag, "-w", weight_scale,
                   "--response-mode", sample.response_mode,
                   "--seed", args.seed_base + SAMPLES.index(sample)], directory, "analysis.log")
    if not args.dry_run:
        dat_path = root_input.with_name(root_input.stem + f"-{args.run_tag}.dat")
        data = dict(line.split(maxsplit=1) for line in dat_path.read_text().splitlines() if line.strip())
        expected_events = shower_completion.expected_analysis_events(manifest)
        if int(data["events_read"]) != expected_events:
            raise ValueError(f"HwSim event count {data['events_read']} differs from saved/requested {expected_events}")
        if number(data["sum_weight"]) <= 0:
            raise ValueError("non-positive signed analysis weight sum; increase the pilot statistics")
        if sample.signal:
            data = analysis_summary(directory, args.run_tag, expected_events, args.higgs_br)
        if "shower_completion" in manifest:
            shower_completion.normalization_denominator(manifest, number(data["sum_weight"]), weight_scale)
        manifest["analysis"] = data
        if "lhe" not in manifest:
            manifest["lhe"] = inspect_lhe(lhe_path(args, sample), sample, args)
        if sample.signal:
            write_signal_normalization(args, sample, manifest, manifest["lhe"], weight_scale)
        else:
            normalization = {
                "run_tag": args.run_tag, "sample": sample.name,
                "cross_section_pb": manifest["lhe"]["cross_section_pb"],
                "cross_section_error_pb": manifest["lhe"]["cross_section_error_pb"],
                "source": manifest["lhe"]["normalization_source"] + ": before detector response and BR",
                "weight_scale": weight_scale,
            }
            if "shower_completion" in manifest:
                normalization["shower_completion_sha256"] = manifest["shower_completion"]["fingerprint"]
            write_json(directory / f"normalization-{args.run_tag}.json", normalization, args)


def run_campaign(args):
    samples = selected_samples(args)
    if args.stage == "normalize":
        for sample in samples:
            if sample.signal:
                normalize_existing(args, sample)
        return 0
    if args.stage not in ("prepare", "build") and any(s.signal for s in samples) and not args.signal_lhe:
        raise ValueError("--signal-lhe is required for the signal; use --run-samples backgrounds for MG5 only")
    if args.stage in ("analyze", "all") and any(s.signal for s in samples):
        preflight_signal_normalization(args, signal_campaign_identity(args))
        signal = SAMPLES[0]
        manifest_path = sample_dir(args, signal) / "campaign.json"
        if not args.dry_run and manifest_path.is_file():
            previous = json.loads(manifest_path.read_text())
            if "analyze" in previous.get("completed", []):
                verify_signal_rate(args, signal, previous)
    if args.stage in ("analyze", "all"):
        if not args.dry_run:
            for sample in samples:
                path = sample_dir(args, sample) / "campaign.json"
                if path.is_file():
                    existing = json.loads(path.read_text())
                    if "shower_completion" in existing:
                        shower_completion.validate_completion(existing["shower_completion"], existing,
                                                               directory=sample_dir(args, sample))
                    elif args.stage == "analyze" and "shower" not in existing.get("completed", []):
                        raise ValueError("shower is not recorded as complete; run --stage shower --resume first")
        command(args, ["make", "-C", ANALYSIS_DIR, ANALYSIS_EXE.name,
                       f"CPP={args.analysis_cxx}", f"CXX={args.analysis_cxx}",
                       "FASTJET_CPPFLAGS=", "FASTJET_LDFLAGS="],
                SCRIPT_DIR, "ho-analysis-build.log")
    stages = ("generate", "shower", "analyze") if args.stage == "all" else (args.stage,)
    for sample in samples:
        manifest = prepare(args, sample)
        for stage in stages:
            if stage == "prepare":
                continue
            if stage in manifest["completed"]:
                if args.resume:
                    if not args.dry_run:
                        verify_completed(args, sample, stage, manifest)
                    print(f"Reusing completed {stage}: {sample.name}")
                    continue
                raise ValueError(f"{sample.name}: {stage} already complete; use --resume")
            {"build": build, "generate": generate, "shower": shower, "analyze": analyze}[stage](args, sample, manifest)
            manifest["completed"].append(stage)
            save_manifest(args, sample, manifest)
    print(f"HO campaign directory: {args.output_dir}")
    return 0


def main(argv=None):
    args = parse_args(argv)
    if args.dry_run:
        return run_campaign(args)
    if args.stage == "normalize" and not args.output_dir.is_dir():
        raise ValueError(f"normalize requires an existing HO campaign directory: {args.output_dir}")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    with (args.output_dir / ".campaign.lock").open("a") as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise ValueError(f"another campaign command is active in {args.output_dir}")
        return run_campaign(args)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (ValueError, RuntimeError, OSError) as error:
        sys.exit(f"Error: {error}")
