"""Extract source-grouped regional rates from the published student 40 TeV scores.

Run from any directory with Python, NumPy and SciPy. The signed physical
weights in the score export are yields at 100/fb. Group response alternatives
from the same generated event before computing Monte Carlo covariances.
"""
import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy.sparse import coo_matrix

FOLDER = Path(__file__).resolve().parent
SOURCE = FOLDER / 'scores.csv'
THRESHOLD = .992
EXPOSURE = 100.
FIELDS = ('sourceevent', 'm_gg', 'score', 'weight_fb', 'test_weight_fb', 'is_test')


def read_scores():
    records = defaultdict(list)
    with SOURCE.open() as stream:
        for row in csv.DictReader(stream):
            assert float(row['n_selected_photons']) >= 2
            rate = float(row['physical_weight']) / EXPOSURE
            projected = float(row['projected_physical_weight']) / EXPOSURE
            assert np.isclose(rate/float(row['partition_fraction']), projected, rtol=1.e-12, atol=1.e-14)
            records[row['sample']].append((int(row['sourceevent']), float(row['m_gg']),
                                           float(row['score']), rate, projected, row['partition']=='test'))
    return {name: np.asarray(rows, dtype=[('sourceevent', 'i8'), ('m_gg', 'f8'),
                                          ('score','f8'), ('weight_fb','f8'),
                                          ('test_weight_fb','f8'), ('is_test','?')])
            for name, rows in records.items()}


def summarize(sample, mode):
    data = sample[sample['is_test'] & (sample['score'] >= THRESHOLD)] if mode=='default_classifier' else sample
    mass = data['m_gg']
    weights = data['test_weight_fb' if mode=='default_classifier' else 'weight_fb']
    _, idx = np.unique(data['sourceevent'], return_inverse=True)
    def matrix(binid, n):
        ok = (binid >= 0) & (binid < n)
        nsources = int(max(idx, default=-1)) + 1
        return coo_matrix((weights[ok], (idx[ok],binid[ok])), shape=(nsources,n)).tocsr()
    def stats(source_matrix):
        return dict(rates_fb=np.asarray(source_matrix.sum(axis=0)).ravel().tolist(),
                    covariance_fb2=(source_matrix.T@source_matrix).toarray().tolist(),
                    selected_sources=np.asarray((source_matrix != 0).sum(axis=0)).ravel().tolist())
    binid = np.searchsorted(EDGES, mass, side='right') - 1
    regions = {
        'peak_123_127':(mass >=123)&(mass<127),
        'sideband_105_120':(mass>=105)&(mass<120),
        'sideband_130_160':(mass>=130)&(mass<160),
        'gap_120_123':(mass>=120)&(mass<123),
        'gap_127_130':(mass>=127)&(mass<130),
        'outside_105_160':(mass<105)|(mass>=160),
    }
    codes = np.full(len(weights),-1)
    for i,mask in enumerate(regions.values()):
        assert not np.any(codes[mask] != -1)
        codes[mask]=i
    assert np.all(codes>=0)
    src = matrix(codes,len(regions))
    details=stats(src)
    center = src[:,0].toarray().ravel()
    side = np.asarray(src[:,1:3].sum(axis=1)).ravel()
    details.update(names=list(regions), all_mass_rate_fb=float(weights.sum()),
                   all_mass_mc_error_fb=float(np.linalg.norm(np.asarray(src.sum(axis=1)).ravel())),
                   peak_fb=float(center.sum()), control_fb=float(side.sum()),
                   peak_mc_error_fb=float(np.linalg.norm(center)), control_mc_error_fb=float(np.linalg.norm(side)),
                   peak_control_covariance_fb2=float(center@side), peak_sources=int(np.count_nonzero(center)),
                   control_sources=int(np.count_nonzero(side)), all_selected_sources=int(src.shape[0]),
                   min_mass_gev=float(mass.min()) if len(mass) else None,
                   max_mass_gev=float(mass.max()) if len(mass) else None)
    return dict(regions=details, spectrum=stats(matrix(binid,len(EDGES)-1)))


EDGES = np.arange(105.,161.)
if __name__ == '__main__':
    records=read_scores()
    save=dict(source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
              source_uri='timur:/home/shared/HiggsSSC/student-results/ssc40-20261118/diphoton/xgboost_ssc/scores.csv',
              exposure_fb_inverse=EXPOSURE, default_classifier_threshold=THRESHOLD,
              binned_mass_edges_gev=EDGES.tolist(),
              event_selection='Inclusive uses all eligible rows with at least two photons, with no classifier cut; default classifier uses the held-out test, score >=0.992, with saved projected physical weights. Bins and regions are lower-inclusive, upper-exclusive. All rates in fb; covariance is the sum of outer products of signed source vectors at fixed generator normalization.',
              selections={mode:{name:summarize(rows, mode) for name, rows in records.items()}
                          for mode in ['inclusive','default_classifier']})
    (FOLDER/'diphoton_regions.json').write_text(json.dumps(save,separators=(',',':'))+'\n')
    for mode, d in save['selections'].items():
        print(mode, 'peak, control, all, peak and control sources, masses')
        for name,s in d.items():
            print(name,*[s['regions'][k] for k in ['peak_fb','control_fb','all_mass_rate_fb','peak_sources','control_sources','min_mass_gev','max_mass_gev']])
