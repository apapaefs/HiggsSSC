"""Compute and cross-check expected local discovery luminosities at 125 GeV."""
import hashlib
import json
import math
from pathlib import Path

from scipy.optimize import brentq

from sideband_reach import OnOff, combined_reach, fixed_transfer_power


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
REGIONS = ROOT / "diphoton_regions.json"
SHAPE = ROOT / "closure/continuum_fit.json"
FOUR = ROOT.parent / "student-defaults-20261118/2f510c0/discovery/median_5sigma.json"


def summarize_reach(luminosity):
    return {"luminosity_fb_inverse": luminosity,
            "calendar_months_at_design": None if luminosity is None else 1.2*luminosity}


def crosscheck(model, estimate, s4=None, b4=None):
    # The data include many thousands of diphotons. Average the conditional
    # nonrandomized power over T and bracket a median crossing near the
    # asymptotic estimate, to a precision finer than the quoted projections.
    args = () if s4 is None else (s4, b4)
    power = lambda L: fixed_transfer_power(model,L,*args)
    central = brentq(lambda L: power(L)-.5, estimate*.97, estimate*1.03, xtol=2.e-5)
    return {"luminosity_fb_inverse": central, "calendar_months_at_design": 1.2*central,
            "exact_power_at_approximate_reach": power(estimate), "approximate_fb_inverse": estimate}


def main():
    regions = json.loads(REGIONS.read_text())["selections"]["inclusive"]
    signal = next(row["regions"] for k,row in regions.items() if k.startswith("signal"))
    background = {k:row["regions"] for k,row in regions.items() if k.startswith("bkg")}
    totals = {field:sum(row[field] for row in background.values()) for field in ("peak_fb","control_fb")}
    bsr, bsb = totals["peak_fb"], totals["control_fb"]
    variance = {k:v["peak_mc_error_fb"]**2/bsr**2 + v["control_mc_error_fb"]**2/bsb**2
                - 2*v["peak_control_covariance_fb2"]/bsr/bsb for k,v in background.items()}
    transfer_error = math.sqrt(sum(variance.values()))
    model_args = (signal["peak_fb"],bsr,signal["control_fb"],bsb)
    tests = {"known_transfer": OnOff(*model_args), "simulation_transfer": OnOff(*model_args, transfer_error),
             "half_percent_transfer": OnOff(*model_args, .005)}
    inputs = json.loads(FOUR.read_text())["selections"]["classifier_extended_fourlepton_test"]
    four = {k:v["fourlepton"] for k,v in inputs.items()}
    def combinations(qgamma):
        return {k:{t:summarize_reach(lum) for t,lum in combined_reach(
                    qgamma, v["signal_fb"], v["background_fb"]).items()} for k,v in four.items()}
    counting = {}
    for k, model in tests.items():
        diphoton = model.diphoton_asimov()
        counting[k] = {"diphoton":summarize_reach(diphoton), "combined":combinations(model.q_asimov),
                       "sigma_log_transfer": model.log_transfer_error,
                       "limiting_gamma_Z": model.limiting_z() if model.log_transfer_error else None}
        if k=="known_transfer":
            counting[k]["exact_conditional_checks"] = {"diphoton": crosscheck(model,diphoton)}
            for name, rates in four.items():
                estimate = counting[k]["combined"][name]["gaussian_score_exact_fourlepton_fb_inverse"]
                counting[k]["exact_conditional_checks"][name] = crosscheck(
                    model,estimate["luminosity_fb_inverse"],rates["signal_fb"],rates["background_fb"])
    shapes = json.loads(SHAPE.read_text())["models"]
    fits = {}
    for name,item in shapes.items():
        q = item["q0_per_fb_Asimov_fitted_continuum"]
        fits[name] = {"qgamma_per_fb":q, "diphoton":summarize_reach(25./q),
                      "combined":combinations(lambda l:q*l)}
    nominal = shapes["exponential2"]
    q = nominal["q0_per_fb_Asimov_fitted_continuum"]
    spur = nominal["spurious_signal_mc_standard_error"]
    uncertainty_case = {"scope":"Illustration assuming a calibrated additive signal-like fit bias with a fixed Gaussian measurement error equal to its present MC standard error. The observed MC central residual is not assumed to be a physical bias.",
                        "sigma_mu":spur,"diphoton":summarize_reach(None),"limiting_gamma_Z":1./spur,
                        "combined":combinations(lambda l:1./(1./(q*l) + spur**2))}
    result = {"luminosity_per_design_year_fb_inverse":10., "alpha_one_sided_local_5sigma":2.866515718791933e-7,
              "mass_GeV":125, "inputs":{str(p.relative_to(ROOT.parent)):hashlib.sha256(p.read_bytes()).hexdigest()
                                         for p in (REGIONS,SHAPE,FOUR)},
              "method":"Diphoton Asimov likelihood at SM strength one, with the background normalization floating in the data fit. Combine an asymptotically normal diphoton likelihood score with the exact Poisson four-lepton count to find 50% discovery probability. The known-transfer counting cross-check uses a conditional binomial/Poisson test and averages over all on/off totals. Uncertain counting transfers use a Gaussian constraint on the log peak/sideband ratio. Other systematics are fixed.",
              "fourlepton_rates_fb":{k:{a:v[a] for a in ("signal_fb","background_fb")} for k,v in four.items()},
              "peak_and_sideband_rates_fb":{"signal":[model_args[0],model_args[2]],"background":[bsr,bsb]},
              "background_transfer":bsr/bsb, "variance_log_transfer_by_background":variance,
              "sigma_log_transfer_for_limiting_5sigma":tests["known_transfer"].log_transfer_shift/5.,
              "inclusive_peak_counting":counting, "multibin_models":fits,
              "multibin_additive_bias_illustration":uncertainty_case}
    (HERE / "sideband_reach.json").write_text(json.dumps(result,indent=2,allow_nan=False)+"\n")
    print(json.dumps(counting["known_transfer"]["exact_conditional_checks"],indent=2))


if __name__=="__main__":
    main()
